package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.util.Iterator;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
//import org.eclipse.core.resources.IFolder;
//import org.eclipse.core.resources.IProject;
//import org.eclipse.core.resources.IResource;
//import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;

public class MTable2Owl {
	public static void generateMTable(IProject metagProject, OntModel ontModel, boolean isBFO)
			throws CoreException, DocumentException {
		IFolder tableFolder = null;
		IFolder tableFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder tableFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (tableFolder1.exists()) {
			tableFolder = tableFolder1;
		} else if (tableFolder2.exists()) {
			tableFolder = tableFolder2;
		}
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		OntClass owlMapping_TableClass = ontModel.createClass(METAG + "Mapping_Table");
		OntClass owlMapping_Table_ColumnClass = ontModel.createClass(METAG + "Mapping_Table_Column");
		owlMapping_TableClass.addSubClass(owlMapping_Table_ColumnClass);
		OntClass owlMapping_Table_RowClass = ontModel.createClass(METAG + "Mapping_Table_Row");
		owlMapping_TableClass.addSubClass(owlMapping_Table_RowClass);
		OntClass owlMapping_Table_LinkClass = ontModel.createClass(METAG + "Mapping_Table_Link");
		owlMapping_TableClass.addSubClass(owlMapping_Table_LinkClass);

		// 创建annotaiton property
		AnnotationProperty annotationProName = ontModel.createAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationProlocalLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationProId = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationProText = ontModel.createAnnotationProperty(METAG + "text");
		// 增加mTable标记语言
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");
		// 非一定存在annotaiton property
		AnnotationProperty annotationProModel_Id = ontModel.createAnnotationProperty(METAG + "model_id");
		AnnotationProperty annotationProMeta_Model = ontModel.createAnnotationProperty(METAG + "meta_model");
		AnnotationProperty annotationProMeta_Property_Instance_Id = ontModel
				.createAnnotationProperty(METAG + "meta_property_instance_id");
		AnnotationProperty annotationProMeta_Property_Instance_Type = ontModel
				.createAnnotationProperty(METAG + "meta_property_instance_type");
		AnnotationProperty annotationProMeta_Property_Instance_Text = ontModel
				.createAnnotationProperty(METAG + "meta_property_instance_text");

		// 创建Object Property
		ObjectProperty objectProOwnMappingRow = ontModel.createObjectProperty(METAG + "ownMappingRow");
		ObjectProperty objectProOwnMappingColumn = ontModel.createObjectProperty(METAG + "ownMappingColumn");
		if (isBFO) {
			OntClass owlKarmaClass = ontModel.getOntClass(METAG + "KARMA");
			owlKarmaClass.addSubClass(owlMapping_TableClass);
		}

		for (IResource fileLanguage : tableFolder.members()) {
			if (fileLanguage.getType() == IResource.FOLDER) {
				IFolder languageFolder = (IFolder) fileLanguage;
				IFolder fileModel = null;
				IFolder fileModel1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
				IFolder fileModel2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
				if (fileModel1 != null) {
					fileModel = fileModel1;
				} else if (fileModel2 != null) {
					fileModel = fileModel2;
				}
				for (IResource f : fileModel.members()) {
					if (f.getName().endsWith(".mTable")) {
						// 读mTable文件
						File file = new File(f.getLocation().toOSString());
						SAXReader reader = new SAXReader();
						Document document = reader.read(file);
						Element root = document.getRootElement();
						String mapping_TableName = root.element("Mapping_Table").attribute("Name").getValue();

						// 每一个owlMapping_TableIndividual属于一个Mapping_Table
						Individual owlMapping_TableIndividual = ontModel.createIndividual(METAG + mapping_TableName,
								owlMapping_TableClass);
						owlMapping_TableIndividual.addProperty(annotationProName, mapping_TableName);
						if (root.element("Mapping_Table").attribute("localLabel") != null) {
							String localLabel = root.element("Mapping_Table").attribute("localLabel").getValue();
							owlMapping_TableIndividual.addProperty(annotationProlocalLabel, localLabel);
						}
						// 增加mTable标记语言
						OntClass owlLanguage = ontModel.getOntClass(METAG + languageFolder.getName());
						if (owlLanguage == null) {
							String languageId = SaveKarInformation.getLanguageId(languageFolder);
							OntClass ontClass = ontModel.getOntClass(METAG + languageId);
							owlMapping_TableIndividual.addProperty(annotationPropertyModelLocation,
									languageFolder.getName());
						} else {
							owlMapping_TableIndividual.addProperty(annotationPropertyModelLocation,
									owlLanguage.getLocalName());
						}

						// mapping_TableRows
						Element theHeader = root.element("Mapping_Table").element("THE-HEADER");
						Element rowHeader = theHeader.element("ROW-HEADER");
						Element columnHeader = theHeader.element("COLUMN-HEADER");
						if (rowHeader.elements() != null) {
							for (Iterator<Element> it = rowHeader.elementIterator(); it.hasNext();) {
								// ROW
								Element row = it.next();
								String row_Id = row.attribute("id").getValue();
								Individual row_Individual = ontModel.createIndividual(
										METAG + mapping_TableName + "row_refer" + "__" + row_Id,
										owlMapping_Table_RowClass);
								row_Individual.addProperty(annotationProId, row_Id);
								if (row.attribute("model_id")!= null) {
									String model_Id = row.attribute("model_id").getValue();
									row_Individual.addProperty(annotationProModel_Id, model_Id);
								}
								if (row.attribute("meta_model") != null) {
									String meta_Model = row.attribute("meta_model").getValue();
									row_Individual.addProperty(annotationProMeta_Model, meta_Model);
								}
								String row_text = row.getText();
								row_Individual.addProperty(annotationProText, row_text);
								if (row.element("meta_property_instance") != null) {
									Element meta_Property_Instance = row.element("meta_property_instance");
									if (meta_Property_Instance.attribute("meta_property_instance_id") != null) {
										String meta_Property_Instance_Id = meta_Property_Instance
												.attribute("meta_property_instance_id").getValue();
										row_Individual.addProperty(annotationProMeta_Property_Instance_Id,
												meta_Property_Instance_Id);
									}
									if (meta_Property_Instance.attribute("meta_property_instance_type") != null) {
										String meta_Property_Instance_Type = meta_Property_Instance
												.attribute("meta_property_instance_type").getValue();
										row_Individual.addProperty(annotationProMeta_Property_Instance_Type,
												meta_Property_Instance_Type);
									}
									if (meta_Property_Instance.getText() != null) {
										String meta_Property_Instance_Text = meta_Property_Instance.getText();
										row_Individual.addProperty(annotationProMeta_Property_Instance_Text,
												meta_Property_Instance_Text);
									}

								}
								owlMapping_TableIndividual.addProperty(objectProOwnMappingRow, row_Individual);
							}
						}
						// mapping_TableColumns
						if (columnHeader.elements() != null) {
							for (Iterator<Element> it = columnHeader.elementIterator(); it.hasNext();) {
								// Column
								Element column = it.next();
								String column_Id = column.attribute("id").getValue();
								Individual column_Individual = ontModel.createIndividual(
										METAG + mapping_TableName + "column_refer" + "__" + column_Id,
										owlMapping_Table_ColumnClass);
								column_Individual.addProperty(annotationProId, column_Id);
								if (column.attribute("model_id") != null) {
									String model_Id = column.attribute("model_id").getValue();
									column_Individual.addProperty(annotationProModel_Id, model_Id);
								}
								if (column.attribute("meta_model") != null) {
									String meta_Model = column.attribute("meta_model").getValue();
									column_Individual.addProperty(annotationProMeta_Model, meta_Model);
								}
								String column_text = column.getText();
								column_Individual.addProperty(annotationProText, column_text);
								if (column.element("meta_property_instance") != null) {
									Element meta_Property_Instance = column.element("meta_property_instance");
									if (meta_Property_Instance.attribute("meta_property_instance_id") != null) {
										String meta_Property_Instance_Id = meta_Property_Instance
												.attribute("meta_property_instance_id").getValue();
										column_Individual.addProperty(annotationProMeta_Property_Instance_Id,
												meta_Property_Instance_Id);
									}
									if (meta_Property_Instance.attribute("meta_property_instance_type") != null) {
										String meta_Property_Instance_Type = meta_Property_Instance
												.attribute("meta_property_instance_type").getValue();
										column_Individual.addProperty(annotationProMeta_Property_Instance_Type,
												meta_Property_Instance_Type);
									}
									if (meta_Property_Instance.getText() != null) {
										String meta_Property_Instance_Text = meta_Property_Instance.getText();
										column_Individual.addProperty(annotationProMeta_Property_Instance_Text,
												meta_Property_Instance_Text);
									}

								}
								owlMapping_TableIndividual.addProperty(objectProOwnMappingColumn, column_Individual);

							}
						}
						// LINK
						Element link = root.element("Mapping_Table").element("LINK");
						if (link.elements() != null) {
							for (Iterator<Element> it = link.elementIterator(); it.hasNext();) {
								Element row = it.next();
								String linkFromRow_id = row.attribute("id").getValue();
								Individual linkFromRow_Individual = ontModel
										.getIndividual(METAG + mapping_TableName + "row_refer" + "__" + linkFromRow_id);
								for (Iterator<Element> itc = row.elementIterator(); itc.hasNext();) {
									Element column = itc.next();
									String linkToColumn_id = column.attribute("id").getValue();
									Individual linkToColumn_Individual = ontModel.getIndividual(
											METAG + mapping_TableName + "column_refer" + "__" + linkToColumn_id);
									String relationship = column.getText();
									if (isBFO) {
										if (relationship.equals("复制") || relationship.equals("追溯")
												|| relationship.equals("满足") || relationship.equals("验证")
												|| relationship.equals("细化") || relationship.equals("派生")
												|| relationship.equals("组合")|| relationship.equals("包含")) {
											ObjectProperty objectProLink = ontModel
													.getObjectProperty(METAG + relationship);
											linkFromRow_Individual.addProperty(objectProLink, linkToColumn_Individual);
										} else if (relationship != null && relationship != "") {
											ObjectProperty objectProLink = ontModel
													.createObjectProperty(METAG + relationship);
											linkFromRow_Individual.addProperty(objectProLink, linkToColumn_Individual);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
