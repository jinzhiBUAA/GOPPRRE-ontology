package org.fc.mdt.owl.karma2owl;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.eclipse.core.resources.IProject;

public class BFO2Owl {
	public static void generateBFO(IProject metagProject, OntModel ontModel) {
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";

		// 1.先创建框架
		// 1.1框架中的类
		OntClass owlEntityClass = ontModel.createClass(METAG + "entity");
		OntClass owlContinuantClass = ontModel.createClass(METAG + "continuant");
		owlEntityClass.addSubClass(owlContinuantClass);
		OntClass owlGdcClass = ontModel.createClass(METAG + "generically_dependent_continuant");
		owlContinuantClass.addSubClass(owlGdcClass);
		OntClass owlIctClass = ontModel.createClass(METAG + "Information_Content_Entity");
		owlGdcClass.addSubClass(owlIctClass);
		OntClass owlDescriptiveIceClass = ontModel.createClass(METAG + "Descriptive_Information_Content_Entity");
		owlIctClass.addSubClass(owlDescriptiveIceClass);
		OntClass owlDesignativeIceClass = ontModel.createClass(METAG + "Designative_Information_Content_Entity");
		owlIctClass.addSubClass(owlDesignativeIceClass);
		OntClass owlDirectiveIceClass = ontModel.createClass(METAG + "Directive_Information_Content_Entity");
		owlIctClass.addSubClass(owlDirectiveIceClass);
		OntClass owlKarmaClass = ontModel.createClass(METAG + "KARMA"); 
		owlDirectiveIceClass.addSubClass(owlKarmaClass);
		OntClass owlDSMClass = ontModel.createClass(METAG + "DSM");
		owlDirectiveIceClass.addSubClass(owlDSMClass);
		OntClass owlActionSpecificationClass = ontModel.createClass(METAG + "Action_Specification");
		owlDirectiveIceClass.addSubClass(owlActionSpecificationClass);
		OntClass owlManufacturingStepSpecificationClass = ontModel
				.createClass(METAG + "Manufacturing_Step_Specification");
		owlActionSpecificationClass.addSubClass(owlManufacturingStepSpecificationClass);
		OntClass owlObjectivespecificationClass = ontModel.createClass(METAG + "Objective_specification");
		owlDirectiveIceClass.addSubClass(owlObjectivespecificationClass);
		OntClass owlPlanSpecificationClass = ontModel.createClass(METAG + "Plan_Specification");
		owlDirectiveIceClass.addSubClass(owlPlanSpecificationClass);
		OntClass owlManufacturingOperationSpecificationClass = ontModel
				.createClass(METAG + "Manufacturing_Operation_Specification");
		owlPlanSpecificationClass.addSubClass(owlManufacturingOperationSpecificationClass);
		OntClass owlManufacturingProcessPlanClass = ontModel.createClass(METAG + "Manufacturing_Process_Plan");
		owlPlanSpecificationClass.addSubClass(owlManufacturingProcessPlanClass);
		OntClass owlTaskDescriptionClass = ontModel.createClass(METAG + "Task_Description");
		owlPlanSpecificationClass.addSubClass(owlTaskDescriptionClass);
		OntClass owlProductDesignClass = ontModel.createClass(METAG + "Product_Design");
		owlDirectiveIceClass.addSubClass(owlProductDesignClass);
		OntClass owlRequirementClass = ontModel.createClass(METAG + "BFO_Requirement");
		owlDirectiveIceClass.addSubClass(owlRequirementClass);
		OntClass owlReqIFClass = ontModel.createClass(METAG + "ReqIF");
		owlRequirementClass.addSubClass(owlReqIFClass);
		OntClass owlProductRequirementClass = ontModel.createClass(METAG + "Product_Requirement");
		owlRequirementClass.addSubClass(owlProductRequirementClass);
		OntClass owlSpecificationClass = ontModel.createClass(METAG + "Specification");
		owlDirectiveIceClass.addSubClass(owlSpecificationClass);
		OntClass owlQualitySpecificationClass = ontModel.createClass(METAG + "Quality_Specification");
		owlSpecificationClass.addSubClass(owlQualitySpecificationClass);
		OntClass owlIndependentContinuantClass = ontModel.createClass(METAG + "independent_continuant");
		owlContinuantClass.addSubClass(owlIndependentContinuantClass);
		OntClass owlImmaterialEntityClass = ontModel.createClass(METAG + "immaterial_entity");
		owlIndependentContinuantClass.addSubClass(owlImmaterialEntityClass);
		OntClass owlContinuantFiatBoundaryClass = ontModel.createClass(METAG + "continuant_fiat_boundary");
		owlImmaterialEntityClass.addSubClass(owlContinuantFiatBoundaryClass);
		OntClass owlFiatLineClass = ontModel.createClass(METAG + "fiat_line");
		owlContinuantFiatBoundaryClass.addSubClass(owlFiatLineClass);
		OntClass owlFiatPointClass = ontModel.createClass(METAG + "fiat_point");
		owlContinuantFiatBoundaryClass.addSubClass(owlFiatPointClass);
		OntClass owlFiatSurfaceClass = ontModel.createClass(METAG + "fiat_surface");
		owlContinuantFiatBoundaryClass.addSubClass(owlFiatSurfaceClass);
		OntClass owlSiteClass = ontModel.createClass(METAG + "site");
		owlImmaterialEntityClass.addSubClass(owlSiteClass);
		OntClass owlSpatialRegionClass = ontModel.createClass(METAG + "spatial_region");
		owlImmaterialEntityClass.addSubClass(owlSpatialRegionClass);
		OntClass owlOnedimensionalSpatialRegionClass = ontModel.createClass(METAG + "one_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlOnedimensionalSpatialRegionClass);
		OntClass owlThreedimensionalSpatialRegionClass = ontModel
				.createClass(METAG + "three_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlThreedimensionalSpatialRegionClass);
		OntClass owlTwodimensionalSpatialRegionClass = ontModel.createClass(METAG + "two_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlTwodimensionalSpatialRegionClass);
		OntClass owlZerodimensionalSpatialRegionClass = ontModel.createClass(METAG + "zero_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlZerodimensionalSpatialRegionClass);
		OntClass owlMaterialEntityClass = ontModel.createClass(METAG + "material_entity");
		owlIndependentContinuantClass.addSubClass(owlMaterialEntityClass);
		OntClass owlAgentClass = ontModel.createClass(METAG + "Agent");
		owlMaterialEntityClass.addSubClass(owlAgentClass);
		OntClass owlCustomerClass = ontModel.createClass(METAG + "Customer");
		owlAgentClass.addSubClass(owlCustomerClass);
		OntClass owlProspectiveCustomerClass = ontModel.createClass(METAG + "Prospective_Customer");
		owlAgentClass.addSubClass(owlProspectiveCustomerClass);
		OntClass owlSupplierClass = ontModel.createClass(METAG + "Supplier");
		owlAgentClass.addSubClass(owlSupplierClass);
		OntClass owlComponentClass = ontModel.createClass(METAG + "Component");
		owlMaterialEntityClass.addSubClass(owlComponentClass);
		OntClass owlFiatObjectPartClass = ontModel.createClass(METAG + "fiat_object_part");
		owlMaterialEntityClass.addSubClass(owlFiatObjectPartClass);
		OntClass owlObjectClass = ontModel.createClass(METAG + "BFO_object");
		owlMaterialEntityClass.addSubClass(owlObjectClass);
		OntClass owlMaterialArtifactClass = ontModel.createClass(METAG + "Material_Artifact");
		owlObjectClass.addSubClass(owlMaterialArtifactClass);
		OntClass owlAssemblyClass = ontModel.createClass(METAG + "Assembly");
		owlMaterialArtifactClass.addSubClass(owlAssemblyClass);
		OntClass owlMachineClass = ontModel.createClass(METAG + "Machine");
		owlMaterialArtifactClass.addSubClass(owlMachineClass);
		OntClass owlManufacturingMachineClass = ontModel.createClass(METAG + "Manufacturing_Machine");
		owlMachineClass.addSubClass(owlManufacturingMachineClass);
		OntClass owlPieceofEquipmentClass = ontModel.createClass(METAG + "Piece_of_Equipment");
		owlMaterialArtifactClass.addSubClass(owlPieceofEquipmentClass);
		OntClass owlPieceofManufacturingEquipmentClass = ontModel
				.createClass(METAG + "Piece_of_Manufacturing_Equipment");
		owlPieceofEquipmentClass.addSubClass(owlPieceofManufacturingEquipmentClass);
		OntClass owlToolClass = ontModel.createClass(METAG + "Tool");
		owlMaterialArtifactClass.addSubClass(owlToolClass);
		OntClass owlManufacturingToolClass = ontModel.createClass(METAG + "Manufacturing_Tool");
		owlToolClass.addSubClass(owlManufacturingToolClass);
		OntClass owlOrganismClass = ontModel.createClass(METAG + "Organism");
		owlObjectClass.addSubClass(owlOrganismClass);
		OntClass owlPersonClass = ontModel.createClass(METAG + "Person");
		owlOrganismClass.addSubClass(owlPersonClass);
		OntClass owlObjectAggregateClass = ontModel.createClass(METAG + "object_aggregate");
		owlMaterialEntityClass.addSubClass(owlObjectAggregateClass);
		OntClass owlGroupofAgentsClass = ontModel.createClass(METAG + "Group_of_Agents");
		owlObjectAggregateClass.addSubClass(owlGroupofAgentsClass);
		OntClass owlOrganizationClass = ontModel.createClass(METAG + "Organization");
		owlGroupofAgentsClass.addSubClass(owlOrganizationClass);
		OntClass owlBusinessOrganizationClass = ontModel.createClass(METAG + "Business_Organization");
		owlOrganizationClass.addSubClass(owlBusinessOrganizationClass);
		OntClass owlManufacturingBusinessClass = ontModel.createClass(METAG + "Manufacturing_Business");
		owlBusinessOrganizationClass.addSubClass(owlManufacturingBusinessClass);
		OntClass owlSystemClass = ontModel.createClass(METAG + "BFO_System");
		owlObjectAggregateClass.addSubClass(owlSystemClass);
		OntClass owlEngineeredSystemClass = ontModel.createClass(METAG + "Engineered_System");
		owlSystemClass.addSubClass(owlEngineeredSystemClass);
		OntClass owlManufacturedSystemClass = ontModel.createClass(METAG + "Manufactured_System");
		owlEngineeredSystemClass.addSubClass(owlManufacturedSystemClass);
		OntClass owlMechanicalSystemClass = ontModel.createClass(METAG + "Mechanical_System");
		owlEngineeredSystemClass.addSubClass(owlMechanicalSystemClass);
		OntClass owlPortionofInputMaterialClass = ontModel.createClass(METAG + "Portion_of_Input_Material");
		owlMaterialEntityClass.addSubClass(owlPortionofInputMaterialClass);
		OntClass owlProductClass = ontModel.createClass(METAG + "Product");
		owlContinuantClass.addSubClass(owlProductClass);
		OntClass owlManufacturedProductClass = ontModel.createClass(METAG + "Manufactured_Product");
		owlProductClass.addSubClass(owlManufacturedProductClass);
		OntClass owlResourceClass = ontModel.createClass(METAG + "Resource");
		owlContinuantClass.addSubClass(owlResourceClass);
		OntClass owlHumanResourceClass = ontModel.createClass(METAG + "Human_Resource");
		owlResourceClass.addSubClass(owlHumanResourceClass);
		OntClass owlIntangibleResourceClass = ontModel.createClass(METAG + "Intangible_Resource");
		owlResourceClass.addSubClass(owlIntangibleResourceClass);
		OntClass owlMaterialResourceClass = ontModel.createClass(METAG + "Material_Resource");
		owlResourceClass.addSubClass(owlMaterialResourceClass);
		OntClass owlSpecificallyDependentContinuantClass = ontModel
				.createClass(METAG + "specifically_dependent_continuant");
		owlContinuantClass.addSubClass(owlSpecificallyDependentContinuantClass);
		OntClass owlqualityClass = ontModel.createClass(METAG + "quality");
		owlSpecificallyDependentContinuantClass.addSubClass(owlqualityClass);
		OntClass owlRelationalQualityClass = ontModel.createClass(METAG + "relational_quality");
		owlqualityClass.addSubClass(owlRelationalQualityClass);
		OntClass owlRealizableEntityClass = ontModel.createClass(METAG + "realizable_entity");
		owlSpecificallyDependentContinuantClass.addSubClass(owlRealizableEntityClass);
		OntClass owlDispositionClass = ontModel.createClass(METAG + "disposition");
		owlRealizableEntityClass.addSubClass(owlDispositionClass);
		OntClass owlCapabilityClass = ontModel.createClass(METAG + "Capability");
		owlDispositionClass.addSubClass(owlCapabilityClass);
		OntClass owlFunctionClass = ontModel.createClass(METAG + "BFO_function");
		owlDispositionClass.addSubClass(owlFunctionClass);
		OntClass owlIntentionClass = ontModel.createClass(METAG + "Intention");
		owlDispositionClass.addSubClass(owlIntentionClass);
		OntClass owlRoleClass = ontModel.createClass(METAG + "BFO_role");
		owlRealizableEntityClass.addSubClass(owlRoleClass);
		OntClass owlComponentRoleClass = ontModel.createClass(METAG + "Component_Role");
		owlRoleClass.addSubClass(owlComponentRoleClass);
		OntClass owlCustomerRoleClass = ontModel.createClass(METAG + "CustomerRole");
		owlRoleClass.addSubClass(owlCustomerRoleClass);
		OntClass owlInputMaterialRoleClass = ontModel.createClass(METAG + "Input_Material_Role");
		owlRoleClass.addSubClass(owlInputMaterialRoleClass);
		OntClass owlRawMaterialRoleClass = ontModel.createClass(METAG + "Raw_Material_Role");
		owlInputMaterialRoleClass.addSubClass(owlRawMaterialRoleClass);
		OntClass owlProductRoleClass = ontModel.createClass(METAG + "Product_Role");
		owlRoleClass.addSubClass(owlProductRoleClass);
		OntClass owlProspectiveCustomerRoleClass = ontModel.createClass(METAG + "Prospective_Customer_Role");
		owlRoleClass.addSubClass(owlProspectiveCustomerRoleClass);
		OntClass owlResourceRoleClass = ontModel.createClass(METAG + "Resource_Role");
		owlRoleClass.addSubClass(owlResourceRoleClass);
		OntClass owlManufacturingResourceRoleClass = ontModel.createClass(METAG + "Manufacturing_Resource_Role");
		owlResourceRoleClass.addSubClass(owlManufacturingResourceRoleClass);
		OntClass owlSupplierRoleClass = ontModel.createClass(METAG + "Supplier_Role");
		owlRoleClass.addSubClass(owlSupplierRoleClass);

		OntClass owlOccurrentClass = ontModel.createClass(METAG + "occurrent");
		owlEntityClass.addSubClass(owlOccurrentClass);
		OntClass owlProcessClass = ontModel.createClass(METAG + "BFO_process");
		owlOccurrentClass.addSubClass(owlProcessClass);
		OntClass owlAgentiveProcessClass = ontModel.createClass(METAG + "Agentive_Process");
		owlProcessClass.addSubClass(owlAgentiveProcessClass);
		OntClass owlPlannedProcessClass = ontModel.createClass(METAG + "Planned_Process");
		owlAgentiveProcessClass.addSubClass(owlPlannedProcessClass);
		OntClass owlAssemblyProcessClass = ontModel.createClass(METAG + "Assembly_Process");
		owlPlannedProcessClass.addSubClass(owlAssemblyProcessClass);
		OntClass owlBusinessProcessClass = ontModel.createClass(METAG + "Business_Process");
		owlPlannedProcessClass.addSubClass(owlBusinessProcessClass);
		OntClass owlManufacturingEnterpriseProcessClass = ontModel
				.createClass(METAG + "Manufacturing_Enterprise_Process");
		owlBusinessProcessClass.addSubClass(owlManufacturingEnterpriseProcessClass);
		OntClass owlProductProductionProcessClass = ontModel.createClass(METAG + "Product_Production_Process");
		owlManufacturingEnterpriseProcessClass.addSubClass(owlProductProductionProcessClass);
		OntClass owlManufacturingOperationClass = ontModel.createClass(METAG + "Manufacturing_Operation");
		owlPlannedProcessClass.addSubClass(owlManufacturingOperationClass);
		OntClass owlManufacturingProcessClass = ontModel.createClass(METAG + "Manufacturing_Process");
		owlPlannedProcessClass.addSubClass(owlManufacturingProcessClass);
		OntClass owlAssemblyLineProcessClass = ontModel.createClass(METAG + "Assembly_Line_Process");
		owlManufacturingProcessClass.addSubClass(owlAssemblyLineProcessClass);
		OntClass owlTaskClass = ontModel.createClass(METAG + "Task");
		owlPlannedProcessClass.addSubClass(owlTaskClass);
		OntClass owlStepClass = ontModel.createClass(METAG + "Step");
		owlTaskClass.addSubClass(owlStepClass);
		OntClass owlTransportProcessClass = ontModel.createClass(METAG + "Transport_Process");
		owlPlannedProcessClass.addSubClass(owlTransportProcessClass);
		OntClass owlHistoryClass = ontModel.createClass(METAG + "history");
		owlProcessClass.addSubClass(owlHistoryClass);
		OntClass owlProcessProfileClass = ontModel.createClass(METAG + "process_profile");
		owlProcessClass.addSubClass(owlProcessProfileClass);
		OntClass owlProcessAggregateClass = ontModel.createClass(METAG + "Process_Aggregate");
		owlOccurrentClass.addSubClass(owlProcessAggregateClass);
		OntClass owlManufacturingOperationsClass = ontModel.createClass(METAG + "Manufacturing_Operations");
		owlProcessAggregateClass.addSubClass(owlManufacturingOperationsClass);
		OntClass owlProcessHistoryClass = ontModel.createClass(METAG + "ProcessHistory");
		owlProcessAggregateClass.addSubClass(owlProcessHistoryClass);
		OntClass owlProcessBoundaryClass = ontModel.createClass(METAG + "process_boundary");
		owlOccurrentClass.addSubClass(owlProcessBoundaryClass);
		OntClass owlSpatiotemporalRegionClass = ontModel.createClass(METAG + "spatiotemporal_region");
		owlOccurrentClass.addSubClass(owlSpatiotemporalRegionClass);
		OntClass owlTemporalRegionClass = ontModel.createClass(METAG + "temporal_region");
		owlOccurrentClass.addSubClass(owlTemporalRegionClass);
		OntClass owlOnedimensionalTemporalRegionClass = ontModel.createClass(METAG + "one_dimensional_temporal_region");
		owlTemporalRegionClass.addSubClass(owlOnedimensionalTemporalRegionClass);
		OntClass owlTemporalIntervalClass = ontModel.createClass(METAG + "temporal_interval");
		owlOnedimensionalTemporalRegionClass.addSubClass(owlTemporalIntervalClass);
		OntClass owlZerodimensionalTemporalRegionClass = ontModel
				.createClass(METAG + "zero_dimensional_temporal_region");
		owlTemporalRegionClass.addSubClass(owlZerodimensionalTemporalRegionClass);
		OntClass owlTemporalInstantClass = ontModel.createClass(METAG + "temporal_instant");
		owlZerodimensionalTemporalRegionClass.addSubClass(owlTemporalInstantClass);

		OntClass owlZzzDeprecatedClass = ontModel.createClass(METAG + "zzzDeprecated");
		OntClass owlFeatureClass = ontModel.createClass(METAG + "BFO_Feature");
		owlZzzDeprecatedClass.addSubClass(owlFeatureClass);
		OntClass owlFeatureDescriptionClass = ontModel.createClass(METAG + "FeatureDescription");
		owlZzzDeprecatedClass.addSubClass(owlFeatureDescriptionClass);
		OntClass owlManufacturingResourceClass = ontModel.createClass(METAG + "ManufacturingResource");
		owlZzzDeprecatedClass.addSubClass(owlManufacturingResourceClass);
		OntClass owlMaterialHandlingResourceClass = ontModel.createClass(METAG + "Material_Handling_Resource");
		owlZzzDeprecatedClass.addSubClass(owlMaterialHandlingResourceClass);
		OntClass owlMeasuredProductQualityClass = ontModel
				.createClass(METAG + "Measured_Product_Quality（to_be_deprecated）");
		owlZzzDeprecatedClass.addSubClass(owlMeasuredProductQualityClass);

		// 用于表示文件与文件内的关系
		ObjectProperty objectProOwn = ontModel.createObjectProperty(METAG + "own");

		// 1.2框架中的AnnotationProperty
		AnnotationProperty annotationProcontributor = ontModel.createAnnotationProperty(METAG + "dc:contributor");
		AnnotationProperty annotationProidentifier = ontModel.createAnnotationProperty(METAG + "dc:identifier");
		AnnotationProperty annotationProdclicense = ontModel.createAnnotationProperty(METAG + "dc:license");
		AnnotationProperty annotationProdescription = ontModel.createAnnotationProperty(METAG + "dcterms:description");
		AnnotationProperty annotationProdctermslicense = ontModel.createAnnotationProperty(METAG + "dcterms:license");
		AnnotationProperty annotationPropublisher = ontModel.createAnnotationProperty(METAG + "dcterms:publisher");
		AnnotationProperty annotationProrights = ontModel.createAnnotationProperty(METAG + "dcterms:rights");
		AnnotationProperty annotationProCopyright = ontModel.createAnnotationProperty(METAG + "Copyright");
		annotationProCopyright.addSuperProperty(annotationProrights);
		AnnotationProperty annotationProtitle = ontModel.createAnnotationProperty(METAG + "dcterms:title");
		AnnotationProperty annotationProMaintainer = ontModel.createAnnotationProperty(METAG + "Maintainer");
		AnnotationProperty annotationPronote = ontModel.createAnnotationProperty(METAG + "note");
		AnnotationProperty annotationProdefinition = ontModel.createAnnotationProperty(METAG + "definition");
		annotationProdefinition.addSuperProperty(annotationPronote);
		AnnotationProperty annotationProElucidation = ontModel.createAnnotationProperty(METAG + "Elucidation");
		annotationProElucidation.addSuperProperty(annotationProdefinition);
		AnnotationProperty annotationProLogicDefinition = ontModel.createAnnotationProperty(METAG + "Logic_Definition");
		annotationProLogicDefinition.addSuperProperty(annotationProdefinition);
		AnnotationProperty annotationProFirstOrderLogicDefinition = ontModel
				.createAnnotationProperty(METAG + "First_Order_Logic_Definition");
		annotationProFirstOrderLogicDefinition.addSuperProperty(annotationProLogicDefinition);
		AnnotationProperty annotationProSemiFormalNaturalLanguageDefinition = ontModel
				.createAnnotationProperty(METAG + "Semi_Formal_Natural_Language_Definition");
		annotationProSemiFormalNaturalLanguageDefinition.addSuperProperty(annotationProLogicDefinition);
		AnnotationProperty annotationProNaturalLanguageDefinition = ontModel
				.createAnnotationProperty(METAG + "Natural_Language_Definition");
		annotationProNaturalLanguageDefinition.addSuperProperty(annotationProdefinition);
		AnnotationProperty annotationProexample = ontModel.createAnnotationProperty(METAG + "example");
		annotationProexample.addSuperProperty(annotationPronote);
		AnnotationProperty annotationProexplanatorynote = ontModel.createAnnotationProperty(METAG + "explanatory_note");
		annotationProexplanatorynote.addSuperProperty(annotationPronote);
		AnnotationProperty annotationProusagenote = ontModel.createAnnotationProperty(METAG + "usage_note");
		annotationProusagenote.addSuperProperty(annotationPronote);
		AnnotationProperty annotationProbackwardCompatibleWith = ontModel
				.createAnnotationProperty(METAG + "owl:backwardCompatibleWith");
		AnnotationProperty annotationProdeprecated = ontModel.createAnnotationProperty(METAG + "owl:deprecated");
		AnnotationProperty annotationProincompatibleWith = ontModel
				.createAnnotationProperty(METAG + "owl:incompatibleWith");
		AnnotationProperty annotationPropriorVersion = ontModel.createAnnotationProperty(METAG + "owl:priorVersion");
		AnnotationProperty annotationProversionInfo = ontModel.createAnnotationProperty(METAG + "owl:versionInfo");
		AnnotationProperty annotationProcomment = ontModel.createAnnotationProperty(METAG + "comment");
		AnnotationProperty annotationProisDefinedBy = ontModel.createAnnotationProperty(METAG + "rdfs:isDefinedBy");
		AnnotationProperty annotationProlabel = ontModel.createAnnotationProperty(METAG + "rdfs:label");
		AnnotationProperty annotationProAlternativeLabelIdentifier = ontModel
				.createAnnotationProperty(METAG + "Alternative_Label_Identifier");
		annotationProAlternativeLabelIdentifier.addSuperProperty(annotationProlabel);
		AnnotationProperty annotationProSynonym = ontModel.createAnnotationProperty(METAG + "Synonym");
		annotationProSynonym.addSuperProperty(annotationProAlternativeLabelIdentifier);
		AnnotationProperty annotationProAbbreviation = ontModel.createAnnotationProperty(METAG + "Abbreviation");
		annotationProAbbreviation.addSuperProperty(annotationProSynonym);
		AnnotationProperty annotationProAcronym = ontModel.createAnnotationProperty(METAG + "Acronym");
		annotationProAcronym.addSuperProperty(annotationProAbbreviation);
		AnnotationProperty annotationProSymbol = ontModel.createAnnotationProperty(METAG + "Symbol");
		annotationProSymbol.addSuperProperty(annotationProAbbreviation);
		AnnotationProperty annotationProseeAlso = ontModel.createAnnotationProperty(METAG + "rdfs:seeAlso");
		AnnotationProperty annotationProRelationToBasicFormalOntologyElement = ontModel
				.createAnnotationProperty(METAG + "Relation_To_Basic_Formal_Ontology_Element");
		AnnotationProperty annotationProprefLabel = ontModel.createAnnotationProperty(METAG + "skos:prefLabel");
		AnnotationProperty annotationProscopeNote = ontModel.createAnnotationProperty(METAG + "skos:scopeNote");
		AnnotationProperty annotationProSource = ontModel.createAnnotationProperty(METAG + "Source");
		AnnotationProperty annotationProAdaptedFrom = ontModel.createAnnotationProperty(METAG + "Adapted_From");
		annotationProAdaptedFrom.addSuperProperty(annotationProSource);
		AnnotationProperty annotationProDirectSource = ontModel.createAnnotationProperty(METAG + "Direct_Source");
		annotationProDirectSource.addSuperProperty(annotationProSource);
		AnnotationProperty annotationProExcerptedFrom = ontModel.createAnnotationProperty(METAG + "Excerpted_From");
		annotationProExcerptedFrom.addSuperProperty(annotationProSource);
		AnnotationProperty annotationProxdefinitionsothercommon = ontModel
				.createAnnotationProperty(METAG + "x_definitions_other_common");
		AnnotationProperty annotationProxexamplescomplement = ontModel
				.createAnnotationProperty(METAG + "x_examples_complement");
		AnnotationProperty annotationProxexamplescounter = ontModel
				.createAnnotationProperty(METAG + "x_examplescounter");
		AnnotationProperty annotationProxunresolvedissues = ontModel
				.createAnnotationProperty(METAG + "x_unresolved_issues");

		// 1.3框架中的ObjectProperty
		ObjectProperty objectPro2Dboundaryof = ontModel.createObjectProperty(METAG + "2D_boundary_of");
		ObjectProperty objectProachieves = ontModel.createObjectProperty(METAG + "achieves");
		ObjectProperty objectProcauses = ontModel.createObjectProperty(METAG + "causes");
		ObjectProperty objectProconcretizesatsometime = ontModel
				.createObjectProperty(METAG + "concretizes_at_some_time");
		ObjectProperty objectProconcretizesatalltimes = ontModel
				.createObjectProperty(METAG + "concretizes_at_all_times");
		objectProconcretizesatalltimes.addSuperProperty(objectProconcretizesatalltimes);
		ObjectProperty objectProcontinuantpartofatsometime = ontModel
				.createObjectProperty(METAG + "continuant_part_of_at_some_time");
		ObjectProperty objectProcontinuantpartofatalltimes = ontModel
				.createObjectProperty(METAG + "continuant_part_of_at_all_times");
		objectProcontinuantpartofatalltimes.addSuperProperty(objectProcontinuantpartofatsometime);
		ObjectProperty objectPromemberpartofatalltimes = ontModel
				.createObjectProperty(METAG + "member_part_of_at_all_times");
		objectPromemberpartofatalltimes.addSuperProperty(objectProcontinuantpartofatalltimes);
		ObjectProperty objectPropropercontinuantpartofatalltimes = ontModel
				.createObjectProperty(METAG + "proper_continuant_part_of_at_all_times");
		objectPropropercontinuantpartofatalltimes.addSuperProperty(objectProcontinuantpartofatalltimes);
		ObjectProperty objectPromemberpartofatsometime = ontModel
				.createObjectProperty(METAG + "member_part_of_at_some_time");
		objectPromemberpartofatsometime.addSuperProperty(objectProcontinuantpartofatsometime);
		ObjectProperty objectPromemberpartofatalltimes1 = ontModel
				.createObjectProperty(METAG + "member_part_of_at_all_times");
		objectPromemberpartofatalltimes1.addSuperProperty(objectPromemberpartofatsometime);
		ObjectProperty objectPropropercontinuantpartofatsometime = ontModel
				.createObjectProperty(METAG + "proper_continuant_part_of_at_some_time");
		objectPropropercontinuantpartofatsometime.addSuperProperty(objectProcontinuantpartofatsometime);
		ObjectProperty objectPropropercontinuantpartofatalltimes1 = ontModel
				.createObjectProperty(METAG + "proper_continuant_part_of_at_all_times");
		objectPropropercontinuantpartofatalltimes1.addSuperProperty(objectPropropercontinuantpartofatsometime);
		ObjectProperty objectProenvirons = ontModel.createObjectProperty(METAG + "environs");
		ObjectProperty objectProexistsat = ontModel.createObjectProperty(METAG + "exists_at");
		ObjectProperty objectProfirstinstantof = ontModel.createObjectProperty(METAG + "first_instant_of");
		ObjectProperty objectProgenericallydependsonatsometime = ontModel
				.createObjectProperty(METAG + "generically_depends_on_at_some_time");
		ObjectProperty objectProgenericallydependsonatalltimes = ontModel
				.createObjectProperty(METAG + "generically_depends_on_at_all_times");
		objectProgenericallydependsonatalltimes.addSuperProperty(objectProgenericallydependsonatsometime);
		ObjectProperty objectProhas2Dboundary = ontModel.createObjectProperty(METAG + "has_2D_boundary");
		ObjectProperty objectProhascontinuantpartatsometime = ontModel
				.createObjectProperty(METAG + "has_continuant_part_at_some_time");
		ObjectProperty objectProhascontinuantpartatalltimes = ontModel
				.createObjectProperty(METAG + "has_continuant_part_at_all_times");
		objectProhascontinuantpartatalltimes.addSuperProperty(objectProhascontinuantpartatsometime);
		ObjectProperty objectProhasmemberpartatalltimes = ontModel
				.createObjectProperty(METAG + "has_member_part_at_all_times");
		objectProhasmemberpartatalltimes.addSuperProperty(objectProhascontinuantpartatalltimes);
		ObjectProperty objectProhaspropercontinuantpartatalltimes = ontModel
				.createObjectProperty(METAG + "has_proper_continuant_part_at_all_times");
		objectProhaspropercontinuantpartatalltimes.addSuperProperty(objectProhascontinuantpartatalltimes);
		ObjectProperty objectProhasmemberpartatsometime = ontModel
				.createObjectProperty(METAG + "has_member_part_at_some_time");
		objectProhasmemberpartatsometime.addSuperProperty(objectProhascontinuantpartatsometime);
		ObjectProperty objectProhasmemberpartatalltimes1 = ontModel
				.createObjectProperty(METAG + "has_member_part_at_all_times");
		objectProhasmemberpartatalltimes1.addSuperProperty(objectProhasmemberpartatsometime);
		ObjectProperty objectProhaspropercontinuantpartatsometime = ontModel
				.createObjectProperty(METAG + "has_proper_continuant_part_at_some_time");
		objectProhaspropercontinuantpartatsometime.addSuperProperty(objectProhascontinuantpartatsometime);
		ObjectProperty objectProhaspropercontinuantpartatalltimes1 = ontModel
				.createObjectProperty(METAG + "has_proper_continuant_part_at_all_times");
		objectProhaspropercontinuantpartatalltimes1.addSuperProperty(objectProhaspropercontinuantpartatsometime);
		ObjectProperty objectProhasfirstinstant = ontModel.createObjectProperty(METAG + "has_first_instant");
		ObjectProperty objectProhashistory = ontModel.createObjectProperty(METAG + "has_history");
		ObjectProperty objectProhaslastinstant = ontModel.createObjectProperty(METAG + "has_last_instant");
		ObjectProperty objectProhasmaterialbasisatsometime = ontModel
				.createObjectProperty(METAG + "has_material_basis_at_some_time");
		ObjectProperty objectProhasmaterialbasisatalltimes = ontModel
				.createObjectProperty(METAG + "has_material_basis_at_all_times");
		objectProhasmaterialbasisatalltimes.addSuperProperty(objectProhasmaterialbasisatsometime);
		ObjectProperty objectProhasoccurrentpart = ontModel.createObjectProperty(METAG + "has_occurrent_part");
		ObjectProperty objectProhasproperoccurrentpart = ontModel
				.createObjectProperty(METAG + "has_proper_occurrent_part");
		objectProhasproperoccurrentpart.addSuperProperty(objectProhasoccurrentpart);
		ObjectProperty objectProhastemporalpart = ontModel.createObjectProperty(METAG + "has_temporal_part");
		objectProhastemporalpart.addSuperProperty(objectProhasoccurrentpart);
		ObjectProperty objectProhaspropertemporalpart = ontModel
				.createObjectProperty(METAG + "has_proper_temporal_part");
		objectProhaspropertemporalpart.addSuperProperty(objectProhastemporalpart);
		ObjectProperty objectProhasparticipantatsometime = ontModel
				.createObjectProperty(METAG + "has_participant_at_some_time");
		ObjectProperty objectProhasinputatsometime = ontModel.createObjectProperty(METAG + "has_input_at_some_time");
		objectProhasinputatsometime.addSuperProperty(objectProhasparticipantatsometime);
		ObjectProperty objectProhasoutputatsometime = ontModel.createObjectProperty(METAG + "has_output_at_some_time");
		objectProhasoutputatsometime.addSuperProperty(objectProhasparticipantatsometime);
		ObjectProperty objectProhasparticipantatalltimes = ontModel
				.createObjectProperty(METAG + "has_participant_at_all_times");
		objectProhasparticipantatalltimes.addSuperProperty(objectProhasparticipantatsometime);
		ObjectProperty objectProhasrealization = ontModel.createObjectProperty(METAG + "has_realization");
		ObjectProperty objectProhistoryof = ontModel.createObjectProperty(METAG + "history_of");
		ObjectProperty objectProintentionof = ontModel.createObjectProperty(METAG + "intention_of");
		ObjectProperty objectProisabout = ontModel.createObjectProperty(METAG + "is_about");
		ObjectProperty objectProdescribes = ontModel.createObjectProperty(METAG + "describes");
		objectProdescribes.addSuperProperty(objectProisabout);
		ObjectProperty objectProdesignates = ontModel.createObjectProperty(METAG + "designates");
		objectProdesignates.addSuperProperty(objectProisabout);
		ObjectProperty objectProprescribes = ontModel.createObjectProperty(METAG + "prescribes");
		objectProprescribes.addSuperProperty(objectProisabout);
		ObjectProperty objectProspecifies = ontModel.createObjectProperty(METAG + "specifies");
		objectProspecifies.addSuperProperty(objectProprescribes);
		ObjectProperty objectProisavailableto = ontModel.createObjectProperty(METAG + "is_available_to");
		ObjectProperty objectProiscarrierofatsometime = ontModel
				.createObjectProperty(METAG + "is_carrier_of_at_some_time");
		ObjectProperty objectProiscarrierofatalltimes = ontModel
				.createObjectProperty(METAG + "is_carrier_of_at_all_times");
		objectProiscarrierofatalltimes.addSuperProperty(objectProiscarrierofatsometime);
		ObjectProperty objectProisconcretizedbyatsometime = ontModel
				.createObjectProperty(METAG + "is_concretized_by_at_some_time");
		ObjectProperty objectProisconcretizedbyatalltimes = ontModel
				.createObjectProperty(METAG + "is_concretized_by_at_all_times");
		objectProisconcretizedbyatalltimes.addSuperProperty(objectProisconcretizedbyatsometime);
		ObjectProperty objectProissubjectof = ontModel.createObjectProperty(METAG + "is_subject_of");
		ObjectProperty objectProdescribedby = ontModel.createObjectProperty(METAG + "described_by");
		objectProdescribedby.addSuperProperty(objectProissubjectof);
		ObjectProperty objectProdesignatedby = ontModel.createObjectProperty(METAG + "designated_by");
		objectProdesignatedby.addSuperProperty(objectProissubjectof);
		ObjectProperty objectProprescribedby = ontModel.createObjectProperty(METAG + "prescribed_by");
		objectProprescribedby.addSuperProperty(objectProissubjectof);
		ObjectProperty objectProisusedin = ontModel.createObjectProperty(METAG + "is_used_in");
		ObjectProperty objectProlastinstantof = ontModel.createObjectProperty(METAG + "last_instant_of");
		ObjectProperty objectProlocatedin = ontModel.createObjectProperty(METAG + "located_in");
		ObjectProperty objectProlocatedinatsometime = ontModel.createObjectProperty(METAG + "located_in_at_some_time");
		ObjectProperty objectProlocatedinatalltimes = ontModel.createObjectProperty(METAG + "located_in_at_all_times");
		objectProlocatedinatalltimes.addSuperProperty(objectProlocatedinatsometime);
		ObjectProperty objectProlocatedof = ontModel.createObjectProperty(METAG + "located_of");
		ObjectProperty objectProlocatedinofsometime = ontModel.createObjectProperty(METAG + "located_of_at_some_time");
		ObjectProperty objectProlocatedofatalltimes = ontModel.createObjectProperty(METAG + "located_of_at_all_times");
		objectProlocatedofatalltimes.addSuperProperty(objectProlocatedinofsometime);
		ObjectProperty objectPromaterialbasisofatsometime = ontModel
				.createObjectProperty(METAG + "material_basis_of_at_some_time");
		ObjectProperty objectPromaterialbasisofatalltimes = ontModel
				.createObjectProperty(METAG + "material_basis_of_at_all_times");
		objectPromaterialbasisofatalltimes.addSuperProperty(objectPromaterialbasisofatsometime);
		ObjectProperty objectProoccupiesspatialregionatsometime = ontModel
				.createObjectProperty(METAG + "occupies_spatial_region_at_some_time");
		ObjectProperty objectProoccupiesspatialregionatalltimes = ontModel
				.createObjectProperty(METAG + "occupies_spatial_region_at_all_times");
		objectProoccupiesspatialregionatalltimes.addSuperProperty(objectProoccupiesspatialregionatsometime);
		ObjectProperty objectProoccupiesspatiotemporalregion = ontModel
				.createObjectProperty(METAG + "occupies_spatiotemporal_region");
		ObjectProperty objectProoccupiestemporalregion = ontModel
				.createObjectProperty(METAG + "occupies_temporal_region");
		ObjectProperty objectProoccurrentpartof = ontModel.createObjectProperty(METAG + "occurrent_part_of");
		ObjectProperty objectProproperoccurrentpartof = ontModel
				.createObjectProperty(METAG + "proper_occurrent_part_of");
		objectProproperoccurrentpartof.addSuperProperty(objectProoccurrentpartof);
		ObjectProperty objectProtemporalpartof = ontModel.createObjectProperty(METAG + "temporal_part_of");
		objectProtemporalpartof.addSuperProperty(objectProoccurrentpartof);
		ObjectProperty objectPropropertemporalpartof = ontModel.createObjectProperty(METAG + "proper_temporal_part_of");
		objectPropropertemporalpartof.addSuperProperty(objectProtemporalpartof);
		ObjectProperty objectProoccursin = ontModel.createObjectProperty(METAG + "occurs_in");
		ObjectProperty objectProparticipatesinatsometime = ontModel
				.createObjectProperty(METAG + "participates_in_at_some_time");
		ObjectProperty objectProhasagent = ontModel.createObjectProperty(METAG + "has_agent");
		objectProhasagent.addSuperProperty(objectProparticipatesinatsometime);
		ObjectProperty objectProisinputofatsometime = ontModel.createObjectProperty(METAG + "is_input_of_at_some_time");
		objectProisinputofatsometime.addSuperProperty(objectProparticipatesinatsometime);
		ObjectProperty objectProisoutputofatsometime = ontModel
				.createObjectProperty(METAG + "is_output_of_at_some_time");
		objectProisoutputofatsometime.addSuperProperty(objectProparticipatesinatsometime);
		ObjectProperty objectProparticipatesinatalltimes = ontModel
				.createObjectProperty(METAG + "participates_in_at_all_times");
		objectProparticipatesinatalltimes.addSuperProperty(objectProparticipatesinatsometime);
		ObjectProperty objectProprecededby = ontModel.createObjectProperty(METAG + "preceded_by");
		ObjectProperty objectProprecedes = ontModel.createObjectProperty(METAG + "precedes");
		ObjectProperty objectProrealizes = ontModel.createObjectProperty(METAG + "realizes");
		ObjectProperty objectProspatiallyprojectsontoatsometime = ontModel
				.createObjectProperty(METAG + "spatially_projects_onto_at_some_time");
		ObjectProperty objectProspatiallyprojectsontoatalltimes = ontModel
				.createObjectProperty(METAG + "spatially_projects_onto_at_all_times");
		objectProspatiallyprojectsontoatalltimes.addSuperProperty(objectProspatiallyprojectsontoatsometime);
		ObjectProperty objectProspecificallydependedonby = ontModel
				.createObjectProperty(METAG + "specifically_depended_on_by");
		ObjectProperty objectProbearerof = ontModel.createObjectProperty(METAG + "bearer_of");
		objectProbearerof.addSuperProperty(objectProspecificallydependedonby);
		ObjectProperty objectProhasdisposition = ontModel.createObjectProperty(METAG + "has_disposition");
		objectProhasdisposition.addSuperProperty(objectProbearerof);
		ObjectProperty objectProhasfunction = ontModel.createObjectProperty(METAG + "has_function");
		objectProhasfunction.addSuperProperty(objectProbearerof);
		ObjectProperty objectProhasquality = ontModel.createObjectProperty(METAG + "has_quality");
		objectProhasquality.addSuperProperty(objectProbearerof);
		ObjectProperty objectProhasrole = ontModel.createObjectProperty(METAG + "has_role");
		objectProhasrole.addSuperProperty(objectProbearerof);
		ObjectProperty objectProspecificallydependson = ontModel
				.createObjectProperty(METAG + "specifically_depends_on");
		ObjectProperty objectProinheresin = ontModel.createObjectProperty(METAG + "inheres_in");
		objectProinheresin.addSuperProperty(objectProspecificallydependson);
		ObjectProperty objectProdispositionof = ontModel.createObjectProperty(METAG + "disposition_of");
		objectProdispositionof.addSuperProperty(objectProinheresin);
		ObjectProperty objectProfunctionof = ontModel.createObjectProperty(METAG + "function_of");
		objectProfunctionof.addSuperProperty(objectProinheresin);
		ObjectProperty objectProqualityof = ontModel.createObjectProperty(METAG + "quality_of");
		objectProqualityof.addSuperProperty(objectProinheresin);
		ObjectProperty objectProroleof = ontModel.createObjectProperty(METAG + "role_of");
		objectProroleof.addSuperProperty(objectProinheresin);
		ObjectProperty objectProtemporallyprojectsonto = ontModel
				.createObjectProperty(METAG + "temporally_projects_onto");
		ObjectProperty objectProtriggers = ontModel.createObjectProperty(METAG + "triggers");
		ObjectProperty objectProEqual =ontModel.createObjectProperty(METAG + "equal_to");

	}
}
