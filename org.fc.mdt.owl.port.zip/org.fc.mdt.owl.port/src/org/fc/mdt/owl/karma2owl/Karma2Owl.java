package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

import org.antlr.runtime.tree.ParseTree;
import org.apache.commons.lang3.StringUtils;
import org.apache.jena.ontology.AllValuesFromRestriction;
import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.DatatypeProperty;
import org.apache.jena.ontology.HasValueRestriction;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.IntersectionClass;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.SomeValuesFromRestriction;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.vocabulary.XSD;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.fc.mdt.core.karma.ds.node.GraphObject;
import org.fc.mdt.core.karma.ds.node.MetaGraph;
import org.fc.mdt.core.karma.ds.node.MetaObject;
import org.fc.mdt.core.karma.ds.node.MetaPoint;
import org.fc.mdt.core.karma.ds.node.MetaProperty;
import org.fc.mdt.core.karma.ds.node.MetaRelationship;
import org.fc.mdt.core.karma.ds.node.MetaRole;
import org.fc.mdt.core.karma.ds.node.Model;
import org.fc.mdt.core.karma.ds.node.Packages;
import org.fc.mdt.core.karma.ds.node.PackagesImport;
import org.fc.mdt.core.karma.ds.node.Point;
import org.fc.mdt.core.karma.ds.node.Relationship;
import org.fc.mdt.core.karma.ds.node.Role;
import org.fc.mdt.core.karma.ds.node.references.Gantt;
import org.fc.mdt.core.karma.ds.node.references.GanttTask;
import org.fc.mdt.core.karma.ds.node.references.GanttTaskElement;
import org.fc.mdt.core.karma.ds.node.references.ImportPackage;
import org.fc.mdt.core.karma.ds.node.references.Matrix;
import org.fc.mdt.core.karma.ds.node.references.MetaPointTypeReference;
import org.fc.mdt.core.karma.ds.node.references.MetaPropertyTypeReference;
import org.fc.mdt.core.karma.ds.node.references.PropertyTypeReference;
import org.fc.mdt.core.karma.ds.node.references.SwimLane;
import org.fc.mdt.core.karma.ds.node.references.Text;
import org.fc.mdt.core.karma.ds.utils.GraphType;
import org.fc.mdt.core.karma.ds.utils.RoutingStyle;
import org.fc.mdt.core.karma.ds.node.references.Layout;
import org.fc.mdt.core.karma.parser.compiler.KarmaCompilerManager;
import org.fc.mdt.core.karma.parser.error.KarmaCompilationError;
import org.fc.mdt.core.karma.parser.node.MetaGraphAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.node.MetaObjectAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.node.MetaPointAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.node.MetaPropertyAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.node.MetaRelationshipAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.node.MetaRoleAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.node.ModelAntlr4SubVisitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;
import org.fc.mdt.core.utils.issues.IProblem;
import org.fc.mdt.core.utils.issues.ProblemImpl;
import org.fc.mdt.core.utils.issues.ReportProblem;
import org.fc.mdt.core.utils.log.console.MdtLogConsole;
import org.fc.mdt.core.utils.log.console.MdtLogConsoleFactory;
import org.fc.mdt.owl.port.messages.Messages;
import org.fc.mdt.core.karma.parser.util.KarmaParseUtil;

public class Karma2Owl {
	private static MdtLogConsole console = MdtLogConsoleFactory.getInstance().getConsole();

	public static void generateKarma(IProject metagProject, OntModel ontModel, boolean isBFO) throws Exception {
		IFolder karmaFolder = null;
		IFolder karmaFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder karmaFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (karmaFolder1.exists()) {
			karmaFolder = karmaFolder1;
		} else if (karmaFolder2.exists()) {
			karmaFolder = karmaFolder2;
		}
		// 先写owl一些必要的基本信息
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		// owl元元模型
		OntClass owlProjectClass = ontModel.createClass(METAG + "Project");
		OntClass owlIconClass = ontModel.createClass(METAG + "Icon");
		OntClass owlImageClass = ontModel.createClass(METAG + "Image");
		OntClass owlLangugeClass = ontModel.createClass(METAG + "Language");
		OntClass owlGraphClass = ontModel.createClass(METAG + "Graph");
		OntClass owlObjectClass = ontModel.createClass(METAG + "Object");
		OntClass owlPropertyClass = ontModel.createClass(METAG + "Property");
		OntClass owlPointClass = ontModel.createClass(METAG + "Point");
		OntClass owlRelationshipClass = ontModel.createClass(METAG + "Relationship");
		OntClass owlRoleClass = ontModel.createClass(METAG + "Role");
		OntClass owlconnectorClass = ontModel.createClass(METAG + "Connector");
		OntClass owlFunctionClass = ontModel.createClass(METAG + "Function");
		OntClass owlpluginClass = ontModel.createClass(METAG + "Plugin");
		OntClass owlPackagesClass = ontModel.createClass(METAG + "Packages");
		if (isBFO) {
			OntClass owlKarmaClass = ontModel.getOntClass(METAG + "KARMA");
			owlKarmaClass.addSubClass(owlProjectClass);
			owlKarmaClass.addSubClass(owlLangugeClass);
			owlKarmaClass.addSubClass(owlGraphClass);
			owlKarmaClass.addSubClass(owlObjectClass);
			owlKarmaClass.addSubClass(owlPropertyClass);
			owlKarmaClass.addSubClass(owlPointClass);
			owlKarmaClass.addSubClass(owlRelationshipClass);
			owlKarmaClass.addSubClass(owlRoleClass);
			owlKarmaClass.addSubClass(owlconnectorClass);
			owlKarmaClass.addSubClass(owlFunctionClass);
			owlKarmaClass.addSubClass(owlpluginClass);
			owlKarmaClass.addSubClass(owlPackagesClass);
			owlKarmaClass.addSubClass(owlIconClass);
			owlKarmaClass.addSubClass(owlImageClass);
		}

		OntClass owlSwimLaneClass = ontModel.createClass(METAG + "SwimLane");
		OntClass owlSysMLClass = ontModel.createClass(METAG + "SysMLDrawingComponent");
		OntClass owlGanttClass = ontModel.createClass(METAG + "Gantt");
		OntClass owlMatrixClass = ontModel.createClass(METAG + "Matrix");
		owlSwimLaneClass.addSuperClass(owlpluginClass);
		owlSysMLClass.addSuperClass(owlpluginClass);
		owlGanttClass.addSuperClass(owlpluginClass);
		owlMatrixClass.addSuperClass(owlpluginClass);
		OntClass owlGanttElementClass = ontModel.createClass(METAG + "GanttElement");
		OntClass owlGanttTaskClass = ontModel.createClass(METAG + "GanttTask");
		owlGanttElementClass.addSuperClass(owlGanttClass);
		owlGanttTaskClass.addSuperClass(owlGanttClass);

		// 创建CIF annotaiton property
		AnnotationProperty annotationPropertygroupPart = ontModel.createAnnotationProperty(METAG + "groupPart");
		AnnotationProperty annotationPropertylocationPart = ontModel.createAnnotationProperty(METAG + "locationPart");
		AnnotationProperty annotationPropertyedgePart = ontModel.createAnnotationProperty(METAG + "edgePart");
		AnnotationProperty annotationPropertyautomatonPart = ontModel.createAnnotationProperty(METAG + "automatonPart");
		AnnotationProperty annotationPropertySVGPart = ontModel.createAnnotationProperty(METAG + "SVGPart");
		AnnotationProperty annotationPropertyExternalFunctionDeclarePart = ontModel
				.createAnnotationProperty(METAG + "ExternalFunctionDeclarePart");

		// 创建annotaiton property
		AnnotationProperty annotationPropertyColor = ontModel.createAnnotationProperty(METAG + "color");// color的annotation
		AnnotationProperty annotationPropertyfillColor = ontModel.createAnnotationProperty(METAG + "fillColor");
		AnnotationProperty annotationPropertylineColor = ontModel.createAnnotationProperty(METAG + "lineColor");
		AnnotationProperty annotationPropertytextColor = ontModel.createAnnotationProperty(METAG + "textColor");
		annotationPropertyfillColor.addSuperProperty(annotationPropertyColor);
		annotationPropertylineColor.addSuperProperty(annotationPropertyColor);
		annotationPropertytextColor.addSuperProperty(annotationPropertyColor);
		AnnotationProperty annotationPropertyDescription = ontModel.createAnnotationProperty(METAG + "description");
		AnnotationProperty annotationPropertyLocalLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationPropertyTableType = ontModel.createAnnotationProperty(METAG + "tableType");// 20221118加
		AnnotationProperty annotationPropertyDirection = ontModel.createAnnotationProperty(METAG + "direction");
		AnnotationProperty annotationPropertyIcon = ontModel.createAnnotationProperty(METAG + "icon");
		AnnotationProperty annotationPropertyIconAddress = ontModel.createAnnotationProperty(METAG + "iconAddress");
		AnnotationProperty annotationPropertyIconSize = ontModel.createAnnotationProperty(METAG + "iconSize");
		annotationPropertyIconAddress.addSuperProperty(annotationPropertyIcon);
		annotationPropertyIconSize.addSuperProperty(annotationPropertyIcon);
		AnnotationProperty annotationPropertyImageAddress = ontModel.createAnnotationProperty(METAG + "imageAddress");
		AnnotationProperty annotationPropertyinitialLocation = ontModel
				.createAnnotationProperty(METAG + "initialLocation");
		AnnotationProperty annotationPropertylableDisplay = ontModel.createAnnotationProperty(METAG + "lableDisplay");
		AnnotationProperty annotationPropertyMatrix = ontModel.createAnnotationProperty(METAG + "matrix");
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");
		AnnotationProperty annotationPropertyEndLocation = ontModel.createAnnotationProperty(METAG + "endLocation");
		AnnotationProperty annotationPropertyRoutingType = ontModel.createAnnotationProperty(METAG + "routingType");
		AnnotationProperty annotationPropertylStartLocation = ontModel
				.createAnnotationProperty(METAG + "startLocation");
		AnnotationProperty annotationPropertyModelSize = ontModel.createAnnotationProperty(METAG + "modelSize");
		AnnotationProperty annotationPropertyPolyLineLocation = ontModel
				.createAnnotationProperty(METAG + "polyLineLocation");
		AnnotationProperty annotationPropertyLayerLocation = ontModel.createAnnotationProperty(METAG + "layerLocation");
		// SysML增加
		AnnotationProperty annotationPropertyModelElementName = ontModel
				.createAnnotationProperty(METAG + "modelElementName");
		AnnotationProperty annotationPropertyModelElementType = ontModel
				.createAnnotationProperty(METAG + "modelElementType");
		AnnotationProperty annotationPropertyDiagramKind = ontModel.createAnnotationProperty(METAG + "diagramKind");

		annotationPropertyEndLocation.addSuperProperty(annotationPropertyModelLocation);
		annotationPropertylStartLocation.addSuperProperty(annotationPropertyModelLocation);
		annotationPropertyModelSize.addSuperProperty(annotationPropertyModelLocation);
		annotationPropertyPolyLineLocation.addSuperProperty(annotationPropertyModelLocation);
		annotationPropertyLayerLocation.addSuperProperty(annotationPropertyModelLocation);
		AnnotationProperty annotationPropertyScreenMode = ontModel.createAnnotationProperty(METAG + "screenMode");
		AnnotationProperty annotationPropertyShape = ontModel.createAnnotationProperty(METAG + "shape");
		AnnotationProperty annotationPropertyTime = ontModel.createAnnotationProperty(METAG + "time");
		AnnotationProperty annotationPropertydataType = ontModel.createAnnotationProperty(METAG + "dataType");
		AnnotationProperty annotationPropertyunit = ontModel.createAnnotationProperty(METAG + "unit");
		AnnotationProperty annotationPropertyCifString = ontModel.createAnnotationProperty(METAG + "cifString");
		AnnotationProperty annotationPropertyStyle = ontModel.createAnnotationProperty(METAG + "style");
		AnnotationProperty annotationPropertyInitial = ontModel.createAnnotationProperty(METAG + "initial");
		AnnotationProperty annotationPropertyType = ontModel.createAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPropertyText = ontModel.createAnnotationProperty(METAG + "text");
		AnnotationProperty annotationPropertyIconDisplay = ontModel.createAnnotationProperty(METAG + "iconDisplay");
		AnnotationProperty annotationPropertyFrameSize = ontModel.createAnnotationProperty(METAG + "frameSize");
		AnnotationProperty annotationPropertyLineType = ontModel.createAnnotationProperty(METAG + "linetype");
		AnnotationProperty annotationPropertySdIdentification = ontModel
				.createAnnotationProperty(METAG + "SdIdentification");
		AnnotationProperty annotationPropertySmoothness = ontModel.createAnnotationProperty(METAG + "smoothness");// 2020927加
		AnnotationProperty annotationPropertyAvoidObstructionsRouting = ontModel
				.createAnnotationProperty(METAG + "avoidObstructionsRouting");// 2020927加
		AnnotationProperty annotationPropertyClosestDistanceRouting = ontModel
				.createAnnotationProperty(METAG + "closestDistanceRouting");// 2020927加
		AnnotationProperty annotationPropertyJumpLinkStatus = ontModel
				.createAnnotationProperty(METAG + "jumpLinkStatus");// 2020927加
		AnnotationProperty annotationPropertyJumpLinkType = ontModel.createAnnotationProperty(METAG + "jumpLinkType");// 2020927加
		AnnotationProperty annotationPropertyReverseJumpLink = ontModel
				.createAnnotationProperty(METAG + "reverseJumpLink");// 2020927加

		AnnotationProperty annotationPropertyQueue = ontModel.createAnnotationProperty(METAG + "queue");

		AnnotationProperty annotationPropertyId = ontModel.createAnnotationProperty(METAG + "id");

		// 20220629加
		AnnotationProperty annotationPropertyUnderline = ontModel.createAnnotationProperty(METAG + "underline");
		AnnotationProperty annotationPropertyStrikethrough = ontModel.createAnnotationProperty(METAG + "strikeThrough");
		// 20221129
		AnnotationProperty annotationPropertyUnfoldDirection = ontModel
				.createAnnotationProperty(METAG + "UnfoldDirection");
		// 20230927
		AnnotationProperty annotationPropertyVisualizationList = ontModel
				.createAnnotationProperty(METAG + "VisualizationList");
		// 创建obj property
		ObjectProperty projectIncludingLanguageProp = ontModel.createObjectProperty(METAG + "projectIncludingLanguage");
		ObjectProperty bindingProp = ontModel.createObjectProperty(METAG + "binding");
		ObjectProperty RoleBindingObjectProp = ontModel.createObjectProperty(METAG + "roleBindingObject");
		RoleBindingObjectProp.addSuperProperty(bindingProp);
		ObjectProperty RoleBindingPointProp = ontModel.createObjectProperty(METAG + "roleBindingPoint");
		RoleBindingPointProp.addSuperProperty(bindingProp);
		ObjectProperty connectProp = ontModel.createObjectProperty(METAG + "connect");
		ObjectProperty hasPropertyProp = ontModel.createObjectProperty(METAG + "hasProperty");

		ObjectProperty includingProp = ontModel.createObjectProperty(METAG + "including");
		ObjectProperty graphIncludingConnectorProp = ontModel.createObjectProperty(METAG + "graphIncludingConnector");
		graphIncludingConnectorProp.addSuperProperty(includingProp);
		ObjectProperty graphIncludingORRProp = ontModel.createObjectProperty(METAG + "graphIncludingORR");
		ObjectProperty graphIncludingObjectProp = ontModel.createObjectProperty(METAG + "graphIncludingObject");
		ObjectProperty graphIncludingRelationshipProp = ontModel
				.createObjectProperty(METAG + "graphIncludingRelationship");
		ObjectProperty graphIncludingRoleProp = ontModel.createObjectProperty(METAG + "graphIncludingRole");
		graphIncludingORRProp.addSuperProperty(includingProp);
		graphIncludingObjectProp.addSuperProperty(graphIncludingORRProp);
		graphIncludingRelationshipProp.addSuperProperty(graphIncludingORRProp);
		graphIncludingRoleProp.addSuperProperty(graphIncludingORRProp);
		ObjectProperty graphIncludingPluginProp = ontModel.createObjectProperty(METAG + "graphIncludingPlugin");
		ObjectProperty pluginIncludingTaskProp = ontModel.createObjectProperty(METAG + "pluginIncludingTask");
		ObjectProperty taskIncludingElementprop = ontModel.createObjectProperty(METAG + "taskIncludingElement");
		pluginIncludingTaskProp.addSuperProperty(graphIncludingPluginProp);
		taskIncludingElementprop.addSuperProperty(graphIncludingPluginProp);
		graphIncludingPluginProp.addSuperProperty(includingProp);

		ObjectProperty languageIncludingGOPPRRProp = ontModel.createObjectProperty(METAG + "languageIncludingGOPPRR");
		ObjectProperty languageIncludingGraphProp = ontModel.createObjectProperty(METAG + "languageIncludingGraph");
		ObjectProperty languageIncludingObjectProp = ontModel.createObjectProperty(METAG + "languageIncludingObject");
		ObjectProperty languageIncludingPointProp = ontModel.createObjectProperty(METAG + "languageIncludingPoint");
		ObjectProperty languageIncludingRelationshipProp = ontModel
				.createObjectProperty(METAG + "languageIncludingRelationship");
		ObjectProperty languageIncludingRoleProp = ontModel.createObjectProperty(METAG + "languageIncludingRole");
		ObjectProperty languageIncludingPropertyProp = ontModel
				.createObjectProperty(METAG + "languageIncludingProperty");
		ObjectProperty languageIncludingPackagesProp = ontModel
				.createObjectProperty(METAG + "languageIncludingPackages");
		languageIncludingGOPPRRProp.addSuperProperty(includingProp);
		languageIncludingGraphProp.addSuperProperty(languageIncludingGOPPRRProp);
		languageIncludingObjectProp.addSuperProperty(languageIncludingGOPPRRProp);
		languageIncludingPointProp.addSuperProperty(languageIncludingGOPPRRProp);
		languageIncludingRelationshipProp.addSuperProperty(languageIncludingGOPPRRProp);
		languageIncludingRoleProp.addSuperProperty(languageIncludingGOPPRRProp);
		languageIncludingPropertyProp.addSuperProperty(languageIncludingGOPPRRProp);
		projectIncludingLanguageProp.addSuperProperty(includingProp);
		languageIncludingPackagesProp.addSuperProperty(includingProp);

		ObjectProperty mappingProp = ontModel.createObjectProperty(METAG + "mapping");
		ObjectProperty decomposeProp = ontModel.createObjectProperty(METAG + "decompose");
		ObjectProperty explodeProp = ontModel.createObjectProperty(METAG + "explode");
		decomposeProp.addSuperProperty(mappingProp);
		explodeProp.addSuperProperty(mappingProp);
		ObjectProperty decomposePointConnectObjectProp = ontModel
				.createObjectProperty(METAG + "decomposePointConnectObject");
		ObjectProperty decomposePointConnectPointProp = ontModel
				.createObjectProperty(METAG + "decomposePointConnectPoint");
		decomposePointConnectObjectProp.addSuperProperty(decomposeProp);
		decomposePointConnectPointProp.addSuperProperty(decomposeProp);
		ObjectProperty LinkProp = ontModel.createObjectProperty(METAG + "link");
		ObjectProperty linkFromRelationshipProp = ontModel.createObjectProperty(METAG + "linkFromRelationship");
		ObjectProperty linkObjectAndPointProp = ontModel.createObjectProperty(METAG + "linkObjectAndPoint");
		ObjectProperty linkRelationshipAndRoleProp = ontModel.createObjectProperty(METAG + "linkRelationshipAndRole");
		ObjectProperty linkToObjectProp = ontModel.createObjectProperty(METAG + "linkToObject");
		linkFromRelationshipProp.addSuperProperty(LinkProp);
		linkObjectAndPointProp.addSuperProperty(LinkProp);
		linkRelationshipAndRoleProp.addSuperProperty(LinkProp);
		linkToObjectProp.addSuperProperty(LinkProp);
		ObjectProperty extendProp = ontModel.createObjectProperty(METAG + "extend");// 20240103add Graph继承
		// Package 增加Model的相关ObjectProperty
		ObjectProperty hasModelProp = ontModel.createObjectProperty(METAG + "hasModel");
		ObjectProperty hasPackageProp = ontModel.createObjectProperty(METAG + "hasPackage");
		// Clone增加Model的相关ObjectProperty
		ObjectProperty cloneModelProp = ontModel.createObjectProperty(METAG + "cloneModel");
		ObjectProperty cloneObjectProp = ontModel.createObjectProperty(METAG + "cloneObject");
		ObjectProperty clonePointProp = ontModel.createObjectProperty(METAG + "clonePoint");
		ObjectProperty clonePropertyProp = ontModel.createObjectProperty(METAG + "cloneProperty");
		// DataProperty
		DatatypeProperty pointDirection = ontModel.createDatatypeProperty(METAG + "pointDirection");// 创建data属性,等价类中描述点的方向
		pointDirection.addDomain(owlPointClass);
		pointDirection.addRange(XSD.xstring);
		DatatypeProperty value = ontModel.createDatatypeProperty(METAG + "value");// 创建data属性，主要描述属性的值
		value.addDomain(owlPropertyClass);
		value.addRange(XSD.xstring);

		// -----------------------------------------------------//
		// -----------------------------------------------------//
		// ----------------------开始读karma--------------------//
		// -----------------------------------------------------//
		// -----------------------------------------------------//

		// ----------------------icons----------------------//2022.06.07加
		IFolder iconsFolder = null;
		IFolder iconsFolder1 = metagProject.getFolder(PackagePath.TYPE_ICONS);
		IFolder iconsFolder2 = metagProject.getFolder(PackagePath.TYPE_ICONS_ZH);
		if (iconsFolder1.exists()) {
			iconsFolder = iconsFolder1;
		} else if (iconsFolder2.exists()) {
			iconsFolder = iconsFolder2;
		}
		AnnotationProperty annotationPropertyIconPath = ontModel.createAnnotationProperty(METAG + "iconPath");
		try {
			for (IResource f : iconsFolder.members()) {
				String path = f.getLocation().toOSString();
				String iconIndividualID = UUID.randomUUID().toString();
				Individual owlIconIndividual = owlIconClass.createIndividual(METAG + iconIndividualID);
				owlIconIndividual.addProperty(annotationPropertyIconPath, path);
				owlIconIndividual.addProperty(annotationPropertyLocalLabel, f.getName());
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		// ----------------------images----------------------//2022.06.07加
		IFolder imagesFolder = null;
		IFolder imagesFolder1 = metagProject.getFolder(PackagePath.TYPE_IMAGES);
		IFolder imagesFolder2 = metagProject.getFolder(PackagePath.TYPE_IMAGES_ZH);
		if (imagesFolder1.exists()) {
			imagesFolder = imagesFolder1;
		} else if (imagesFolder2.exists()) {
			imagesFolder = imagesFolder2;
		}
		AnnotationProperty annotationPropertyImagesPath = ontModel.createAnnotationProperty(METAG + "imagePath");
		try {
			for (IResource f : imagesFolder.members()) {
				String path = f.getLocation().toOSString();
				String imageIndividualID = UUID.randomUUID().toString();
				Individual owlImageIndividual = owlImageClass.createIndividual(METAG + imageIndividualID);
				owlImageIndividual.addProperty(annotationPropertyImagesPath, path);
				owlImageIndividual.addProperty(annotationPropertyLocalLabel, f.getName());
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		// ----------------------Project项目----------------------//2022.06.07加
		// 项目修改显示id
		// 判断有没有id
		String projectId = SaveKarInformation.getProjectId(metagProject);
		if (projectId != null && projectId.length() > 0) {
			OntClass owlProject = ontModel.createClass(METAG + projectId);
			owlProject.addSuperClass(owlProjectClass);
			owlProject.addProperty(annotationPropertyId, projectId);
			owlProject.addProperty(annotationPropertyLocalLabel, metagProject.getProject().getName());
		} else {
			OntClass owlProject = ontModel.createClass(METAG + metagProject.getProject().getName());
			owlProject.addSuperClass(owlProjectClass);
			owlProject.addProperty(annotationPropertyId, projectId);
		}

		// ----------------------语言----------------------//
		try {
			// IFolder karmaFolder = metagProject.getFolder("languages");
			for (IResource fileLanguage : karmaFolder.members()) {
				if (fileLanguage.getType() == IResource.FOLDER) {
					IFolder languageFolder = (IFolder) fileLanguage;
					// 修改显示语言id
					OntClass owlLanguage;
					String languageId = SaveKarInformation.getLanguageId(languageFolder);
					if (languageId != null && languageId.length() > 0) {
						owlLanguage = ontModel.createClass(METAG + languageId);
						owlLanguage.addSuperClass(owlLangugeClass);
						owlLanguage.addProperty(annotationPropertyId, languageId);
						owlLanguage.addProperty(annotationPropertyLocalLabel, fileLanguage.getName());
					} else {
						owlLanguage = ontModel.createClass(METAG + fileLanguage.getName());
						owlLanguage.addSuperClass(owlLangugeClass);
					}

					// ----------------------属性元模型----------------------//
					IFolder filemetaProperty = null;
					IFolder filemetaProperty1 = (IFolder) languageFolder
							.findMember("/" + PackagePath.TYPE_METAPROPERTY);
					IFolder filemetaProperty2 = (IFolder) languageFolder
							.findMember("/" + PackagePath.TYPE_METAPROPERTY_ZH);
					if (filemetaProperty1 != null) {
						filemetaProperty = filemetaProperty1;
					} else if (filemetaProperty2 != null) {
						filemetaProperty = filemetaProperty2;
					}
					for (IResource f : filemetaProperty.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();
							MetaProperty metaProperty = KarmaCompilerManager.parseMetaPropertyById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							List<KarmaCompilationError> errors = KarmaCompilerManager.getErrors(packagePath, path);
							List<IProblem> problemList = new ArrayList<IProblem>();
							for (KarmaCompilationError error : errors) {
								if (error != null) {
									IProblem fatalProblem = new ProblemImpl(error.getLine() + 1, error.getMessage(),
											filePath);
									problemList.add(fatalProblem);
								}
							}
							if (problemList.size() != 0) {
								ReportProblem.getInstance().doReport(problemList);
							}
							// 生成属性元模型
							// 20220802加控制台报错
							for (Iterator It = ontModel.listClasses(); It.hasNext();) {
								OntClass classExist = (OntClass) It.next();
								if (classExist.getLocalName() != null
										&& metaProperty.getId().equals(classExist.getLocalName())) {
									console.printError(Messages.getValue("ExportWizardPage_owlExportError")
											+ Messages.getValue("duplicateMetaPropertyID") + metaProperty.getId());
								}
							}
							OntClass owlmetaProperty = ontModel.createClass(METAG + metaProperty.getId());
							owlmetaProperty.addSuperClass(owlPropertyClass);

							// 属性元模型 annotation
							owlmetaProperty.addProperty(annotationPropertyLocalLabel, metaProperty.getLocalLabel()); // LocalLabel
							owlmetaProperty.addProperty(annotationPropertydataType,
									metaProperty.getDataType().toString()); // dataType
							if (metaProperty.getUnit() != null) {
								owlmetaProperty.addProperty(annotationPropertyunit, metaProperty.getUnit().toString()); // unit
							}
							if (metaProperty.getDescription() != null && !metaProperty.getDescription().equals("")) {
								owlmetaProperty.addProperty(annotationPropertyDescription,
										metaProperty.getDescription()); // Description
							}
							owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
									languageIncludingPropertyProp, owlmetaProperty));
						}
					}
					System.out.println("===属性元模型成功===");

					// ----------------------点元模型----------------------//
					IFolder filemetaPoint = null;
					IFolder filemetaPoint1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAPOINT);
					IFolder filemetaPoint2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAPOINT_ZH);
					if (filemetaPoint1 != null) {
						filemetaPoint = filemetaPoint1;
					} else if (filemetaPoint2 != null) {
						filemetaPoint = filemetaPoint2;
					}
					for (IResource f : filemetaPoint.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();
							MetaPoint metaPoint = KarmaCompilerManager.parseMetaPointById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							List<KarmaCompilationError> errors = KarmaCompilerManager.getErrors(packagePath, path);
							List<IProblem> problemList = new ArrayList<IProblem>();
							for (KarmaCompilationError error : errors) {
								if (error != null) {
									IProblem fatalProblem = new ProblemImpl(error.getLine() + 1, error.getMessage(),
											filePath);
									problemList.add(fatalProblem);
								}
							}
							if (problemList.size() != 0) {
								ReportProblem.getInstance().doReport(problemList);
							}
							// 生成点元模型
							// 20220802加控制台报错
							for (Iterator It = ontModel.listClasses(); It.hasNext();) {
								OntClass classExist = (OntClass) It.next();
								if (classExist.getLocalName() != null
										&& metaPoint.getId().equals(classExist.getLocalName())) {
									console.printError(Messages.getValue("ExportWizardPage_owlExportError")
											+ Messages.getValue("duplicateMetaPointID") + metaPoint.getId());
								}
							}
							OntClass owlMetaPoint = ontModel.createClass(METAG + metaPoint.getId());
							owlMetaPoint.addSuperClass(owlPointClass);

							// 点元模型 annotation
							owlMetaPoint.addProperty(annotationPropertyLocalLabel, metaPoint.getLocalLabel()); // LocalLabel
							if (metaPoint.getDescription() != null && !metaPoint.getDescription().equals("")) {
								owlMetaPoint.addProperty(annotationPropertyDescription, metaPoint.getDescription()); // Description
							}
							owlMetaPoint.addProperty(annotationPropertyShape, metaPoint.getPointShape().toString()); // Shape

							// 点元模型 property
							for (MetaPropertyTypeReference ref : metaPoint.getProperties()) {
								// 20220802加控制台报错
								for (Iterator It = ontModel.listClasses(); It.hasNext();) {
									OntClass classExist = (OntClass) It.next();
									if (classExist.getLocalName() != null
											&& ref.getId().equals(classExist.getLocalName())) {
										console.printError(Messages.getValue("ExportWizardPage_owlExportError")
												+ Messages.getValue("duplicateMetaPointRefMetaPropertyID")
												+ ref.getId());
									}
								}
								OntClass owMetaPointProperty = ontModel.createClass(METAG + ref.getId());
								owMetaPointProperty.addProperty(annotationPropertyLocalLabel, ref.getLocalLabel());
								OntClass owlMetaProperty = ontModel.getOntClass(METAG + ref.getMetaProperty().getId());
								owMetaPointProperty.addSuperClass(owlMetaProperty);

								if (ref.isUnique()) {
									AllValuesFromRestriction pointHasProperty = ontModel
											.createAllValuesFromRestriction(null, hasPropertyProp, owMetaPointProperty); // some
									owlMetaPoint.addEquivalentClass(pointHasProperty);
								} else {
									SomeValuesFromRestriction pointHasProperty = ontModel
											.createSomeValuesFromRestriction(null, hasPropertyProp,
													owMetaPointProperty); // some
									owlMetaPoint.addEquivalentClass(pointHasProperty);
								}

							}
							owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
									languageIncludingPointProp, owlMetaPoint));
						}
					}
					System.out.println("===点元模型成功===");

					// ----------------------对象元模型----------------------//
					IFolder filemetaObject = null;
					IFolder filemetaObject1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAOBJECT);
					IFolder filemetaObject2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAOBJECT_ZH);
					if (filemetaObject1 != null) {
						filemetaObject = filemetaObject1;
					} else if (filemetaObject2 != null) {
						filemetaObject = filemetaObject2;
					}
					for (IResource f : filemetaObject.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();
							MetaObject metaObject = KarmaCompilerManager.parseMetaObjectById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							List<KarmaCompilationError> errors = KarmaCompilerManager.getErrors(packagePath, path);
							List<IProblem> problemList = new ArrayList<IProblem>();
							for (KarmaCompilationError error : errors) {
								if (error != null) {
									IProblem fatalProblem = new ProblemImpl(error.getLine() + 1, error.getMessage(),
											filePath);
									problemList.add(fatalProblem);
								}
							}
							if (problemList.size() != 0) {
								ReportProblem.getInstance().doReport(problemList);
							}
							// 生成对象元模型
							// 20220802加控制台报错
							for (Iterator It = ontModel.listClasses(); It.hasNext();) {
								OntClass classExist = (OntClass) It.next();
								if (classExist.getLocalName() != null
										&& metaObject.getId().equals(classExist.getLocalName())) {
									console.printError(Messages.getValue("ExportWizardPage_owlExportError")
											+ Messages.getValue("duplicateMetaObjectID") + metaObject.getId());
								}
							}
							OntClass owlMetaObject = ontModel.createClass(METAG + metaObject.getId());
							owlMetaObject.addSuperClass(owlObjectClass);

							// 对象元模型 annotation
							owlMetaObject.addProperty(annotationPropertyLocalLabel, metaObject.getLocalLabel()); // LocalLabel
							if (metaObject.getDescription() != null && !metaObject.getDescription().equals("")) {
								owlMetaObject.addProperty(annotationPropertyDescription, metaObject.getDescription()); // Description
							}
							if (metaObject.getIconPath() != null) {
								if (!metaObject.getIconPath().equals("")) {
									owlMetaObject.addProperty(annotationPropertyIcon, metaObject.getIconPath()); // Icon
								}
							}
							owlMetaObject.addProperty(annotationPropertyShape, metaObject.getObjectShape().toString()); // Shape
							owlMetaObject.addProperty(annotationPropertyScreenMode, metaObject.getMode().toString());// visualizedMode
							// 20220606加
							if (metaObject.getImage() != null) {
								if (!metaObject.getImage().equals("")) {
									owlMetaObject.addProperty(annotationPropertyImageAddress, metaObject.getImage()); // ImageAddress
								}
							}
							//
							// 20221129UnfoldDirection
							if (metaObject.getDirection().equals(metaObject.getDirection().X)) {
								System.out.println(
										metaObject.getMode().toString() + "" + metaObject.getDirection().X.toString());
								owlMetaObject.addProperty(annotationPropertyUnfoldDirection,
										metaObject.getDirection().X.toString());
							}
							if (metaObject.getDirection().equals(metaObject.getDirection().Y)) {
								System.out.println(
										metaObject.getMode().toString() + "" + metaObject.getDirection().Y.toString());
								owlMetaObject.addProperty(annotationPropertyUnfoldDirection,
										metaObject.getDirection().Y.toString());
							}
							//

							// 对象元模型 property
							for (MetaPropertyTypeReference ref : metaObject.getProperties()) {
								// 20220802加控制台报错
								for (Iterator It = ontModel.listClasses(); It.hasNext();) {
									OntClass classExist = (OntClass) It.next();
									if (classExist.getLocalName() != null
											&& ref.getId().equals(classExist.getLocalName())) {
										console.printError(Messages.getValue("ExportWizardPage_owlExportError")
												+ Messages.getValue("duplicateMetaObjectRefMetaPropertyID")
												+ ref.getId());
									}
								}
								OntClass owlMetaObjectProperty = ontModel.createClass(METAG + ref.getId());
								owlMetaObjectProperty.addProperty(annotationPropertyLocalLabel, ref.getLocalLabel());
								OntClass owlMetaProperty = ontModel.getOntClass(METAG + ref.getMetaProperty().getId());
								owlMetaObjectProperty.addSuperClass(owlMetaProperty);

								if (ref.isUnique()) {
									AllValuesFromRestriction objectHasProperty = ontModel
											.createAllValuesFromRestriction(null, hasPropertyProp,
													owlMetaObjectProperty); // some
									owlMetaObject.addEquivalentClass(objectHasProperty);
								} else {
									SomeValuesFromRestriction objectHasProperty = ontModel
											.createSomeValuesFromRestriction(null, hasPropertyProp,
													owlMetaObjectProperty); // some
									owlMetaObject.addEquivalentClass(objectHasProperty);
								}

							}

							// 对象元模型 point
							for (MetaPointTypeReference ref : metaObject.getPoints()) {
								// 20220802加控制台报错
								for (Iterator It = ontModel.listClasses(); It.hasNext();) {
									OntClass classExist = (OntClass) It.next();
									if (classExist.getLocalName() != null
											&& ref.getId().equals(classExist.getLocalName())) {
										console.printError(Messages.getValue("ExportWizardPage_owlExportError")
												+ Messages.getValue("duplicateMetaObjectRefMetaPointID") + ref.getId());
									}
								}
								OntClass owlMetaObjectPoint = ontModel.createClass(METAG + ref.getId());
								owlMetaObjectPoint.addProperty(annotationPropertyLocalLabel, ref.getLocalName());
								OntClass owlMetaPoint = ontModel.getOntClass(METAG + ref.getPoint().getId());
								owlMetaObjectPoint.addSuperClass(owlMetaPoint);

								HasValueRestriction objectpointvaluedirection = ontModel.createHasValueRestriction(null,
										pointDirection, ontModel.createLiteral(ref.getDirection().toString())); // value
								IntersectionClass PointAndPointValueDirection = ontModel.createIntersectionClass(null,
										ontModel.createList(
												new RDFNode[] { owlMetaObjectPoint, objectpointvaluedirection })); // and
								SomeValuesFromRestriction objectsomepointanddirection = ontModel
										.createSomeValuesFromRestriction(null, linkObjectAndPointProp,
												PointAndPointValueDirection); // some
								owlMetaObject.addEquivalentClass(objectsomepointanddirection);
							}
							owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
									languageIncludingObjectProp, owlMetaObject));
						}
					}
					System.out.println("===对象元模型成功===");

					// ----------------------角色元模型----------------------//
					IFolder filemetaRole = null;
					IFolder filemetaRole1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAROLE);
					IFolder filemetaRole2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAROLE_ZH);
					if (filemetaRole1 != null) {
						filemetaRole = filemetaRole1;
					} else if (filemetaRole2 != null) {
						filemetaRole = filemetaRole2;
					}
					for (IResource f : filemetaRole.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();
							MetaRole metaRole = KarmaCompilerManager.parseMetaRoleById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							List<KarmaCompilationError> errors = KarmaCompilerManager.getErrors(packagePath, path);
							List<IProblem> problemList = new ArrayList<IProblem>();
							for (KarmaCompilationError error : errors) {
								if (error != null) {
									IProblem fatalProblem = new ProblemImpl(error.getLine() + 1, error.getMessage(),
											filePath);
									problemList.add(fatalProblem);
								}
							}
							if (problemList.size() != 0) {
								ReportProblem.getInstance().doReport(problemList);
							}
							// 生成角色元模型
							// 20220802加控制台报错
							for (Iterator It = ontModel.listClasses(); It.hasNext();) {
								OntClass classExist = (OntClass) It.next();
								if (classExist.getLocalName() != null
										&& metaRole.getId().equals(classExist.getLocalName())) {
									console.printError(Messages.getValue("ExportWizardPage_owlExportError")
											+ Messages.getValue("duplicateMetaRoleID") + metaRole.getId());
								}
							}
							OntClass owlMetaRole = ontModel.createClass(METAG + metaRole.getId());
							owlMetaRole.addSuperClass(owlRoleClass);

							// 角色元模型 annotation
							owlMetaRole.addProperty(annotationPropertyLocalLabel, metaRole.getLocalLabel()); // LocalLabel
							if (metaRole.getDescription() != null && !metaRole.getDescription().equals("")) {
								owlMetaRole.addProperty(annotationPropertyDescription, metaRole.getDescription()); // Description
							}
							owlMetaRole.addProperty(annotationPropertyShape, metaRole.getRoleShape().toString()); // Shape
							owlMetaRole.addProperty(annotationPropertyDirection, metaRole.getDirection().toString()); // Direction

							// 角色元模型 property
							for (MetaPropertyTypeReference ref : metaRole.getProperties()) {
								// 20220802加控制台报错
								for (Iterator It = ontModel.listClasses(); It.hasNext();) {
									OntClass classExist = (OntClass) It.next();
									if (classExist.getLocalName() != null
											&& ref.getId().equals(classExist.getLocalName())) {
										console.printError(Messages.getValue("ExportWizardPage_owlExportError")
												+ Messages.getValue("duplicateMetaRoleRefMetaPropertyID")
												+ ref.getId());
									}
								}
								OntClass owlmetaRoleProperty = ontModel.createClass(METAG + ref.getId());
								owlmetaRoleProperty.addProperty(annotationPropertyLocalLabel, ref.getLocalLabel());
								OntClass owlmetaProperty = ontModel.getOntClass(METAG + ref.getMetaProperty().getId());
								owlmetaRoleProperty.addSuperClass(owlmetaProperty);

								if (ref.isUnique()) {
									AllValuesFromRestriction RoleHasProperty = ontModel
											.createAllValuesFromRestriction(null, hasPropertyProp, owlmetaRoleProperty); // some
									owlMetaRole.addEquivalentClass(RoleHasProperty);
								} else {
									SomeValuesFromRestriction RoleHasProperty = ontModel
											.createSomeValuesFromRestriction(null, hasPropertyProp,
													owlmetaRoleProperty); // some
									owlMetaRole.addEquivalentClass(RoleHasProperty);
								}

							}
							owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
									languageIncludingRoleProp, owlMetaRole));
						}
					}
					System.out.println("===角色元模型成功===");

					// ----------------------关系元模型----------------------//
					IFolder filemetaRelationship = null;
					IFolder filemetaRelationship1 = (IFolder) languageFolder
							.findMember("/" + PackagePath.TYPE_METARELATIONSHIP);
					IFolder filemetaRelationship2 = (IFolder) languageFolder
							.findMember("/" + PackagePath.TYPE_METARELATIONSHIP_ZH);
					if (filemetaRelationship1 != null) {
						filemetaRelationship = filemetaRelationship1;
					} else if (filemetaRelationship2 != null) {
						filemetaRelationship = filemetaRelationship2;
					}
					for (IResource f : filemetaRelationship.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();
							MetaRelationship metaRelationship = KarmaCompilerManager.parseMetaRelationshipById(
									packagePath, f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							List<KarmaCompilationError> errors = KarmaCompilerManager.getErrors(packagePath, path);
							List<IProblem> problemList = new ArrayList<IProblem>();
							for (KarmaCompilationError error : errors) {
								if (error != null) {
									IProblem fatalProblem = new ProblemImpl(error.getLine() + 1, error.getMessage(),
											filePath);
									problemList.add(fatalProblem);
								}
							}
							if (problemList.size() != 0) {
								ReportProblem.getInstance().doReport(problemList);
							}
							// 生成关系元模型
							// 20220802加控制台报错
							for (Iterator It = ontModel.listClasses(); It.hasNext();) {
								OntClass classExist = (OntClass) It.next();
								if (classExist.getLocalName() != null
										&& metaRelationship.getId().equals(classExist.getLocalName())) {
									console.printError(Messages.getValue("ExportWizardPage_owlExportError")
											+ Messages.getValue("duplicateMetaRelationshipID")
											+ metaRelationship.getId());
								}
							}
							OntClass owlMetaRelationship = ontModel.createClass(METAG + metaRelationship.getId());
							owlMetaRelationship.addSuperClass(owlRelationshipClass);

							// 关系元模型 annotation
							owlMetaRelationship.addProperty(annotationPropertyLocalLabel,
									metaRelationship.getLocalLabel()); // LocalLabel
							if (metaRelationship.getDescription() != null
									&& !metaRelationship.getDescription().equals("")) {
								owlMetaRelationship.addProperty(annotationPropertyDescription,
										metaRelationship.getDescription()); // Description
							}
							if (metaRelationship.getIconPath() != null && !metaRelationship.getIconPath().equals("")) {
								owlMetaRelationship.addProperty(annotationPropertyIcon, metaRelationship.getIconPath()); // Icon
							}
							owlMetaRelationship.addProperty(annotationPropertyShape,
									metaRelationship.getRelationshipShape().toString()); // Shape

							// 关系元模型 property
							for (MetaPropertyTypeReference ref : metaRelationship.getProperties()) {
								// 20220802加控制台报错
								for (Iterator It = ontModel.listClasses(); It.hasNext();) {
									OntClass classExist = (OntClass) It.next();
									if (classExist.getLocalName() != null
											&& ref.getId().equals(classExist.getLocalName())) {
										console.printError(Messages.getValue("ExportWizardPage_owlExportError")
												+ Messages.getValue("duplicateMetaRelationshipRefMetaPropertyID")
												+ ref.getId());
									}
								}
								OntClass owlMetaRelationshipProperty = ontModel.createClass(METAG + ref.getId());
								owlMetaRelationshipProperty.addProperty(annotationPropertyLocalLabel,
										ref.getLocalLabel());
								OntClass owlmetaProperty = ontModel.getOntClass(METAG + ref.getMetaProperty().getId());
								owlMetaRelationshipProperty.addSuperClass(owlmetaProperty);

								if (ref.isUnique()) {
									AllValuesFromRestriction RelationshipHasProperty = ontModel
											.createAllValuesFromRestriction(null, hasPropertyProp,
													owlMetaRelationshipProperty); // some
									owlMetaRelationship.addEquivalentClass(RelationshipHasProperty);
								} else {
									SomeValuesFromRestriction RelationshipHasProperty = ontModel
											.createSomeValuesFromRestriction(null, hasPropertyProp,
													owlMetaRelationshipProperty); // some
									owlMetaRelationship.addEquivalentClass(RelationshipHasProperty);
								}

							}
							// 关系元模型 Role
							// 1.25新数据机构修改
							for (String ref : metaRelationship.getRoles().keySet()) {
								OntClass owlmetaRole = ontModel.getOntClass(METAG + ref);
								SomeValuesFromRestriction RelationshipLinkRole = ontModel
										.createSomeValuesFromRestriction(null, linkRelationshipAndRoleProp,
												owlmetaRole); // some
								owlMetaRelationship.addEquivalentClass(RelationshipLinkRole);
							}
							owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
									languageIncludingRelationshipProp, owlMetaRelationship));
						}
					}
					System.out.println("===关系元模型成功===");

					// ----------------------图元模型----------------------//
					HashSet<MetaGraph> metaGraphSet = new HashSet<MetaGraph>();
					IFolder filemetaGraph = null;
					IFolder filemetaGraph1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAGRAPH);
					IFolder filemetaGraph2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_METAGRAPH_ZH);
					if (filemetaGraph1 != null) {
						filemetaGraph = filemetaGraph1;
					} else if (filemetaGraph2 != null) {
						filemetaGraph = filemetaGraph2;
					}
					for (IResource f : filemetaGraph.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();
							MetaGraph metaGraph = KarmaCompilerManager.parseMetaGraphById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							List<KarmaCompilationError> errors = KarmaCompilerManager.getErrors(packagePath, path);
							List<IProblem> problemList = new ArrayList<IProblem>();
							for (KarmaCompilationError error : errors) {
								if (error != null) {
									IProblem fatalProblem = new ProblemImpl(error.getLine() + 1, error.getMessage(),
											filePath);
									problemList.add(fatalProblem);
								}
							}
							if (problemList.size() != 0) {
								ReportProblem.getInstance().doReport(problemList);
							}
							metaGraphSet.add(metaGraph);
							// 生成图元模型
							// 20220802加控制台报错
							for (Iterator It = ontModel.listClasses(); It.hasNext();) {
								OntClass classExist = (OntClass) It.next();
								if (classExist.getLocalName() != null
										&& metaGraph.getId().equals(classExist.getLocalName())) {
									console.printError(Messages.getValue("ExportWizardPage_owlExportError")
											+ Messages.getValue("duplicateMetaGraphID") + metaGraph.getId());
								}
							}
							OntClass owlMetaGraph = ontModel.getOntClass(METAG + metaGraph.getId());//2040103对应下述新增修改
							if(owlMetaGraph == null) {
								owlMetaGraph = ontModel.createClass(METAG + metaGraph.getId());
							}
//							OntClass owlMetaGraph = ontModel.createClass(METAG + metaGraph.getId());
							owlMetaGraph.addSuperClass(owlGraphClass);

							// 图元模型 annotation
							owlMetaGraph.addProperty(annotationPropertyLocalLabel, metaGraph.getLocalLabel()); // LocalLabel
							if (metaGraph.getDescription() != null && !metaGraph.getDescription().equals("")) {
								owlMetaGraph.addProperty(annotationPropertyDescription, metaGraph.getDescription()); // Description
							}
							if (metaGraph.getType() != null) {
								owlMetaGraph.addProperty(annotationPropertyType, metaGraph.getType().toString());
							}

							// 图元模型继承20240103
							HashMap<String, MetaGraph> metaGraphs = metaGraph.getExtendMap();
							if (metaGraphs != null) {
								// 获取所有key的集合
								Set<String> keys = metaGraphs.keySet();
								// 遍历所有key
								for (String key : keys) {
									OntClass owlExtendedMetaGraph;
									owlExtendedMetaGraph = ontModel.getOntClass(METAG + key);
									if(owlExtendedMetaGraph == null) {
										owlExtendedMetaGraph = ontModel.createClass(METAG + key);
									}
									SomeValuesFromRestriction graphExtendGraph = ontModel
											.createSomeValuesFromRestriction(null, extendProp, owlExtendedMetaGraph); // some
									owlMetaGraph.addEquivalentClass(graphExtendGraph);
								}
							}

							// 图元模型 property
							for (MetaPropertyTypeReference ref : metaGraph.getProperties()) {
								// 20220802加控制台报错
								for (Iterator It = ontModel.listClasses(); It.hasNext();) {
									OntClass classExist = (OntClass) It.next();
									if (classExist.getLocalName() != null
											&& ref.getId().equals(classExist.getLocalName())) {
										console.printError(Messages.getValue("ExportWizardPage_owlExportError")
												+ Messages.getValue("duplicateMetaGraphRefMetaPropertyID")
												+ ref.getId());
									}
								}
								OntClass owlmetaGraphProperty = ontModel.createClass(METAG + ref.getId());
								owlmetaGraphProperty.addProperty(annotationPropertyLocalLabel, ref.getLocalLabel());
								OntClass owlmetaProperty = ontModel.getOntClass(METAG + ref.getMetaProperty().getId());
								owlmetaGraphProperty.addSuperClass(owlmetaProperty);

								if (ref.isUnique()) {
									AllValuesFromRestriction graphHasProperty = ontModel.createAllValuesFromRestriction(
											null, hasPropertyProp, owlmetaGraphProperty); // some
									owlMetaGraph.addEquivalentClass(graphHasProperty);
								} else {
									SomeValuesFromRestriction graphHasProperty = ontModel
											.createSomeValuesFromRestriction(null, hasPropertyProp,
													owlmetaGraphProperty); // some
									owlMetaGraph.addEquivalentClass(graphHasProperty);
								}

							}

							// 图元模型 Object
							// 1.25新数据机构修改
							for (String ref : metaGraph.getObjects().keySet()) {
								OntClass owlMetaObject = ontModel.getOntClass(METAG + ref);
								SomeValuesFromRestriction graphIncludingObject = ontModel
										.createSomeValuesFromRestriction(null, graphIncludingObjectProp, owlMetaObject); // some
								owlMetaGraph.addEquivalentClass(graphIncludingObject);
							}

							// 图元模型 Relationship
							// 1.25新数据机构修改
							for (String ref : metaGraph.getRelationships().keySet()) {
								OntClass owlMetaRelationship = ontModel.getOntClass(METAG + ref);
								SomeValuesFromRestriction graphIncludingRelationship = ontModel
										.createSomeValuesFromRestriction(null, graphIncludingRelationshipProp,
												owlMetaRelationship); // some
								owlMetaGraph.addEquivalentClass(graphIncludingRelationship);
							}

							// 图元模型 Connector
							OntClass owlMetaConnector = ontModel.createClass(METAG + "connect_" + metaGraph.getId());
							owlMetaConnector.addSuperClass(owlconnectorClass);
							SomeValuesFromRestriction graphIncludingConnector = ontModel
									.createSomeValuesFromRestriction(null, graphIncludingConnectorProp,
											owlMetaConnector);
							owlMetaGraph.addEquivalentClass(graphIncludingConnector);
							// 图元模型 绑定
							for (String key : metaGraph.getBindingMap().keySet()) {
								String[] keyArr = key.split("\\.");
								SomeValuesFromRestriction linkFromRelationship = ontModel
										.createSomeValuesFromRestriction(null, linkFromRelationshipProp,
												ontModel.getOntClass(METAG + keyArr[0]));
								SomeValuesFromRestriction linkRelationshipAndRole = ontModel
										.createSomeValuesFromRestriction(null, linkRelationshipAndRoleProp,
												ontModel.getOntClass(METAG + keyArr[1]));

								HashSet<String> set = metaGraph.getBindingMap().get(key);
								for (String v : set) {
									String[] valueArr = v.split("\\.");
									// length == 1表示不通过点相连
									if (valueArr.length == 1) {
										SomeValuesFromRestriction linkToObject = ontModel
												.createSomeValuesFromRestriction(null, linkToObjectProp,
														ontModel.getOntClass(METAG + valueArr[0]));
										SomeValuesFromRestriction roleBindingObject = ontModel
												.createSomeValuesFromRestriction(null, RoleBindingObjectProp,
														ontModel.getOntClass(METAG + valueArr[0]));
										IntersectionClass connector_object = ontModel.createIntersectionClass(null,
												ontModel.createList(new RDFNode[] { linkFromRelationship,
														linkRelationshipAndRole, roleBindingObject, linkToObject }));
										owlMetaConnector.addEquivalentClass(connector_object);
									}
									if (valueArr.length == 2) {
										SomeValuesFromRestriction linkToObject = ontModel
												.createSomeValuesFromRestriction(null, linkToObjectProp,
														ontModel.getOntClass(METAG + valueArr[0]));
										SomeValuesFromRestriction linkObjectAndPoint = ontModel
												.createSomeValuesFromRestriction(null, linkObjectAndPointProp,
														ontModel.getOntClass(METAG + valueArr[1]));
										SomeValuesFromRestriction roleBindingPoint = ontModel
												.createSomeValuesFromRestriction(null, RoleBindingPointProp,
														ontModel.getOntClass(METAG + valueArr[1]));
										IntersectionClass connector_point = ontModel.createIntersectionClass(null,
												ontModel.createList(
														new RDFNode[] { linkFromRelationship, linkRelationshipAndRole,
																roleBindingPoint, linkObjectAndPoint, linkToObject }));
										owlMetaConnector.addEquivalentClass(connector_point);
									}
								}
							}
//							owlLanguage.addProperty(languageIncludingGraphProp, owlMetaGraph);20231112仅适用于individual
							owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
									languageIncludingGraphProp, owlMetaGraph));
						}
					}
					System.out.println("===图元模型成功===");

					// ----------------------分解剖视单独拿出来写----------------------//
					for (MetaGraph metaGraph : metaGraphSet) {
						OntClass owlMetaConnector = ontModel.getOntClass(METAG + "connect_" + metaGraph.getId());
						// 图元模型 分解
						for (String key : metaGraph.getDecompositeMap().keySet()) {
							HashSet<String> set = metaGraph.getDecompositeMap().get(key);
							for (String v : set) {
								SomeValuesFromRestriction some_decompose = ontModel.createSomeValuesFromRestriction(
										null, decomposeProp, ontModel.getOntClass(METAG + v));
								OntClass class1 = ontModel.getOntClass(METAG + key);
								IntersectionClass and_decompose = ontModel.createIntersectionClass(null,
										ontModel.createList(new RDFNode[] { class1, some_decompose }));
								SomeValuesFromRestriction some_graphIncludingObject = ontModel
										.createSomeValuesFromRestriction(null, graphIncludingObjectProp, and_decompose);
								owlMetaConnector.addEquivalentClass(some_graphIncludingObject);
							}
						}
						// 图元模型 剖视
						for (String key : metaGraph.getExplodeMap().keySet()) {
							HashSet<String> set = metaGraph.getExplodeMap().get(key);
							for (String v : set) {
								SomeValuesFromRestriction some_explode = ontModel.createSomeValuesFromRestriction(null,
										explodeProp, ontModel.getOntClass(METAG + v));
								IntersectionClass and_explode = ontModel.createIntersectionClass(null, ontModel
										.createList(new RDFNode[] { ontModel.getOntClass(METAG + key), some_explode }));
								SomeValuesFromRestriction some_graphIncludingObject = ontModel
										.createSomeValuesFromRestriction(null, graphIncludingObjectProp, and_explode);
								owlMetaConnector.addEquivalentClass(some_graphIncludingObject);
							}
						}
					}
					System.out.println("===分解剖视成功===");

					// ----------------------模型----------------------//
					HashSet<Model> ModelSet = new HashSet<Model>();
					IFolder fileModel = null;
					IFolder fileModel1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
					IFolder fileModel2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
					if (fileModel1 != null) {
						fileModel = fileModel1;
					} else if (fileModel2 != null) {
						fileModel = fileModel2;
					}
					for (IResource f : fileModel.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();

							Model model = KarmaCompilerManager.parseModelById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							System.out.println("===图模型visitor成功===");
							// 生成图模型
							OntClass owlMetaGraph = ontModel.getOntClass(METAG + model.getMetaGraph().getId());
							Individual owlGraph = owlMetaGraph.createIndividual(METAG + model.getId());
							// 图模型 Property
							for (PropertyTypeReference ref : model.getPropertiesTypeReference()) {
								OntClass meta = ontModel
										.getOntClass(METAG + ref.getMetaPropertyTypeReference().getId());
								Individual owlGraphProperty = meta.createIndividual(METAG + ref.getId());
							}
							// 图模型 Object
							for (GraphObject graphObject : model.getObjects()) {
								OntClass meta = ontModel.getOntClass(METAG + graphObject.getMetaObject().getId());
								Individual owlGraphObject = meta.createIndividual(METAG + graphObject.getId());
								// GraphObject 属性
								for (PropertyTypeReference ref : graphObject.getPropertiesTypeReference()) {
									OntClass meta2 = ontModel
											.getOntClass(METAG + ref.getMetaPropertyTypeReference().getId());
									Individual owlGraphObjectProperty = meta2.createIndividual(METAG + ref.getId());
								}
								// GraphObject 点
								for (Point graphObjectPoint : graphObject.getPoints()) {
									OntClass meta2 = ontModel
											.getOntClass(METAG + graphObjectPoint.getMetaPointTypeReference().getId());
									Individual owlGraphObjectPoint = meta2
											.createIndividual(METAG + graphObjectPoint.getId());
									// 点属性
									for (PropertyTypeReference pointProperty : graphObjectPoint
											.getPropertiesTypeReference()) {
										OntClass meta3 = ontModel.getOntClass(
												METAG + pointProperty.getMetaPropertyTypeReference().getId());
										Individual owlPointProperty = meta3
												.createIndividual(METAG + pointProperty.getId());
									}
								}
							}
							// 图模型 Relationship
							for (Relationship relationship : model.getRelationships()) {
								OntClass meta = ontModel.getOntClass(METAG + relationship.getMetaRela().getId());
								Individual owlRelationship = meta.createIndividual(METAG + relationship.getId());
								// 关系 属性
								for (PropertyTypeReference ref : relationship.getPropertiesTypeReference()) {
									OntClass meta2 = ontModel
											.getOntClass(METAG + ref.getMetaPropertyTypeReference().getId());
									Individual owlRelationshipProperty = meta2.createIndividual(METAG + ref.getId());
								}
								// 关系 from角色
								Role fromRole = relationship.getFromRole();
								OntClass meta2 = ontModel.getOntClass(METAG + fromRole.getMetaRole().getId());
								Individual owlFromRole = meta2.createIndividual(METAG + fromRole.getId());

								// 角色 属性
								for (PropertyTypeReference fromRoleProperty : fromRole.getPropertiesTypeReference()) {
									OntClass meta3 = ontModel.getOntClass(
											METAG + fromRoleProperty.getMetaPropertyTypeReference().getId());
									Individual owlFromRoleProperty = meta3
											.createIndividual(METAG + fromRoleProperty.getId());
								}

								// 关系 to角色
								Role toRole = relationship.getToRole();
								OntClass meta3 = ontModel.getOntClass(METAG + toRole.getMetaRole().getId());
								Individual owlToRole = meta3.createIndividual(METAG + toRole.getId());

								// 角色 属性
								for (PropertyTypeReference toRoleProperty : toRole.getPropertiesTypeReference()) {
									OntClass meta4 = ontModel
											.getOntClass(METAG + toRoleProperty.getMetaPropertyTypeReference().getId());
									Individual owlToRoleProperty = meta4
											.createIndividual(METAG + toRoleProperty.getId());
								}
							}
						}
					}

					for (IResource f : fileModel.members()) {
						if (f.getName().endsWith(".karma")) {
							String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
							PackagePath packagePath = PackagePath.createPackagePath(path);
							String filePath = f.getFullPath().toString();

							Model model = KarmaCompilerManager.parseModelById(packagePath,
									f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
							// 生成图模型
							OntClass owlMetaGraph = ontModel.getOntClass(METAG + model.getMetaGraph().getId());
							Individual owlGraph = ontModel.getIndividual(METAG + model.getId());
							// 图模型annotation
							owlGraph.addProperty(annotationPropertyLocalLabel, model.getLocalLabel()); // LocalLabel
							if (StringUtils.isNotEmpty(model.getCifString())) {
								owlGraph.addProperty(annotationPropertyCifString, model.getCifString());
							}
							System.out.println("===图模型成功===");
							// 图模型 property
							for (PropertyTypeReference ref : model.getPropertiesTypeReference()) {
								Individual owlGraphProperty = ontModel.getIndividual(METAG + ref.getId());
								owlGraphProperty.addProperty(annotationPropertyLocalLabel, ref.getLocalLabel()); // LocalLabel
								owlGraphProperty.addProperty(value, ref.getValue()); // value
								owlGraphProperty.addProperty(annotationPropertyColor, ref.getColor()); // Color
								if (ref.getProText() != null) {// Text
									Text text = ref.getProText();
									owlGraphProperty.addProperty(annotationPropertyText,
											text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
													+ "," + text.getItalic().toString());
									System.out.println(text.getFont() + "," + text.getSize() + ","
											+ text.getBold().toString() + "," + text.getItalic().toString());
								}
								Boolean isUnderline = ref.isUnderline();
								owlGraphProperty.addProperty(annotationPropertyUnderline, isUnderline.toString());// underline

								Boolean isStrikeThrough = ref.isStrikeThrough();
								owlGraphProperty.addProperty(annotationPropertyStrikethrough,
										isStrikeThrough.toString());// strikeThrough
								// 加clone2022.06.09
								if (ref.getSystemNameClone() != null) {
									Individual cloneProperty = ontModel.getIndividual(METAG + ref.getSystemNameClone());
									owlGraphProperty.addProperty(clonePropertyProp, cloneProperty);
								}
								owlGraph.addProperty(hasPropertyProp, owlGraphProperty);
							}
							System.out.println("===图模型property成功===");

							// 图模型 Object
							for (GraphObject graphObject : model.getObjects()) {
								Individual owlGraphObject = ontModel.getIndividual(METAG + graphObject.getId());

								// GraphObject 属性
								for (PropertyTypeReference ref : graphObject.getPropertiesTypeReference()) {
									Individual owlGraphObjectProperty = ontModel.getIndividual(METAG + ref.getId());
									owlGraphObjectProperty.addProperty(annotationPropertyLocalLabel,
											ref.getLocalLabel()); // LocalLabel
									owlGraphObjectProperty.addProperty(value, ref.getValue());// value

									// 20220629加属性annotation
									// 属性 annotaion
									owlGraphObjectProperty.addProperty(annotationPropertyColor, ref.getColor()); // Color
									if (ref.getProText() != null) {// Text
										Text text = ref.getProText();
										owlGraphObjectProperty.addProperty(annotationPropertyText,
												text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
														+ "," + text.getItalic().toString());
										System.out.println(text.getFont() + "," + text.getSize() + ","
												+ text.getBold().toString() + "," + text.getItalic().toString());
									}
									Boolean isUnderline = ref.isUnderline();
									owlGraphObjectProperty.addProperty(annotationPropertyUnderline,
											isUnderline.toString());// underline
									Boolean isStrikeThrough = ref.isStrikeThrough();
									owlGraphObjectProperty.addProperty(annotationPropertyStrikethrough,
											isStrikeThrough.toString());// strikeThrough

									// 加clone2022.06.09
									if (ref.getSystemNameClone() != null) {
										Individual cloneProperty = ontModel
												.getIndividual(METAG + ref.getSystemNameClone());
										owlGraphObjectProperty.addProperty(clonePropertyProp, cloneProperty);
									}
									owlGraphObject.addProperty(hasPropertyProp, owlGraphObjectProperty);

								}
								// 加clone2022.06.09
								if (graphObject.getCloneObject() != null) {
									for (Iterator It1 = ontModel.listIndividuals(); It1.hasNext();) {
										Individual owlReqIFIndividualPro = (Individual) It1.next();
									}
									Individual cloneObject = ontModel
											.getIndividual(METAG + graphObject.getCloneObject());
									owlGraphObject.addProperty(cloneObjectProp, cloneObject);
								}
								if (graphObject.getCloneModel() != null) {
									Individual cloneModel = ontModel.getIndividual(METAG + graphObject.getCloneModel());
									owlGraphObject.addProperty(cloneModelProp, cloneModel);
								}

								// GraphObject 点
								for (Point graphObjectPoint : graphObject.getPoints()) {
									Individual owlGraphObjectPoint = ontModel
											.getIndividual(METAG + graphObjectPoint.getId());

									// 加clone2022.06.09
									if (graphObjectPoint.getClonePoint() != null) {
										Individual clonePoint = ontModel
												.getIndividual(METAG + graphObjectPoint.getClonePoint());
										owlGraphObjectPoint.addProperty(clonePointProp, clonePoint);
									}

									// 点属性
									for (PropertyTypeReference pointProperty : graphObjectPoint
											.getPropertiesTypeReference()) {
										Individual owlPointProperty = ontModel
												.getIndividual(METAG + pointProperty.getId());
										owlPointProperty.addProperty(annotationPropertyLocalLabel,
												pointProperty.getLocalLabel()); // LocalLabel
										owlPointProperty.addProperty(value, pointProperty.getValue());// value
										owlPointProperty.addProperty(annotationPropertyColor, pointProperty.getColor()); // Color
										if (pointProperty.getProText() != null) {// Text
											Text text = pointProperty.getProText();
											owlPointProperty.addProperty(annotationPropertyText,
													text.getFont() + "," + text.getSize() + ","
															+ text.getBold().toString() + ","
															+ text.getItalic().toString());
											System.out.println(text.getFont() + "," + text.getSize() + ","
													+ text.getBold().toString() + "," + text.getItalic().toString());
										}
										Boolean isUnderline = pointProperty.isUnderline();
										owlPointProperty.addProperty(annotationPropertyUnderline,
												isUnderline.toString());// underline
										Boolean isStrikeThrough = pointProperty.isStrikeThrough();
										owlPointProperty.addProperty(annotationPropertyStrikethrough,
												isStrikeThrough.toString());// strikeThrough

										// 加clone2022.06.09
										if (pointProperty.getSystemNameClone() != null) {
											Individual cloneProperty = ontModel
													.getIndividual(METAG + pointProperty.getSystemNameClone());
											owlPointProperty.addProperty(clonePropertyProp, cloneProperty);
										}
										owlGraphObjectPoint.addProperty(hasPropertyProp, owlPointProperty);
									}

									// 点 annotaion
									owlGraphObjectPoint.addProperty(annotationPropertyLocalLabel,
											graphObjectPoint.getLocalLabel()); // LocalLabel
									String initialLocation = String.valueOf(graphObjectPoint.getPointX()) + ","
											+ String.valueOf(graphObjectPoint.getPointY()) + ","
											+ String.valueOf(graphObjectPoint.getSizeX()) + ","
											+ String.valueOf(graphObjectPoint.getSizeY());
									owlGraphObjectPoint.addProperty(annotationPropertyinitialLocation, initialLocation); // initialLocation
									owlGraphObjectPoint.addProperty(annotationPropertyShape,
											graphObjectPoint.getPointShape().toString()); // Shape
									owlGraphObjectPoint.addProperty(annotationPropertyColor,
											graphObjectPoint.getColor()); // Color

									if (graphObjectPoint.getText() != null) {
										Text text = graphObjectPoint.getText();
										owlGraphObjectPoint.addProperty(annotationPropertyText,
												text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
														+ "," + text.getItalic().toString());
									} // text

									owlGraphObjectPoint.addProperty(annotationPropertyIconDisplay,
											String.valueOf(graphObjectPoint.isIconDisplay()));// iconDisplay
									owlGraphObjectPoint.addProperty(annotationPropertylableDisplay,
											String.valueOf(graphObjectPoint.isLabelDisplay())); // LabelDisplay

									owlGraphObjectPoint.addProperty(annotationPropertyImageAddress,
											String.valueOf(graphObjectPoint.getImage()));// imageAddress
									owlGraphObject.addProperty(linkObjectAndPointProp, owlGraphObjectPoint);

								}
								// GraphObject annotaion
								owlGraphObject.addProperty(annotationPropertyLocalLabel, graphObject.getLocalLabel()); // LocalLabel
								String inititalLocation = String.valueOf(graphObject.getLocationX()) + ","
										+ String.valueOf(graphObject.getLocationY()) + ","
										+ String.valueOf(graphObject.getWidth()) + ","
										+ String.valueOf(graphObject.getHeight());
								owlGraphObject.addProperty(annotationPropertyinitialLocation, inititalLocation); // inititalLocation
								owlGraphObject.addProperty(annotationPropertyShape,
										graphObject.getObjectShape().toString()); // Shape
								if (StringUtils.isNotEmpty(graphObject.getColor())) {
									owlGraphObject.addProperty(annotationPropertyColor, graphObject.getColor()); // Color
								}
								owlGraphObject.addProperty(annotationPropertyScreenMode,
										graphObject.getObjectMode().toString()); // screenMode
								if (StringUtils.isNotEmpty(graphObject.getImage())) {
									owlGraphObject.addProperty(annotationPropertyImageAddress, graphObject.getImage()); // ImageAddress
								}
								if (StringUtils.isNotEmpty(graphObject.getSdIdentification())) {
									owlGraphObject.addProperty(annotationPropertySdIdentification,
											graphObject.getSdIdentification());// SDIdentification
								}
								if (graphObject.getText() != null) {
									Text text = graphObject.getText();
									owlGraphObject.addProperty(annotationPropertyText,
											text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
													+ "," + text.getItalic().toString());// text
								}
								owlGraphObject.addProperty(annotationPropertyIconDisplay,
										String.valueOf(graphObject.isIconDisplay()));// iconDisplay
								owlGraphObject.addProperty(annotationPropertyFrameSize,
										String.valueOf(graphObject.getFrameSize()));// frame
								if (StringUtils.isNotEmpty(graphObject.getLinetype())) {
									owlGraphObject.addProperty(annotationPropertyLineType, graphObject.getLinetype());// frame
								}
								if (StringUtils.isNotEmpty(graphObject.getVisualizationList())) {
									owlGraphObject.addProperty(annotationPropertyVisualizationList,
											graphObject.getVisualizationList());// VisualizationList
								}

								if (StringUtils.isNotEmpty(graphObject.getCifString())) {
									owlGraphObject.addProperty(annotationPropertyCifString, graphObject.getCifString());
								}
								if (StringUtils.isNotEmpty(graphObject.getStyle())) {
									owlGraphObject.addProperty(annotationPropertyStyle, graphObject.getStyle());
								}
								if (StringUtils.isNotEmpty(graphObject.getInitial())) {
									owlGraphObject.addProperty(annotationPropertyInitial, graphObject.getInitial());
								}
								if (StringUtils.isNotEmpty(graphObject.getType())) {
									owlGraphObject.addProperty(annotationPropertyType, graphObject.getType());
								}

								owlGraphObject.addProperty(annotationPropertyLayerLocation,
										String.valueOf(graphObject.getLayerLocation())); // LayerLocation

								owlGraph.addProperty(graphIncludingObjectProp, owlGraphObject);
							}
							System.out.println("===图模型object成功===");

							// 图模型 Relationship
							int n = 0;
							for (Relationship relationship : model.getRelationships()) {
								Individual owlGraphRelationship = ontModel.getIndividual(METAG + relationship.getId());

								// 关系 属性
								for (PropertyTypeReference ref : relationship.getPropertiesTypeReference()) {
									Individual owlRelationshipProperty = ontModel.getIndividual(METAG + ref.getId());
									owlRelationshipProperty.addProperty(annotationPropertyLocalLabel,
											ref.getLocalLabel()); // LocalLabel
									owlRelationshipProperty.addProperty(value, ref.getValue());// value
									owlRelationshipProperty.addProperty(annotationPropertyColor, ref.getColor()); // Color
									if (ref.getProText() != null) {// Text
										Text text = ref.getProText();
										owlRelationshipProperty.addProperty(annotationPropertyText,
												text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
														+ "," + text.getItalic().toString());
									}
									Boolean isUnderline = ref.isUnderline();
									owlRelationshipProperty.addProperty(annotationPropertyUnderline,
											isUnderline.toString());// underline
									Boolean isStrikeThrough = ref.isStrikeThrough();
									owlRelationshipProperty.addProperty(annotationPropertyStrikethrough,
											isStrikeThrough.toString());// strikeThrough
									// 加clone2022.06.09
									if (ref.getSystemNameClone() != null) {
										Individual cloneProperty = ontModel
												.getIndividual(METAG + ref.getSystemNameClone());
										owlRelationshipProperty.addProperty(clonePropertyProp, cloneProperty);
									}
									owlGraphRelationship.addProperty(hasPropertyProp, owlRelationshipProperty);
								}
								// 关系 from角色
								Role fromRole = relationship.getFromRole();
								Individual owlFromRole = ontModel.getIndividual(METAG + fromRole.getId());

								// 角色 属性
								for (PropertyTypeReference fromRoleProperty : fromRole.getPropertiesTypeReference()) {
									Individual owlFromRoleProperty = ontModel
											.getIndividual(METAG + fromRoleProperty.getId());
									owlFromRoleProperty.addProperty(annotationPropertyLocalLabel,
											fromRoleProperty.getLocalLabel()); // LocalLabel
									owlFromRoleProperty.addProperty(value, fromRoleProperty.getValue());// value
									owlFromRoleProperty.addProperty(annotationPropertyColor,
											fromRoleProperty.getColor()); // Color
									if (fromRoleProperty.getProText() != null) {// Text
										Text text = fromRoleProperty.getProText();
										owlFromRoleProperty.addProperty(annotationPropertyText,
												text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
														+ "," + text.getItalic().toString());
									}
									Boolean isUnderline = fromRoleProperty.isUnderline();
									owlFromRoleProperty.addProperty(annotationPropertyUnderline,
											isUnderline.toString());// underline
									Boolean isStrikeThrough = fromRoleProperty.isStrikeThrough();
									owlFromRoleProperty.addProperty(annotationPropertyStrikethrough,
											isStrikeThrough.toString());// strikeThrough

									// 加clone2022.06.09
									if (fromRoleProperty.getSystemNameClone() != null) {
										Individual cloneProperty = ontModel
												.getIndividual(METAG + fromRoleProperty.getSystemNameClone());
										;
										owlFromRoleProperty.addProperty(clonePropertyProp, cloneProperty);
									}
									owlFromRole.addProperty(hasPropertyProp, owlFromRoleProperty);
								}
								// 角色 annotaion
								owlFromRole.addProperty(annotationPropertyLocalLabel, fromRole.getLocalLabel()); // LocalLabel
								owlFromRole.addProperty(annotationPropertyShape, fromRole.getRoleShape().toString()); // Shape
								owlGraphRelationship.addProperty(linkRelationshipAndRoleProp, owlFromRole);
								owlGraph.addProperty(graphIncludingRoleProp, owlFromRole);

								// 关系 to角色
								Role toRole = relationship.getToRole();
								Individual owlToRole = ontModel.getIndividual(METAG + toRole.getId());

								// 角色 属性
								for (PropertyTypeReference toRoleProperty : toRole.getPropertiesTypeReference()) {
									Individual owlToRoleProperty = ontModel
											.getIndividual(METAG + toRoleProperty.getId());
									owlToRoleProperty.addProperty(annotationPropertyLocalLabel,
											toRoleProperty.getLocalLabel()); // LocalLabel
									owlToRoleProperty.addProperty(value, toRoleProperty.getValue());// value
									owlToRoleProperty.addProperty(annotationPropertyColor, toRoleProperty.getColor()); // Color
									if (toRoleProperty.getProText() != null) {// Text
										Text text = toRoleProperty.getProText();
										owlToRoleProperty.addProperty(annotationPropertyText,
												text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
														+ "," + text.getItalic().toString());
									}
									Boolean isUnderline = toRoleProperty.isUnderline();
									owlToRoleProperty.addProperty(annotationPropertyUnderline, isUnderline.toString());// underline
									Boolean isStrikeThrough = toRoleProperty.isStrikeThrough();
									owlToRoleProperty.addProperty(annotationPropertyStrikethrough,
											isStrikeThrough.toString());// strikeThrough

									// 加clone2022.06.09
									if (toRoleProperty.getSystemNameClone() != null) {
										Individual cloneProperty = ontModel
												.getIndividual(METAG + toRoleProperty.getSystemNameClone());
										owlToRoleProperty.addProperty(clonePropertyProp, cloneProperty);
									}
									owlToRole.addProperty(hasPropertyProp, owlToRoleProperty);
								}
								// 角色 annotaion
								owlToRole.addProperty(annotationPropertyLocalLabel, toRole.getLocalLabel()); // LocalLabel
								owlToRole.addProperty(annotationPropertyShape, toRole.getRoleShape().toString()); // Shape
								owlGraphRelationship.addProperty(linkRelationshipAndRoleProp, owlToRole);
								owlGraph.addProperty(graphIncludingRoleProp, owlToRole);

								// 关系 annotaion
								owlGraphRelationship.addProperty(annotationPropertyLocalLabel,
										relationship.getLocalLabel()); // LocalLabel
								owlGraphRelationship.addProperty(annotationPropertyShape,
										relationship.getRelationshipShape().toString()); // Shape
								String endLocation = String.valueOf(relationship.getEndX()) + ","
										+ String.valueOf(relationship.getEndY());
								owlGraphRelationship.addProperty(annotationPropertyEndLocation, endLocation); // EndLocation
								if (StringUtils.isNotBlank(relationship.getPolyline())) {
									owlGraphRelationship.addProperty(annotationPropertyPolyLineLocation,
											relationship.getPolyline()); // PolyLineLocation
								}
								owlGraphRelationship.addProperty(annotationPropertyColor, relationship.getColor()); // Color
								owlGraphRelationship.addProperty(annotationPropertylableDisplay,
										String.valueOf(relationship.isLabelDisplay())); // LabelDisplay
								if (relationship.getText() != null) {
									Text text = relationship.getText();
									owlGraphRelationship.addProperty(annotationPropertyText,
											text.getFont() + "," + text.getSize() + "," + text.getBold().toString()
													+ "," + text.getItalic().toString());// text
								}
								if (StringUtils.isNotBlank(relationship.getSdIdentification())) {
									owlGraphRelationship.addProperty(annotationPropertySdIdentification,
											relationship.getSdIdentification());// SDIdentification
								}
								owlGraphRelationship.addProperty(annotationPropertySmoothness,
										relationship.getSmooth());// smoothness 20230927
								Boolean isAvoidObstructions = relationship.isAvoidObstructions();
								owlGraphRelationship.addProperty(annotationPropertyAvoidObstructionsRouting,
										isAvoidObstructions.toString());// avoidObstructionsRouting 20230927
								Boolean isClosestDistance = relationship.isClosestDistance();
								owlGraphRelationship.addProperty(annotationPropertyClosestDistanceRouting,
										isClosestDistance.toString());// closestDistanceRouting 20230927
								owlGraphRelationship.addProperty(annotationPropertyJumpLinkStatus,
										relationship.getJumpStatus());// jumpLinkStatus 20230927
								owlGraphRelationship.addProperty(annotationPropertyJumpLinkType,
										relationship.getJumpType());// jumpLinkType 20230927
								Boolean isReverse = relationship.isReverse();
								owlGraphRelationship.addProperty(annotationPropertyReverseJumpLink,
										isReverse.toString());// reverseJumpLink 20230927
								owlGraphRelationship.addProperty(annotationPropertyRoutingType,
										relationship.getRoutingTpye());// routingTpye 20230927

								String startLocation = String.valueOf(relationship.getStartX()) + ","
										+ String.valueOf(relationship.getStartY());
								owlGraphRelationship.addProperty(annotationPropertylStartLocation, startLocation); // StartLocation

								if (StringUtils.isNotBlank(relationship.getCifString())) {
									owlGraphRelationship.addProperty(annotationPropertyCifString,
											relationship.getCifString());
								}

								// 20220218
//								owlGraphRelationship.addProperty(annotationPropertyAvoidObstructions,
//										String.valueOf(relationship.isAvoidObstructions()));
//								owlGraphRelationship.addProperty(annotationPropertyClosestDistance,
//										String.valueOf(relationship.isClosestDistance()));
								if (owlMetaGraph.hasProperty(annotationPropertyType)
										&& GraphType.SEQUENCEDIAGRAM.toString().equals(
												owlMetaGraph.getPropertyValue(annotationPropertyType).toString())) {
									owlGraphRelationship.addProperty(annotationPropertyQueue, String.valueOf(n++));
								}

//								if (relationship.getJumpStatus() != null) {
//									owlGraphRelationship.addProperty(annotationPropertyJumpStatus,
//											relationship.getJumpStatus());
//								}
//								if (relationship.getJumpType() != null) {
//									owlGraphRelationship.addProperty(annotationPropertyJumpType,
//											relationship.getJumpType());
//								}
//								owlGraphRelationship.addProperty(annotationPropertyJumpReverse,
//										String.valueOf(relationship.isReverse()));
//								if (relationship.getRoutingTpye() != null) {
//									owlGraphRelationship.addProperty(annotationPropertyRoutingType,
//											relationship.getRoutingTpye());// routingType
//								}
//								if (relationship.getSmooth() != null) {
//									owlGraphRelationship.addProperty(annotationPropertySmooth,
//											relationship.getSmooth());
//								}
//
//								if (StringUtils.isNotBlank(relationship.getColor())) {
//									owlGraphRelationship.addProperty(annotationPropertyColor, relationship.getColor());
//								}
								owlGraphRelationship.addProperty(annotationPropertyModelSize,
										String.valueOf(relationship.getSize()));
								owlGraph.addProperty(graphIncludingRelationshipProp, owlGraphRelationship);
							}
							System.out.println("===图模型relationship成功===");
							// 绑定链接
							HashMap<String, String> bindingMap = model.getBindingMap();
							for (String key : bindingMap.keySet()) {
								String[] relaAndRole = key.split("\\.");
								String[] objectAndPoint = bindingMap.get(key).split("\\.");
								Individual relationship = ontModel.getIndividual(METAG + relaAndRole[0]);
								Individual role = ontModel.getIndividual(METAG + relaAndRole[1]);
								Individual object = ontModel.getIndividual(METAG + objectAndPoint[0]);

								if (objectAndPoint.length == 1) {
									OntClass owlmetaConnector = ontModel
											.getOntClass(METAG + "connect_" + model.getMetaGraph().getId());
									Individual connectorIn = owlmetaConnector
											.createIndividual(METAG + "connectIns_" + relaAndRole[0] + relaAndRole[1]);
									connectorIn.addProperty(linkToObjectProp, object);
									connectorIn.addProperty(linkFromRelationshipProp, relationship);
									connectorIn.addProperty(linkRelationshipAndRoleProp, role);
									connectorIn.addProperty(RoleBindingObjectProp, object);

									owlGraph.addProperty(graphIncludingConnectorProp, connectorIn);
								}
								if (objectAndPoint.length == 2) {
									Individual point = ontModel.getIndividual(METAG + objectAndPoint[1]);
									OntClass owlmetaConnector = ontModel
											.getOntClass(METAG + "connect_" + model.getMetaGraph().getId());
									Individual connectorIn = owlmetaConnector
											.createIndividual(METAG + "connectIns_" + relaAndRole[0] + relaAndRole[1]);
									connectorIn.addProperty(linkToObjectProp, object);
									connectorIn.addProperty(linkObjectAndPointProp, point);
									connectorIn.addProperty(linkFromRelationshipProp, relationship);
									connectorIn.addProperty(linkRelationshipAndRoleProp, role);
									connectorIn.addProperty(RoleBindingPointProp, point);

									owlGraph.addProperty(graphIncludingConnectorProp, connectorIn);
								}
							}
							System.out.println("===图模型connector成功===");
							// connector实例下的connect属性
							for (Relationship relationship : model.getRelationships()) {
								String relationName = relationship.getId();
								Individual connectorIns_From = ontModel.getIndividual(
										METAG + "connectIns_" + relationName + relationship.getFromRole().getId());
								Individual connectorIns_To = ontModel.getIndividual(
										METAG + "connectIns_" + relationName + relationship.getToRole().getId());
								if (connectorIns_From != null && connectorIns_To != null) {
									connectorIns_From.addProperty(connectProp, connectorIns_To);
								}
							}
							System.out.println("===图模型connector的connect属性成功===");

							// 图 插件
							for (SwimLane swimLane : model.getSwimLanes()) {
								Individual owlSwimLane = owlSwimLaneClass.createIndividual(METAG + swimLane.getId());

								owlSwimLane.addProperty(annotationPropertyLocalLabel, swimLane.getLocalLabel()); // LocalLabel
								owlSwimLane.addProperty(annotationPropertyColor, swimLane.getColor()); // Color
								String startLocation = String.valueOf(swimLane.getLocation().getLocationX()) + ","
										+ String.valueOf(swimLane.getLocation().getLocationY());
								owlSwimLane.addProperty(annotationPropertylStartLocation, startLocation); // Location
								String modelSize = String.valueOf(swimLane.getLocation().getSizeX()) + ","
										+ String.valueOf(swimLane.getLocation().getSizeY());
								owlSwimLane.addProperty(annotationPropertyModelSize, modelSize); // ModelSize

								owlGraph.addProperty(graphIncludingPluginProp, owlSwimLane);
							}
							System.out.println("===图模型swimlane成功===");

							// 表单插件
							for (Matrix matrix : model.getMatrixs()) {
								Individual owlMatrix = owlMatrixClass.createIndividual(METAG + matrix.getId());
								if (matrix.getType() != null) {
									owlMatrix.addProperty(annotationPropertyTableType, matrix.getType());// 加tableType
								}
								owlMatrix.addProperty(annotationPropertyLocalLabel, matrix.getLocalLabel()); // LocalLabel
								String startLocation = String.valueOf(matrix.getLocation().getLocationX()) + ","
										+ String.valueOf(matrix.getLocation().getLocationY());
								owlMatrix.addProperty(annotationPropertylStartLocation, startLocation); // initialLocation
								String modelSize = String.valueOf(matrix.getLocation().getSizeX()) + ","
										+ String.valueOf(matrix.getLocation().getSizeY());
								owlMatrix.addProperty(annotationPropertyModelSize, modelSize); // ModelSize

								// 属性
								PropertyTypeReference matrixProperty = matrix.getProperty();
								if (matrixProperty != null) {
									OntClass meta2 = ontModel
											.getOntClass(METAG + matrixProperty.getMetaPropertyTypeReference().getId());
									Individual owlMatrixProperty = meta2
											.createIndividual(METAG + matrixProperty.getId());
									owlMatrix.addProperty(hasPropertyProp, owlMatrixProperty);
								}
								// value
								owlMatrix.addProperty(annotationPropertyMatrix, matrix.getValue());
								// image
								if (matrix.getImage() != null) {
									owlMatrix.addProperty(annotationPropertyImageAddress, matrix.getImage());
								}
								owlGraph.addProperty(graphIncludingPluginProp, owlMatrix);
							}
							System.out.println("===图模型matrix成功===");

							// 布局插件
							for (Layout sysML : model.getSysMLs()) {
								Individual owlSysML = owlSysMLClass.createIndividual(METAG + sysML.getId());// 更正

								owlSysML.addProperty(annotationPropertyLocalLabel, sysML.getLocalLabel()); // LocalLabel
								owlSysML.addProperty(annotationPropertyDiagramKind, sysML.getDiagramKind().toString());// diagramKind
								owlSysML.addProperty(annotationPropertyModelElementType,
										sysML.getElementType().toString());// modelElementType
								owlSysML.addProperty(annotationPropertyModelElementName, sysML.getModelElementName());// modelElementName

								String startLocation = String.valueOf(sysML.getLocation().getLocationX()) + ","
										+ String.valueOf(sysML.getLocation().getLocationY());
								owlSysML.addProperty(annotationPropertylStartLocation, startLocation); // Location
								String modelSize = String.valueOf(sysML.getLocation().getSizeX()) + ","
										+ String.valueOf(sysML.getLocation().getSizeY());
								owlSysML.addProperty(annotationPropertyModelSize, modelSize); // ModelSize
								if (sysML.getImage() != null) {
									owlSysML.addProperty(annotationPropertyImageAddress, sysML.getImage());// imageAddress
								}
								if (sysML.getColor() != null) {
									owlSysML.addProperty(annotationPropertyColor, sysML.getColor()); // color
								}
								if (sysML.getProText() != null) {// Text
									Text text = sysML.getProText();
									owlSysML.addProperty(annotationPropertyText, text.getFont() + "," + text.getSize()
											+ "," + text.getBold().toString() + "," + text.getItalic().toString());
									System.out.println(text.getFont() + "," + text.getSize() + ","
											+ text.getBold().toString() + "," + text.getItalic().toString());
								}

								owlGraph.addProperty(graphIncludingPluginProp, owlSysML);
							}
							System.out.println("===图模型sysml成功===");
							// 甘特图插件
							for (Gantt gantt : model.getGantt()) {
								Individual owlGantt = owlGanttClass.createIndividual(METAG + gantt.getId());

								owlGantt.addProperty(annotationPropertyLocalLabel, gantt.getLocalLabel()); // localLabel
								String startLocation = String.valueOf(gantt.getLocation().getLocationX()) + ","
										+ String.valueOf(gantt.getLocation().getLocationY());
								owlGantt.addProperty(annotationPropertylStartLocation, startLocation); // Location
								String modelSize = String.valueOf(gantt.getLocation().getSizeX()) + ","
										+ String.valueOf(gantt.getLocation().getSizeY());
								owlGantt.addProperty(annotationPropertyModelSize, modelSize); // ModelSize
								owlGantt.addProperty(annotationPropertyTime,
										gantt.getTime().toString() + ";" + String.valueOf(gantt.getTimeUnit()) + ";"
												+ String.valueOf(gantt.getStartTime()) + ";"
												+ String.valueOf(gantt.getEndTime())); // Time
								if (gantt.getColor() != null) {
									owlGantt.addProperty(annotationPropertyColor, gantt.getColor()); // Color
								}

								// gantt Task
								for (GanttTask ganttTask : gantt.getTasks()) {
									Individual owlGanttTask = owlGanttTaskClass
											.createIndividual(METAG + gantt.getId() + "." + ganttTask.getLocalName());

									for (GanttTaskElement ganttElement : ganttTask.getElements()) {
										Individual owlGanttElement = owlGanttElementClass
												.createIndividual(METAG + ganttElement.getId());

										owlGanttElement.addProperty(annotationPropertyLocalLabel,
												ganttElement.getLocalName()); // LocalLabel
										owlGanttElement.addProperty(annotationPropertyColor,
												ganttElement.getElementColor()); // Color
										owlGanttElement.addProperty(annotationPropertyModelSize,
												String.valueOf(ganttElement.getElementLength())); // ModelSize
										owlGanttElement.addProperty(annotationPropertylStartLocation,
												String.valueOf(ganttElement.getElementOffset())); // StartLocation

										owlGanttTask.addProperty(taskIncludingElementprop, owlGanttElement);

									}
									owlGantt.addProperty(pluginIncludingTaskProp, owlGanttTask);
								}
								owlGraph.addProperty(graphIncludingPluginProp, owlGantt);
							}
							System.out.println("===图模型gantt成功===");

							// 分解剖视
							// 0608改
							for (GraphObject graphObject1 : model.getObjects()) {
								Individual owlGraphObject1 = ontModel.getIndividual(METAG + graphObject1.getId());
								if (graphObject1.getDecompositionModel() != null) {
									Model decomposeModel = graphObject1.getDecompositionModel();
									Individual decompose = ontModel.getIndividual(METAG + decomposeModel.getId());
									owlGraphObject1.addProperty(decomposeProp, decompose);
								}
								for (Iterator<Model> it = graphObject1.getExplosionModels().iterator(); it.hasNext();) {
									Model explodeModel = it.next();
									Individual explodes = ontModel.getIndividual(METAG + explodeModel.getId());
									owlGraphObject1.addProperty(explodeProp, explodes);
								}
							}
						}
					}
					System.out.println("===模型成功===");

					// ----------------------package----------------------//
					if (languageFolder.findMember("/" + PackagePath.TYPE_PACKAGES) != null
							|| languageFolder.findMember("/" + PackagePath.TYPE_PACKAGES_ZH) != null) {
						IFolder filePackage = null;
						IFolder filePackage1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_PACKAGES);
						IFolder filePackage2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_PACKAGES_ZH);
						if (filePackage1 != null) {
							filePackage = filePackage1;
						} else if (filePackage2 != null) {
							filePackage = filePackage2;
						}
						for (IResource f : filePackage.members()) {
							if (f.getName().endsWith(".karma")) {
								String path = f.getLocation().toOSString().replaceAll("\\\\", "/");
								PackagePath packagePath = PackagePath.createPackagePath(path);
								PackagesImport packages = KarmaCompilerManager.parsePackagesImportById(packagePath,
										f.getName().substring(0, f.getName().lastIndexOf(".karma")), false);
								Packages topPackage = packages.getPackages();
								OntClass owlPackage = ontModel.createClass(METAG + topPackage.getId() + "Class");
								owlPackagesClass.addSubClass(owlPackage);
								owlLanguage.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
										languageIncludingPackagesProp, owlPackage));
								Individual owlPackageIndi = owlPackage.createIndividual(METAG + topPackage.getId());
								owlPackageIndi.addProperty(annotationPropertyLocalLabel, topPackage.getLocalLabel());
								AnnotationProperty annotationPropertyExternal_plugin = ontModel
										.createAnnotationProperty(METAG + "External_plugin");
								AnnotationProperty annotationPropertyExternal_plugin_resource = ontModel
										.createAnnotationProperty(METAG + "External_plugin_resource");
								ObjectProperty hasImport = ontModel.createObjectProperty(METAG + "hasImport");
								ObjectProperty importPackage = ontModel.createObjectProperty(METAG + "import");
								// Import
								for (ImportPackage m : packages.getImports()) {
									Individual owlImprotIndi = owlPackage.createIndividual(METAG + m.getId());
									owlImprotIndi.addProperty(annotationPropertyExternal_plugin, m.getId());
									owlImprotIndi.addProperty(annotationPropertyLocalLabel, m.getLocalLabel());
									owlImprotIndi.addProperty(annotationPropertyType, m.getType());
									owlImprotIndi.addProperty(annotationPropertyExternal_plugin_resource,
											m.getResource());
									owlPackageIndi.addProperty(hasImport, owlImprotIndi);

								}
								// 遍历嵌套的package
								Queue<Packages> queue = new LinkedList<>();
								queue.add(topPackage);
								while (!queue.isEmpty()) {
									Packages p = queue.poll();
									Individual indi = ontModel.getIndividual(METAG + p.getId());
									for (Model m : p.getModels()) {
										if (ontModel.getIndividual(METAG + m.getId()) != null) {
											indi.addProperty(hasModelProp, ontModel.getIndividual(METAG + m.getId()));
										}
									}
									for (Packages child : p.getPackages()) {
										Individual indiChild = owlPackage.createIndividual(METAG + child.getId());

										if (child.getExternalPlugin().size() != 0) {
											Individual indiImport = ontModel
													.getIndividual(METAG + child.getExternalPlugin().get(0).getId());
											indiChild.addProperty(importPackage, indiImport);
										}
										indiChild.addProperty(annotationPropertyLocalLabel, child.getLocalLabel());
										indi.addProperty(hasPackageProp, indiChild);
										queue.add(child);
									}
								}
							}
						}
					}

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
