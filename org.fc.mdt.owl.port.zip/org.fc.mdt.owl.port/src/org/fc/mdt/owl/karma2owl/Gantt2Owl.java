package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.util.Iterator;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;

public class Gantt2Owl {
	public static void generateGantt(IProject metagProject, OntModel ontModel, boolean isBFO)
			throws CoreException, DocumentException {
		IFolder ganttFolder = null;
		IFolder ganttFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder ganttFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (ganttFolder1.exists()) {
			ganttFolder = ganttFolder1;
		} else if (ganttFolder2.exists()) {
			ganttFolder = ganttFolder2;
		}
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		OntClass owlGanttPluginClass = ontModel.createClass(METAG + "GanttPlugin");
		OntClass owlGanttChartClass = ontModel.createClass(METAG + "GanttChart");
		owlGanttPluginClass.addSubClass(owlGanttChartClass);
		OntClass owlGanttSectionClass = ontModel.createClass(METAG + "GanttSection");
		owlGanttChartClass.addSubClass(owlGanttSectionClass);
		OntClass owlEventClass = ontModel.createClass(METAG + "Event");
		owlGanttSectionClass.addSubClass(owlEventClass);

		// 创建annotaiton property
		AnnotationProperty annotationProName = ontModel.createAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationProActualStartDate = ontModel.createAnnotationProperty(METAG + "ActualStartDate");
		AnnotationProperty annotationProActualActualStartTimeInMillis = ontModel
				.createAnnotationProperty(METAG + "ActualStartTimeInMillis");
		AnnotationProperty annotationProActualEndDate = ontModel.createAnnotationProperty(METAG + "ActualEndDate");
		AnnotationProperty annotationProActualEndTimeInMillis = ontModel
				.createAnnotationProperty(METAG + "ActualEndTimeInMillis");
		AnnotationProperty annotationProPlannedStartDate = ontModel
				.createAnnotationProperty(METAG + "PlannedStartDate");
		AnnotationProperty annotationProPlannedStartTimeInMillis = ontModel
				.createAnnotationProperty(METAG + "PlannedStartTimeInMillis");
		AnnotationProperty annotationProPlannedEndDate = ontModel.createAnnotationProperty(METAG + "PlannedEndDate");
		AnnotationProperty annotationProPlannedEndTimeInMillis = ontModel
				.createAnnotationProperty(METAG + "PlannedEndTimeInMillis");
		AnnotationProperty annotationProPercentComplete = ontModel.createAnnotationProperty(METAG + "PercentComplete");
		AnnotationProperty annotationProId = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationProlocalLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationProlocalValue = ontModel.createAnnotationProperty(METAG + "event_value");

		// 增加gantt标记语言
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");
		ObjectProperty objectProOwn = ontModel.createObjectProperty(METAG + "own");
		if (isBFO) {
			OntClass owlKarmaClass = ontModel.getOntClass(METAG + "KARMA");// 针对BFO的
			owlKarmaClass.addSubClass(owlGanttPluginClass);
		}

		for (IResource fileLanguage : ganttFolder.members()) {
			if (fileLanguage.getType() == IResource.FOLDER) {
				IFolder languageFolder = (IFolder) fileLanguage;
				IFolder fileModel = null;
				IFolder fileModel1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
				IFolder fileModel2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
				if (fileModel1 != null) {
					fileModel = fileModel1;
				} else if (fileModel2 != null) {
					fileModel = fileModel2;
				}
				for (IResource f : fileModel.members()) {
					if (f.getName().endsWith(".gantt")) {
						// 读Gantt文件
						File file = new File(f.getLocation().toOSString());
						SAXReader reader = new SAXReader();
						Document document = reader.read(file);
						Element root = document.getRootElement();
						String ganttName = root.element("Gantt").attribute("Name").getValue();
						// 每一个owlGanttIndividual属于一个Gantt图
						Individual owlGanttIndividual = ontModel.createIndividual(METAG + ganttName,
								owlGanttPluginClass);
						owlGanttIndividual.addProperty(annotationProName, ganttName);
						if (root.element("Gantt").attribute("localLabel") != null) {
							String localLabel = root.element("Gantt").attribute("localLabel").getValue();
							owlGanttIndividual.addProperty(annotationProlocalLabel, localLabel);
						}
						// 增加gannt标记语言
						OntClass owlLanguage = ontModel.getOntClass(METAG + languageFolder.getName());
						if (owlLanguage == null) {
							String languageId = SaveKarInformation.getLanguageId(languageFolder);
							OntClass ontClass = ontModel.getOntClass(METAG + languageId);
							owlGanttIndividual.addProperty(annotationPropertyModelLocation, languageFolder.getName());
						} else {
							owlGanttIndividual.addProperty(annotationPropertyModelLocation, owlLanguage.getLocalName());
						}

						if (root.element("Gantt").element("GanttChart") != null
								&& root.element("Gantt").element("GanttChart").element("GanttSection") != null) {
							Element GanttSection = root.element("Gantt").element("GanttChart").element("GanttSection");
							for (Iterator<Element> it = GanttSection.elementIterator(); it.hasNext();) {
								Element Event = it.next();
								String event_Name = Event.attribute("Name").getValue();
								String event_ActualStartDate = Event.attribute("ActualStartDate").getValue();
								String event_ActualStartTimeInMillis = Event.attribute("ActualStartTimeInMillis")
										.getValue();
								String event_ActualEndDate = Event.attribute("ActualEndDate").getValue();
								String event_ActualEndTimeInMillis = Event.attribute("ActualEndTimeInMillis")
										.getValue();
								String event_PlannedStartDate = Event.attribute("PlannedStartDate").getValue();
								String event_PlannedStartTimeInMillis = Event.attribute("PlannedStartTimeInMillis")
										.getValue();
								String event_PlannedEndDate = Event.attribute("PlannedEndDate").getValue();
								String event_PlannedEndTimeInMillis = Event.attribute("PlannedEndTimeInMillis")
										.getValue();
								String event_PercentComplete = Event.attribute("PercentComplete").getValue();

								Individual event_Individual = ontModel.createIndividual(METAG + ganttName + event_Name,
										owlEventClass);// 待改名称不唯一
								event_Individual.addProperty(annotationProName, event_Name);
								event_Individual.addProperty(annotationProActualStartDate, event_ActualStartDate);
								event_Individual.addProperty(annotationProActualActualStartTimeInMillis,
										event_ActualStartTimeInMillis);
								event_Individual.addProperty(annotationProActualEndDate, event_ActualEndDate);
								event_Individual.addProperty(annotationProActualEndTimeInMillis,
										event_ActualEndTimeInMillis);
								event_Individual.addProperty(annotationProPlannedStartDate, event_PlannedStartDate);
								event_Individual.addProperty(annotationProPlannedStartTimeInMillis,
										event_PlannedStartTimeInMillis);
								event_Individual.addProperty(annotationProPlannedEndDate, event_PlannedEndDate);
								event_Individual.addProperty(annotationProPlannedEndTimeInMillis,
										event_PlannedEndTimeInMillis);
								event_Individual.addProperty(annotationProPercentComplete, event_PercentComplete);

								if (Event.attribute("id") != null && Event.attribute("localLabel") != null
										&& Event.attribute("value") != null) {
									String event_Id = Event.attribute("id").getValue();
									String event_LocalLabel = Event.attribute("localLabel").getValue();
									String event_value = Event.attribute("value").getValue();

									event_Individual.addProperty(annotationProId, event_Id);
									event_Individual.addProperty(annotationProlocalLabel, event_LocalLabel);
									event_Individual.addProperty(annotationProlocalValue, event_value);
								}

								owlGanttIndividual.addProperty(objectProOwn, event_Individual);

							}
						}
					}
				}
			}
		}
	}

}
