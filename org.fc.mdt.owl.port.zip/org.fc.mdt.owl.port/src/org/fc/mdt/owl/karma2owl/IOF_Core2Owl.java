package org.fc.mdt.owl.karma2owl;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.eclipse.core.resources.IProject;

public class IOF_Core2Owl {
	public static void generateIOF_Core(IProject metagProject, OntModel ontModel) {
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
//		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);

		// 1.先创建框架
		// 1.1框架中的类
		OntClass owlEntityClass = ontModel.createClass(METAG + "entity");
		OntClass owlContinuantClass = ontModel.createClass(METAG + "continuant");
		owlEntityClass.addSubClass(owlContinuantClass);
		OntClass owlGdcClass = ontModel.createClass(METAG + "generically_dependent_continuant");
		owlContinuantClass.addSubClass(owlGdcClass);
		OntClass owlIctClass = ontModel.createClass(METAG + "Information_Content_Entity");
		owlGdcClass.addSubClass(owlIctClass);
		OntClass owlActionSpecificationClass = ontModel.createClass(METAG + "Action_Specification");
		owlIctClass.addSubClass(owlActionSpecificationClass);
		OntClass owlAgreementClass = ontModel.createClass(METAG + "Agreement");
		owlIctClass.addSubClass(owlAgreementClass);
		OntClass owlCommercialServiceAgreementClass = ontModel.createClass(METAG + "CommercialServiceAgreement");
		owlAgreementClass.addSubClass(owlCommercialServiceAgreementClass);
		OntClass owlAlgorithmClass = ontModel.createClass(METAG + "Algorithm");
		owlIctClass.addSubClass(owlAlgorithmClass);
		OntClass owlDescriptiveIceClass = ontModel.createClass(METAG + "DescriptiveInformationContentEntity");
		owlIctClass.addSubClass(owlDescriptiveIceClass);
		OntClass owlDesignativeIceClass = ontModel.createClass(METAG + "DesignativeInformationContentEntity");
		owlIctClass.addSubClass(owlDesignativeIceClass);
		OntClass owlDesignSpecificationClass = ontModel.createClass(METAG + "DesignSpecification");
		owlIctClass.addSubClass(owlDesignSpecificationClass);
		OntClass owlDirectiveIceClass = ontModel.createClass(METAG + "DirectiveInformationContentEntity");
		owlIctClass.addSubClass(owlDirectiveIceClass);
		OntClass owlIdentifierClass = ontModel.createClass(METAG + "Identifier");
		owlIctClass.addSubClass(owlIdentifierClass);
		OntClass owlOrganizationIdentifierClass = ontModel.createClass(METAG + "OrganizationIdentifier");
		owlIdentifierClass.addSubClass(owlOrganizationIdentifierClass);
		OntClass owlPhysicalLocationIdentifierClass = ontModel.createClass(METAG + "PhysicalLocationIdentifier");
		owlIdentifierClass.addSubClass(owlPhysicalLocationIdentifierClass);
		OntClass owlMeasurementInformationContentEntityClass = ontModel
				.createClass(METAG + "MeasurementInformationContentEntity");
		owlIctClass.addSubClass(owlMeasurementInformationContentEntityClass);
		OntClass owlObjectiveSpecificationClass = ontModel.createClass(METAG + "ObjectiveSpecification");
		owlIctClass.addSubClass(owlObjectiveSpecificationClass);
		OntClass owlPlanSpecificationClass = ontModel.createClass(METAG + "PlanSpecification");
		owlIctClass.addSubClass(owlPlanSpecificationClass);
		OntClass owlCommercialServiceSpecificationClass = ontModel
				.createClass(METAG + "CommercialServiceSpecification");
		owlPlanSpecificationClass.addSubClass(owlCommercialServiceSpecificationClass);
		OntClass owlEncodedAlgorithmClass = ontModel.createClass(METAG + "EncodedAlgorithm");
		owlPlanSpecificationClass.addSubClass(owlEncodedAlgorithmClass);
		OntClass owlRequirementSpecificationClass = ontModel.createClass(METAG + "RequirementSpecification");
		owlIctClass.addSubClass(owlRequirementSpecificationClass);
		OntClass owlValueExpressionClass = ontModel.createClass(METAG + "ValueExpression");
		owlIctClass.addSubClass(owlValueExpressionClass);
		OntClass owlMeasuredValueExpressionClass = ontModel.createClass(METAG + "MeasuredValueExpression");
		owlValueExpressionClass.addSubClass(owlMeasuredValueExpressionClass);

		OntClass owlIndependentContinuantClass = ontModel.createClass(METAG + "independent_continuant");
		owlContinuantClass.addSubClass(owlIndependentContinuantClass);
		OntClass owlImmaterialEntityClass = ontModel.createClass(METAG + "immaterial_entity");
		owlIndependentContinuantClass.addSubClass(owlImmaterialEntityClass);
		OntClass owlContinuantFiatBoundaryClass = ontModel.createClass(METAG + "continuant_fiat_boundary");
		owlImmaterialEntityClass.addSubClass(owlContinuantFiatBoundaryClass);
		OntClass owlFiatLineClass = ontModel.createClass(METAG + "fiat_line");
		owlContinuantFiatBoundaryClass.addSubClass(owlFiatLineClass);
		OntClass owlFiatPointClass = ontModel.createClass(METAG + "fiat_point");
		owlContinuantFiatBoundaryClass.addSubClass(owlFiatPointClass);
		OntClass owlFiatSurfaceClass = ontModel.createClass(METAG + "fiat_surface");
		owlContinuantFiatBoundaryClass.addSubClass(owlFiatSurfaceClass);
		OntClass owlSiteClass = ontModel.createClass(METAG + "site");
		owlImmaterialEntityClass.addSubClass(owlSiteClass);
		OntClass owlSpatialRegionClass = ontModel.createClass(METAG + "spatial_region");
		owlImmaterialEntityClass.addSubClass(owlSpatialRegionClass);
		OntClass owlOnedimensionalSpatialRegionClass = ontModel.createClass(METAG + "one_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlOnedimensionalSpatialRegionClass);
		OntClass owlThreedimensionalSpatialRegionClass = ontModel
				.createClass(METAG + "three_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlThreedimensionalSpatialRegionClass);
		OntClass owlTwodimensionalSpatialRegionClass = ontModel.createClass(METAG + "two_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlTwodimensionalSpatialRegionClass);
		OntClass owlZerodimensionalSpatialRegionClass = ontModel.createClass(METAG + "zero_dimensional_spatial_region");
		owlSpatialRegionClass.addSubClass(owlZerodimensionalSpatialRegionClass);
		OntClass owlMaterialEntityClass = ontModel.createClass(METAG + "material_entity");
		owlIndependentContinuantClass.addSubClass(owlMaterialEntityClass);
		OntClass owlAgentClass = ontModel.createClass(METAG + "Agent");
		owlMaterialEntityClass.addSubClass(owlAgentClass);
		OntClass owlBuyerClass = ontModel.createClass(METAG + "Buyer");
		owlAgentClass.addSubClass(owlBuyerClass);
		OntClass owlCustomerClass = ontModel.createClass(METAG + "Customer");
		owlAgentClass.addSubClass(owlCustomerClass);
		OntClass owlManufacturerClass = ontModel.createClass(METAG + "Manufacturer");
		owlAgentClass.addSubClass(owlManufacturerClass);
		OntClass owlSupplierClass = ontModel.createClass(METAG + "Supplier");
		owlAgentClass.addSubClass(owlSupplierClass);
		OntClass owlServiceProviderClass = ontModel.createClass(METAG + "ServiceProvider");
		owlSupplierClass.addSubClass(owlServiceProviderClass);
		OntClass owlFiatObjectPartClass = ontModel.createClass(METAG + "fiat_object_part");
		owlMaterialEntityClass.addSubClass(owlFiatObjectPartClass);
		OntClass owlMaintainableMaterialItemClass = ontModel.createClass(METAG + "MaintainableMaterialItem");
		owlMaterialEntityClass.addSubClass(owlMaintainableMaterialItemClass);
		OntClass owlMaterialComponentClass = ontModel.createClass(METAG + "MaterialComponent");
		owlMaterialEntityClass.addSubClass(owlMaterialComponentClass);
		OntClass owlMaterialProductClass = ontModel.createClass(METAG + "MaterialProduct");
		owlMaterialEntityClass.addSubClass(owlMaterialProductClass);
		OntClass owlMaterialResourceClass = ontModel.createClass(METAG + "MaterialResource");
		owlMaterialEntityClass.addSubClass(owlMaterialResourceClass);
		OntClass owlObjectClass = ontModel.createClass(METAG + "IOF_Core_object");// object与KARMA中的重复
		owlMaterialEntityClass.addSubClass(owlObjectClass);
		OntClass owlMaterialArtifactClass = ontModel.createClass(METAG + "MaterialArtifact");
		owlObjectClass.addSubClass(owlMaterialArtifactClass);
		OntClass owlAssemblyClass = ontModel.createClass(METAG + "Assembly");
		owlMaterialArtifactClass.addSubClass(owlAssemblyClass);
		OntClass owlPieceOfEquipmentClass = ontModel.createClass(METAG + "PieceOfEquipment");
		owlMaterialArtifactClass.addSubClass(owlPieceOfEquipmentClass);
		OntClass owlPersonClass = ontModel.createClass(METAG + "Person");
		owlObjectClass.addSubClass(owlPersonClass);
		OntClass owlObjectAggregateClass = ontModel.createClass(METAG + "object_aggregate");
		owlMaterialEntityClass.addSubClass(owlObjectAggregateClass);
		OntClass owlGroupofAgentsClass = ontModel.createClass(METAG + "GroupOfAgents");
		owlObjectAggregateClass.addSubClass(owlGroupofAgentsClass);
		OntClass owlOrganizedGroupOfAgentsClass = ontModel.createClass(METAG + "OrganizedGroupOfAgents");
		owlGroupofAgentsClass.addSubClass(owlOrganizedGroupOfAgentsClass);
		OntClass owlOrganizationClass = ontModel.createClass(METAG + "Organization");
		owlOrganizedGroupOfAgentsClass.addSubClass(owlOrganizationClass);
		OntClass owlBusinessOrganizationClass = ontModel.createClass(METAG + "BusinessOrganization");
		owlOrganizationClass.addSubClass(owlBusinessOrganizationClass);
//		OntClass owlManufacturerClass = ontModel.createClass(METAG + "Manufacturer");
		owlOrganizationClass.addSubClass(owlManufacturerClass);
		OntClass owlSystemClass = ontModel.createClass(METAG + "IOF_Core_System");// System与KARMA中的重复
		owlObjectAggregateClass.addSubClass(owlSystemClass);
		OntClass owlEngineeredSystemClass = ontModel.createClass(METAG + "EngineeredSystem");
		owlSystemClass.addSubClass(owlEngineeredSystemClass);
		OntClass owlRawMaterialClass = ontModel.createClass(METAG + "RawMaterial");
		owlMaterialEntityClass.addSubClass(owlRawMaterialClass);

		OntClass owlSpeciallyDependentContinuantClass = ontModel.createClass(METAG + "specially_dependent_continuant");
		owlContinuantClass.addSubClass(owlSpeciallyDependentContinuantClass);
		OntClass owlQualityClass = ontModel.createClass(METAG + "quality");
		owlSpeciallyDependentContinuantClass.addSubClass(owlQualityClass);
		OntClass owlRelationalQualityClass = ontModel.createClass(METAG + "relational_quality");
		owlQualityClass.addSubClass(owlRelationalQualityClass);
		OntClass owlRealizableEntityClass = ontModel.createClass(METAG + "realizable_entity");
		owlSpeciallyDependentContinuantClass.addSubClass(owlRealizableEntityClass);
		OntClass owlDispositionClass = ontModel.createClass(METAG + "disposition");
		owlRealizableEntityClass.addSubClass(owlDispositionClass);
		OntClass owlCapabilityClass = ontModel.createClass(METAG + "Capability");
		owlDispositionClass.addSubClass(owlCapabilityClass);
		OntClass owlFunctionClass = ontModel.createClass(METAG + "IOF_Core_function");
		owlCapabilityClass.addSubClass(owlFunctionClass);
		OntClass owlBusinessFunctionClass = ontModel.createClass(METAG + "BusinessFunction");
		owlFunctionClass.addSubClass(owlBusinessFunctionClass);
		OntClass owlMeasurementCapabilityClass = ontModel.createClass(METAG + "MeasurementCapability");
		owlCapabilityClass.addSubClass(owlMeasurementCapabilityClass);
//		OntClass owlFunctionClass = ontModel.createClass(METAG + "IOF_Core_function");// 与前面重复了
		owlDispositionClass.addSubClass(owlFunctionClass);
//		OntClass owlBusinessFunctionClass = ontModel.createClass(METAG + "BusinessFunction");
		owlFunctionClass.addSubClass(owlBusinessFunctionClass);
		OntClass owlRoleClass = ontModel.createClass(METAG + "IOF_Core_role");// role与KARMA中的重复
		owlRealizableEntityClass.addSubClass(owlRoleClass);
		OntClass owlAgentRoleClass = ontModel.createClass(METAG + "AgentRole");
		owlRoleClass.addSubClass(owlAgentRoleClass);
		OntClass owlBuyerRoleClass = ontModel.createClass(METAG + "BuyerRole");
		owlAgentRoleClass.addSubClass(owlBuyerRoleClass);
		OntClass owlCustomerRoleClass = ontModel.createClass(METAG + "CustomerRole");
		owlAgentRoleClass.addSubClass(owlCustomerRoleClass);
		OntClass owlManufacturerRoleClass = ontModel.createClass(METAG + "ManufacturerRole");
		owlAgentRoleClass.addSubClass(owlManufacturerRoleClass);
		OntClass owlSupplierRoleClass = ontModel.createClass(METAG + "SupplierRole");
		owlAgentRoleClass.addSubClass(owlSupplierRoleClass);
		OntClass owlServiceProviderRoleClass = ontModel.createClass(METAG + "ServiceProviderRole");
		owlSupplierRoleClass.addSubClass(owlServiceProviderRoleClass);
		OntClass owlEquipmentRoleClass = ontModel.createClass(METAG + "EquipmentRole");
		owlRoleClass.addSubClass(owlEquipmentRoleClass);
		OntClass owlMaintainableMaterialItemRoleClass = ontModel.createClass(METAG + "MaintainableMaterialItemRole");
		owlRoleClass.addSubClass(owlMaintainableMaterialItemRoleClass);
		OntClass owlMaterialComponentRoleClass = ontModel.createClass(METAG + "MaterialComponentRole");
		owlRoleClass.addSubClass(owlMaterialComponentRoleClass);
		OntClass owlMaterialProductRoleClass = ontModel.createClass(METAG + "MaterialProductRole");
		owlRoleClass.addSubClass(owlMaterialProductRoleClass);
		OntClass owlMaterialResourceRoleClass = ontModel.createClass(METAG + "MaterialResourceRole");
		owlRoleClass.addSubClass(owlMaterialResourceRoleClass);
		OntClass owlRawMaterialRoleClass = ontModel.createClass(METAG + "RawMaterialRole");
		owlRoleClass.addSubClass(owlRawMaterialRoleClass);

		OntClass owlOccurrentClass = ontModel.createClass(METAG + "occurrent");
		owlEntityClass.addSubClass(owlOccurrentClass);
		OntClass owlEventClass = ontModel.createClass(METAG + "Event");
		owlOccurrentClass.addSubClass(owlEventClass);
		OntClass owlProcessClass = ontModel.createClass(METAG + "IOF_Core_process");// process与KARMA中的重复
		owlOccurrentClass.addSubClass(owlProcessClass);
		OntClass owlHistoryClass = ontModel.createClass(METAG + "history");
		owlProcessClass.addSubClass(owlHistoryClass);
		OntClass owlMaterialStateClass = ontModel.createClass(METAG + "MaterialState");
		owlProcessClass.addSubClass(owlMaterialStateClass);
		OntClass owlPlannedProcessClass = ontModel.createClass(METAG + "PlannedProcess");
		owlProcessClass.addSubClass(owlPlannedProcessClass);
		OntClass owlBusinessProcessClass = ontModel.createClass(METAG + "BusinessProcess");
		owlPlannedProcessClass.addSubClass(owlBusinessProcessClass);
		OntClass owlBuyingBusinessProcessClass = ontModel.createClass(METAG + "BuyingBusinessProcess");
		owlBusinessProcessClass.addSubClass(owlBuyingBusinessProcessClass);
		OntClass owlCommercialServiceClass = ontModel.createClass(METAG + "CommercialService");
		owlBusinessProcessClass.addSubClass(owlCommercialServiceClass);
		OntClass owlProcuringBusinessProcessClass = ontModel.createClass(METAG + "ProcuringBusinessProcess");
		owlBusinessProcessClass.addSubClass(owlProcuringBusinessProcessClass);
		OntClass owlProductProductionProcessClass = ontModel.createClass(METAG + "ProductProductionProcess");
		owlBusinessProcessClass.addSubClass(owlProductProductionProcessClass);
		OntClass owlSellingBusinessProcessClass = ontModel.createClass(METAG + "SellingBusinessProcess");
		owlBusinessProcessClass.addSubClass(owlSellingBusinessProcessClass);
		OntClass owlSupplyingBusinessProcessClass = ontModel.createClass(METAG + "SupplyingBusinessProcess");
		owlBusinessProcessClass.addSubClass(owlSupplyingBusinessProcessClass);
		OntClass owlComputingProcessClass = ontModel.createClass(METAG + "ComputingProcess");
		owlPlannedProcessClass.addSubClass(owlComputingProcessClass);
		OntClass owlManufacturingProcessClass = ontModel.createClass(METAG + "ManufacturingProcess");
		owlPlannedProcessClass.addSubClass(owlManufacturingProcessClass);
		OntClass owlAssemblyProcessClass = ontModel.createClass(METAG + "AssemblyProcess");
		owlManufacturingProcessClass.addSubClass(owlAssemblyProcessClass);
		OntClass owlMaterialLocationChangeProcessClass = ontModel.createClass(METAG + "MaterialLocationChangeProcess");
		owlPlannedProcessClass.addSubClass(owlMaterialLocationChangeProcessClass);
		OntClass owlMeasurementProcessClass = ontModel.createClass(METAG + "MeasurementProcess");
		owlPlannedProcessClass.addSubClass(owlMeasurementProcessClass);
		OntClass owlProcessBoundaryClass = ontModel.createClass(METAG + "process_boundary");
		owlOccurrentClass.addSubClass(owlProcessBoundaryClass);
		OntClass owlProcessCharacteristicClass = ontModel.createClass(METAG + "ProcessCharacteristic");
		owlOccurrentClass.addSubClass(owlProcessCharacteristicClass);
		OntClass owlSpatiotemporalRegionClass = ontModel.createClass(METAG + "spatiotemporal_region");
		owlOccurrentClass.addSubClass(owlSpatiotemporalRegionClass);
		OntClass owlTemporalRegionClass = ontModel.createClass(METAG + "temporal_region");
		owlOccurrentClass.addSubClass(owlTemporalRegionClass);
		OntClass owlOnedimensionalTemporalRegionClass = ontModel.createClass(METAG + "one_dimensional_temporal_region");
		owlTemporalRegionClass.addSubClass(owlOnedimensionalTemporalRegionClass);
		OntClass owlTemporalIntervalClass = ontModel.createClass(METAG + "temporal_interval");
		owlOnedimensionalTemporalRegionClass.addSubClass(owlTemporalIntervalClass);
		OntClass owlZerodimensionalTemporalRegionClass = ontModel
				.createClass(METAG + "zero_dimensional_temporal_region");
		owlTemporalRegionClass.addSubClass(owlZerodimensionalTemporalRegionClass);
		OntClass owlTemporalInstantClass = ontModel.createClass(METAG + "temporal_instant");
		owlZerodimensionalTemporalRegionClass.addSubClass(owlTemporalInstantClass);

		OntClass owlKarmaClass = ontModel.createClass(METAG + "KARMA");
		owlDesignSpecificationClass.addSubClass(owlKarmaClass);
		OntClass owlDSMClass = ontModel.createClass(METAG + "DSM");
		owlDesignSpecificationClass.addSubClass(owlDSMClass);
		OntClass owlReqIFClass = ontModel.createClass(METAG + "ReqIF");
		owlRequirementSpecificationClass.addSubClass(owlReqIFClass);

		// 1.2框架中的AnnotationProperty
		AnnotationProperty annotationProContributor = ontModel.createAnnotationProperty(METAG + "dc:contributor");
		AnnotationProperty annotationProIdentifier = ontModel.createAnnotationProperty(METAG + "dc:identifier");
		AnnotationProperty annotationProDcLicense = ontModel.createAnnotationProperty(METAG + "dc:license");
		AnnotationProperty annotationProDctermsContributor = ontModel
				.createAnnotationProperty(METAG + "dcterms:contributor");
		AnnotationProperty annotationProDctermsCreator = ontModel.createAnnotationProperty(METAG + "dcterms:creator");
		annotationProDctermsCreator.addSuperProperty(annotationProDctermsContributor);
		AnnotationProperty annotationProMaintainer = ontModel.createAnnotationProperty(METAG + "maintainer");
		annotationProMaintainer.addSuperProperty(annotationProDctermsContributor);
		AnnotationProperty annotationProDctermsIssued = ontModel.createAnnotationProperty(METAG + "dcterms:issued");
		AnnotationProperty annotationProDctermsLicense = ontModel.createAnnotationProperty(METAG + "dcterms:license");
		AnnotationProperty annotationProDctermsModified = ontModel.createAnnotationProperty(METAG + "dcterms:modified");
		AnnotationProperty annotationProDctermsPublisher = ontModel
				.createAnnotationProperty(METAG + "dcterms:publisher");
		AnnotationProperty annotationProDctermsReferences = ontModel
				.createAnnotationProperty(METAG + "dcterms:references");
		AnnotationProperty annotationProDctermsRights = ontModel.createAnnotationProperty(METAG + "dcterms:rights");
		AnnotationProperty annotationProCopyright = ontModel.createAnnotationProperty(METAG + "copyright");
		annotationProCopyright.addSuperProperty(annotationProDctermsRights);
		AnnotationProperty annotationProDctermsSource = ontModel.createAnnotationProperty(METAG + "dcterms:source");
		AnnotationProperty annotationProAdaptedFrom = ontModel.createAnnotationProperty(METAG + "adaptedFrom");
		annotationProAdaptedFrom.addSuperProperty(annotationProDctermsSource);
		AnnotationProperty annotationProDirectSource = ontModel.createAnnotationProperty(METAG + "directSource");
		annotationProDirectSource.addSuperProperty(annotationProDctermsSource);
		AnnotationProperty annotationProExcerptedFrom = ontModel.createAnnotationProperty(METAG + "excerptedFrom");
		annotationProExcerptedFrom.addSuperProperty(annotationProDctermsSource);
		AnnotationProperty annotationProDctermsTitle = ontModel.createAnnotationProperty(METAG + "dcterms:title");
		AnnotationProperty annotationProIsPrimitive = ontModel.createAnnotationProperty(METAG + "isPrimitive");
		AnnotationProperty annotationProMaturity = ontModel.createAnnotationProperty(METAG + "maturity");
		AnnotationProperty annotationProOwlBackwardCompatibleWith = ontModel
				.createAnnotationProperty(METAG + "owl:backwardCompatibleWith");
		AnnotationProperty annotationProOwlDeprecated = ontModel.createAnnotationProperty(METAG + "owl:deprecated");
		AnnotationProperty annotationProOwlIncompatibleWith = ontModel
				.createAnnotationProperty(METAG + "owl:incompatibleWith");
		AnnotationProperty annotationProOwlPriorVersion = ontModel.createAnnotationProperty(METAG + "owl:priorVersion");
		AnnotationProperty annotationProOwlVersionInfo = ontModel.createAnnotationProperty(METAG + "owl:versionInfo");
		AnnotationProperty annotationProRdfsComment = ontModel.createAnnotationProperty(METAG + "rdfs:comment");
		AnnotationProperty annotationProRdfsIsDefinedBy = ontModel.createAnnotationProperty(METAG + "rdfs:isDefinedBy");
		AnnotationProperty annotationProRdfsLabel = ontModel.createAnnotationProperty(METAG + "rdfs:label");
		AnnotationProperty annotationProSkosAltLabel = ontModel.createAnnotationProperty(METAG + "skos:altLabel");
		annotationProSkosAltLabel.addSuperProperty(annotationProRdfsLabel);
		AnnotationProperty annotationProAbbreviation = ontModel.createAnnotationProperty(METAG + "abbreviation");
		annotationProAbbreviation.addSuperProperty(annotationProSkosAltLabel);
		AnnotationProperty annotationProAcronym = ontModel.createAnnotationProperty(METAG + "acronym");
		annotationProAcronym.addSuperProperty(annotationProAbbreviation);
		AnnotationProperty annotationProSymbol = ontModel.createAnnotationProperty(METAG + "symbol");
		annotationProSymbol.addSuperProperty(annotationProAbbreviation);
		AnnotationProperty annotationProSynonym = ontModel.createAnnotationProperty(METAG + "synonym");
		annotationProSynonym.addSuperProperty(annotationProSkosAltLabel);
		AnnotationProperty annotationProRdfsSeeAlso = ontModel.createAnnotationProperty(METAG + "rdfs:seeAlso");
		AnnotationProperty annotationProSkosNote = ontModel.createAnnotationProperty(METAG + "skos:note");
		AnnotationProperty annotationProCounterExample = ontModel.createAnnotationProperty(METAG + "counter_example");
		annotationProCounterExample.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProDctermsDescription = ontModel
				.createAnnotationProperty(METAG + "dcterms:description");
		annotationProDctermsDescription.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProDctermsAbstract = ontModel.createAnnotationProperty(METAG + "dcterms:abstract");
		annotationProDctermsAbstract.addSuperProperty(annotationProDctermsDescription);
		AnnotationProperty annotationProExplanatoryNote = ontModel.createAnnotationProperty(METAG + "explanatoryNote");
		annotationProExplanatoryNote.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProLogicAxiom = ontModel.createAnnotationProperty(METAG + "logicAxiom");
		annotationProLogicAxiom.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProFirstOrderLogicAxiom = ontModel
				.createAnnotationProperty(METAG + "firstOrderLogicAxiom");
		annotationProFirstOrderLogicAxiom.addSuperProperty(annotationProLogicAxiom);
		AnnotationProperty annotationProSemiFormalNaturalLanguageAxiom = ontModel
				.createAnnotationProperty(METAG + "semiFormalNaturalLanguageAxiom");
		annotationProSemiFormalNaturalLanguageAxiom.addSuperProperty(annotationProLogicAxiom);
		AnnotationProperty annotationProPrimitiveRationale = ontModel
				.createAnnotationProperty(METAG + "primitiveRationale");
		annotationProPrimitiveRationale.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProSkosChangeNote = ontModel.createAnnotationProperty(METAG + "skos:changeNote");
		annotationProSkosChangeNote.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProSkosDefinition = ontModel.createAnnotationProperty(METAG + "skos:definition");
		annotationProSkosDefinition.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProLogicDefinition = ontModel.createAnnotationProperty(METAG + "logicDefinition");
		annotationProLogicDefinition.addSuperProperty(annotationProSkosDefinition);
		AnnotationProperty annotationProFirstOrderLogicDefinition = ontModel
				.createAnnotationProperty(METAG + "firstOrderLogicDefinition");
		annotationProFirstOrderLogicDefinition.addSuperProperty(annotationProLogicDefinition);
		AnnotationProperty annotationProSemiFormalNaturalLanguageDefinition = ontModel
				.createAnnotationProperty(METAG + "semiFormalNaturalLanguageDefinition");
		annotationProSemiFormalNaturalLanguageDefinition.addSuperProperty(annotationProLogicDefinition);
		AnnotationProperty annotationProNaturalLanguageDefinition = ontModel
				.createAnnotationProperty(METAG + "naturalLanguageDefinition");
		annotationProNaturalLanguageDefinition.addSuperProperty(annotationProSkosDefinition);
		AnnotationProperty annotationProSubjectMatterExpertExplanation = ontModel
				.createAnnotationProperty(METAG + "subject_matter_expert_explanation");
		annotationProSubjectMatterExpertExplanation.addSuperProperty(annotationProSkosDefinition);
		AnnotationProperty annotationProSkosEditorialNote = ontModel
				.createAnnotationProperty(METAG + "skos:editorialNote");
		annotationProSkosEditorialNote.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProSkosExample = ontModel.createAnnotationProperty(METAG + "skos:example");
		annotationProSkosExample.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProUsageNote = ontModel.createAnnotationProperty(METAG + "usageNote");
		annotationProUsageNote.addSuperProperty(annotationProSkosNote);
		AnnotationProperty annotationProprefLabel = ontModel.createAnnotationProperty(METAG + "skos:prefLabel");
		AnnotationProperty annotationProscopeNote = ontModel.createAnnotationProperty(METAG + "skos:scopeNote");

		// 用于表示文件与文件内的关系
		ObjectProperty objectProOwn = ontModel.createObjectProperty(METAG + "own");
		ObjectProperty objectProEqual =ontModel.createObjectProperty(METAG + "equal_to");

		// 1.3框架中的ObjectProperty
		ObjectProperty objectProActsOnBehalfOfAtSomeTime = ontModel
				.createObjectProperty(METAG + "actsOnBehalfOfAtSomeTime");
		ObjectProperty objectProConcretizesAtSomeTime = ontModel.createObjectProperty(METAG + "concretizesAtSomeTime");
		ObjectProperty objectProAchievesAtSomeTime = ontModel.createObjectProperty(METAG + "achievesAtSomeTime");
		objectProAchievesAtSomeTime.addSuperProperty(objectProConcretizesAtSomeTime);
		ObjectProperty objectProConcretizesAtAllTimes = ontModel.createObjectProperty(METAG + "concretizesAtAllTimes");
		objectProConcretizesAtAllTimes.addSuperProperty(objectProConcretizesAtSomeTime);
		ObjectProperty objectProContinuantPartOfAtSometime = ontModel
				.createObjectProperty(METAG + "continuant_part_of_at_some_time");
		ObjectProperty objectProContinuantPartOfAtAllTimes = ontModel
				.createObjectProperty(METAG + "continuant_part_of_at_all_times");
		objectProContinuantPartOfAtAllTimes.addSuperProperty(objectProContinuantPartOfAtSometime);
		ObjectProperty objectProMemberPartOfAtAllTimes = ontModel
				.createObjectProperty(METAG + "member_part_of_at_all_times");
		objectProMemberPartOfAtAllTimes.addSuperProperty(objectProContinuantPartOfAtAllTimes);
		ObjectProperty objectProProperContinuantPartOfAtAllTimes = ontModel
				.createObjectProperty(METAG + "proper_continuant_part_of_at_all_times");
		objectProProperContinuantPartOfAtAllTimes.addSuperProperty(objectProContinuantPartOfAtAllTimes);
		ObjectProperty objectProComponentPartOfAtAllTimes = ontModel
				.createObjectProperty(METAG + "componentPartOfAtAllTimes");
		objectProComponentPartOfAtAllTimes.addSuperProperty(objectProProperContinuantPartOfAtAllTimes);		
		ObjectProperty objectProMemberPartOfAtSometime = ontModel
				.createObjectProperty(METAG + "member_part_of_at_some_time");
		objectProMemberPartOfAtSometime.addSuperProperty(objectProContinuantPartOfAtSometime);		
//		ObjectProperty objectProMemberPartOfAtAllTimes = ontModel
//				.createObjectProperty(METAG + "member_part_of_at_all_times");
		objectProMemberPartOfAtAllTimes.addSuperProperty(objectProMemberPartOfAtSometime);		
		ObjectProperty objectProProperContinuantPartOfAtSometime = ontModel
				.createObjectProperty(METAG + "proper_continuant_part_of_at_some_time");
		objectProProperContinuantPartOfAtSometime.addSuperProperty(objectProContinuantPartOfAtSometime);
		ObjectProperty objectProComponentPartOfAtSomeTime = ontModel
				.createObjectProperty(METAG + "componentPartOfAtSomeTime");
		objectProComponentPartOfAtSomeTime.addSuperProperty(objectProProperContinuantPartOfAtSometime);
//		ObjectProperty objectProComponentPartOfAtAllTimes = ontModel
//				.createObjectProperty(METAG + "componentPartOfAtAllTimes");
		objectProComponentPartOfAtAllTimes.addSuperProperty(objectProComponentPartOfAtSomeTime);		
//		ObjectProperty objectProProperContinuantPartOfAtAllTimes = ontModel
//				.createObjectProperty(METAG + "proper_continuant_part_of_at_all_times");
		objectProProperContinuantPartOfAtAllTimes.addSuperProperty(objectProProperContinuantPartOfAtSometime);
//		ObjectProperty objectProComponentPartOfAtAllTimes = ontModel
//				.createObjectProperty(METAG + "componentPartOfAtAllTimes");
		objectProComponentPartOfAtAllTimes.addSuperProperty(objectProProperContinuantPartOfAtAllTimes);		
		ObjectProperty objectProEnvirons = ontModel.createObjectProperty(METAG + "environs");
		ObjectProperty objectProExistsAt = ontModel.createObjectProperty(METAG + "exists_at");
		ObjectProperty objectProFirstInstantOf = ontModel.createObjectProperty(METAG + "first_instant_of");
		ObjectProperty objectProGenericallyDependsOnAtSometime = ontModel
				.createObjectProperty(METAG + "generically_depends_on_at_some_time");
		ObjectProperty objectProGenericallyDependsOnAtAllTimes = ontModel
				.createObjectProperty(METAG + "generically_depends_on_at_all_times");
		objectProGenericallyDependsOnAtAllTimes.addSuperProperty(objectProGenericallyDependsOnAtSometime);

		ObjectProperty objectProHasContinuantPartAtSometime = ontModel
				.createObjectProperty(METAG + "has_continuant_part_at_some_time");
		ObjectProperty objectProHasContinuantPartAtAllTimes = ontModel
				.createObjectProperty(METAG + "has_continuant_part_at_all_times");
		objectProHasContinuantPartAtAllTimes.addSuperProperty(objectProHasContinuantPartAtSometime);
		ObjectProperty objectProHasMemberPartAtAllTimes = ontModel
				.createObjectProperty(METAG + "has_member_part_at_all_times");
		objectProHasMemberPartAtAllTimes.addSuperProperty(objectProHasContinuantPartAtAllTimes);
		ObjectProperty objectProHasProperContinuantPartatAllTimes = ontModel
				.createObjectProperty(METAG + "has_proper_continuant_part_at_all_times");
		objectProHasProperContinuantPartatAllTimes.addSuperProperty(objectProHasContinuantPartAtAllTimes);
		ObjectProperty objectProHasComponentPartAtAllTimes = ontModel
				.createObjectProperty(METAG + "hasComponentPartAtAllTimes");
		objectProHasComponentPartAtAllTimes.addSuperProperty(objectProHasProperContinuantPartatAllTimes);
		ObjectProperty objectProHasMemberPartAtSometime = ontModel
				.createObjectProperty(METAG + "has_member_part_at_some_time");
		objectProHasMemberPartAtSometime.addSuperProperty(objectProHasContinuantPartAtSometime);
//		ObjectProperty objectProHasMemberPartAtAllTimes = ontModel
//				.createObjectProperty(METAG + "has_member_part_at_all_times");
		objectProHasMemberPartAtAllTimes.addSuperProperty(objectProHasMemberPartAtSometime);
		ObjectProperty objectProHasProperContinuantPartAtSometime = ontModel
				.createObjectProperty(METAG + "has_proper_continuant_part_at_some_time");
		objectProHasProperContinuantPartAtSometime.addSuperProperty(objectProHasContinuantPartAtSometime);
		ObjectProperty objectProHasProperContinuantPartAtAllTimes = ontModel
				.createObjectProperty(METAG + "has_proper_continuant_part_at_all_times");
		objectProHasProperContinuantPartAtAllTimes.addSuperProperty(objectProHasProperContinuantPartAtSometime);
//		ObjectProperty objectProHasComponentPartAtAllTimes = ontModel
//				.createObjectProperty(METAG + "hasComponentPartAtAllTimes");
		objectProHasComponentPartAtAllTimes.addSuperProperty(objectProHasProperContinuantPartAtAllTimes);
		ObjectProperty objectProHasComponentPartAtSomeTime = ontModel
				.createObjectProperty(METAG + "hasComponentPartAtSomeTime");
		objectProHasComponentPartAtSomeTime.addSuperProperty(objectProHasProperContinuantPartAtSometime);
//		ObjectProperty objectProHasComponentPartAtAllTimes = ontModel
//				.createObjectProperty(METAG + "hasComponentPartAtAllTimes");
		objectProHasComponentPartAtAllTimes.addSuperProperty(objectProHasComponentPartAtSomeTime);
		ObjectProperty objectProHasFirstInstant = ontModel.createObjectProperty(METAG + "has_first_instant");
		ObjectProperty objectProHasHistory = ontModel.createObjectProperty(METAG + "has_history");
		ObjectProperty objectProHasLastInstant = ontModel.createObjectProperty(METAG + "has_last_instant");
		ObjectProperty objectProHasMaterialBasisAtSometime = ontModel
				.createObjectProperty(METAG + "has_material_basis_at_some_time");
		ObjectProperty objectProHasMaterialBasisAtAllTimes = ontModel
				.createObjectProperty(METAG + "has_material_basis_at_all_times");
		objectProHasMaterialBasisAtAllTimes.addSuperProperty(objectProHasMaterialBasisAtSometime);
		ObjectProperty objectProHasOccurrentPart = ontModel.createObjectProperty(METAG + "has_occurrent_part");
		ObjectProperty objectProHasProperOccurrentPart = ontModel
				.createObjectProperty(METAG + "has_proper_occurrent_part");
		objectProHasProperOccurrentPart.addSuperProperty(objectProHasOccurrentPart);
		ObjectProperty objectProHasTemporalPart = ontModel.createObjectProperty(METAG + "has_temporal_part");
		objectProHasTemporalPart.addSuperProperty(objectProHasOccurrentPart);
		ObjectProperty objectProHasProperTemporalPart = ontModel
				.createObjectProperty(METAG + "has_proper_temporal_part");
		objectProHasProperTemporalPart.addSuperProperty(objectProHasTemporalPart);
		ObjectProperty objectProHasParticipantAtSometime = ontModel
				.createObjectProperty(METAG + "has_participant_at_some_time");
		ObjectProperty objectProHasParticipantAtAllTimes = ontModel
				.createObjectProperty(METAG + "has_participant_at_all_times");
		objectProHasParticipantAtAllTimes.addSuperProperty(objectProHasParticipantAtSometime);
		ObjectProperty objectProHasInput = ontModel.createObjectProperty(METAG + "hasInput");
		objectProHasInput.addSuperProperty(objectProHasParticipantAtSometime);
		ObjectProperty objectProHasOutput = ontModel.createObjectProperty(METAG + "hasOutput");
		objectProHasOutput.addSuperProperty(objectProHasParticipantAtSometime);
		ObjectProperty objectProHasSpecifiedOutput = ontModel.createObjectProperty(METAG + "hasSpecifiedOutput");
		objectProHasSpecifiedOutput.addSuperProperty(objectProHasOutput);
		ObjectProperty objectProHasRealization = ontModel.createObjectProperty(METAG + "has_realization");
		ObjectProperty objectProHasProcessCharacteristic = ontModel.createObjectProperty(METAG + "hasProcessCharacteristic");
		ObjectProperty objectProHistoryOf = ontModel.createObjectProperty(METAG + "history_of");
		ObjectProperty objectProIsCarrierOfAtSomeTime = ontModel
				.createObjectProperty(METAG + "is_carrier_of_at_some_time");
		ObjectProperty objectProIsCarrierOfAtAllTimes = ontModel
				.createObjectProperty(METAG + "is_carrier_of_at_all_times");
		objectProIsCarrierOfAtAllTimes.addSuperProperty(objectProIsCarrierOfAtSomeTime);
		ObjectProperty objectProIsConcretizedByAtSomeTime = ontModel
				.createObjectProperty(METAG + "is_concretized_by_at_some_time");
		ObjectProperty objectProIsConcretizedByAtAllTimes = ontModel
				.createObjectProperty(METAG + "is_concretized_by_at_all_times");
		objectProIsConcretizedByAtAllTimes.addSuperProperty(objectProIsConcretizedByAtSomeTime);
		ObjectProperty objectProIsAchievedByAtSomeTime = ontModel
				.createObjectProperty(METAG + "isAchievedByAtSomeTime");
		objectProIsAchievedByAtSomeTime.addSuperProperty(objectProIsConcretizedByAtSomeTime);
		ObjectProperty objectProIsAbout = ontModel.createObjectProperty(METAG + "isAbout");
		ObjectProperty objectProDenotes = ontModel.createObjectProperty(METAG + "denotes");
		objectProDenotes.addSuperProperty(objectProIsAbout);
		ObjectProperty objectProDesignates = ontModel.createObjectProperty(METAG + "designates");
		objectProDesignates.addSuperProperty(objectProDenotes);
		ObjectProperty objectProDescribes = ontModel.createObjectProperty(METAG + "describes");
		objectProDescribes.addSuperProperty(objectProIsAbout);
		ObjectProperty objectProIsValueExpressionOfAtSomeTime = ontModel.createObjectProperty(METAG + "isValueExpressionOfAtSomeTime");
		objectProIsValueExpressionOfAtSomeTime.addSuperProperty(objectProDescribes);
		ObjectProperty objectProIsMeasuredValueOfAtSomeTime = ontModel.createObjectProperty(METAG + "isMeasuredValueOfAtSomeTime");
		objectProIsMeasuredValueOfAtSomeTime.addSuperProperty(objectProIsValueExpressionOfAtSomeTime);
		ObjectProperty objectProIsValueExpressionOfAtAllTimes = ontModel.createObjectProperty(METAG + "isValueExpressionOfAtAllTimes");
		objectProIsValueExpressionOfAtAllTimes.addSuperProperty(objectProIsValueExpressionOfAtSomeTime);		
		ObjectProperty objectProPrescribes = ontModel.createObjectProperty(METAG + "prescribes");
		objectProPrescribes.addSuperProperty(objectProIsAbout);
		ObjectProperty objectProIsAvailableToAtSomeTime = ontModel.createObjectProperty(METAG + "isAvailableToAtSomeTime");
		ObjectProperty objectProIsSubjectOf= ontModel.createObjectProperty(METAG + "isSubjectOf");
		ObjectProperty objectProDenotedBy = ontModel.createObjectProperty(METAG + "denotedBy");
		objectProDenotedBy.addSuperProperty(objectProIsSubjectOf);
		ObjectProperty objectProDesignatedBy = ontModel.createObjectProperty(METAG + "designatedBy");
		objectProDesignatedBy.addSuperProperty(objectProDenotedBy);
		ObjectProperty objectProDescribedBy = ontModel.createObjectProperty(METAG + "describedBy");
		objectProDescribedBy.addSuperProperty(objectProIsSubjectOf);
		ObjectProperty objectProHasValueExpressionAtSomeTime = ontModel.createObjectProperty(METAG + "hasValueExpressionAtSomeTime");
		objectProHasValueExpressionAtSomeTime.addSuperProperty(objectProDescribedBy);
		ObjectProperty objectProHasMeasuredValueAtSomeTime = ontModel.createObjectProperty(METAG + "hasMeasuredValueAtSomeTime");
		objectProHasMeasuredValueAtSomeTime.addSuperProperty(objectProHasValueExpressionAtSomeTime);
		ObjectProperty objectProHasValueExpressionAtAllTimes = ontModel.createObjectProperty(METAG + "hasValueExpressionAtAllTimes");
		objectProHasValueExpressionAtAllTimes.addSuperProperty(objectProHasValueExpressionAtSomeTime);
		ObjectProperty objectProPrescribedBy = ontModel.createObjectProperty(METAG + "prescribedBy");
		objectProPrescribedBy.addSuperProperty(objectProIsSubjectOf);		
		ObjectProperty objectProLastInstantOf = ontModel.createObjectProperty(METAG + "last_instant_of");
		ObjectProperty objectProLocatedInAtSometime = ontModel.createObjectProperty(METAG + "located_in_at_some_time");
		ObjectProperty objectProLocatedInAtAllTimes = ontModel.createObjectProperty(METAG + "located_in_at_all_times");
		objectProLocatedInAtAllTimes.addSuperProperty(objectProLocatedInAtSometime);
		ObjectProperty objectProLocationOfAtSomeTime = ontModel.createObjectProperty(METAG + "location_of_at_some_time");
		ObjectProperty objectProLocationOfAtAllTimes = ontModel.createObjectProperty(METAG + "location_of_at_all_times");
		objectProLocationOfAtAllTimes.addSuperProperty(objectProLocationOfAtSomeTime);
		ObjectProperty objectProMaterialBasisOfAtSometime = ontModel
				.createObjectProperty(METAG + "material_basis_of_at_some_time");
		ObjectProperty objectProMaterialBasisOfAtAllTimes = ontModel
				.createObjectProperty(METAG + "material_basis_of_at_all_times");
		objectProMaterialBasisOfAtAllTimes.addSuperProperty(objectProMaterialBasisOfAtSometime);
		ObjectProperty objectProMeasuredByAtSomeTime = ontModel.createObjectProperty(METAG + "measuredByAtSomeTime");
		ObjectProperty objectProMeasuresAtSomeTime = ontModel.createObjectProperty(METAG + "measuresAtSomeTime");
		ObjectProperty objectProObservedByAtSomeTime = ontModel.createObjectProperty(METAG + "observedByAtSomeTime");
		ObjectProperty objectProObservesAtSomeTime = ontModel.createObjectProperty(METAG + "observesAtSomeTime");
		
		ObjectProperty objectProOccupiesSpatialRegionAtSomeTime = ontModel
				.createObjectProperty(METAG + "occupies_spatial_region_at_some_time");
		ObjectProperty objectProOccupiesSpatialRegionAtAllTimes = ontModel
				.createObjectProperty(METAG + "occupies_spatial_region_at_all_times");
		objectProOccupiesSpatialRegionAtAllTimes.addSuperProperty(objectProOccupiesSpatialRegionAtSomeTime);
		ObjectProperty objectProOccupiesSpatiotemporalRegion = ontModel
				.createObjectProperty(METAG + "occupies_spatiotemporal_region");
		ObjectProperty objectProOccupiesTemporalRegion = ontModel
				.createObjectProperty(METAG + "occupies_temporal_region");
		ObjectProperty objectProOccurrentPartOf = ontModel.createObjectProperty(METAG + "occurrent_part_of");
		ObjectProperty objectProProperOccurrentPartOf = ontModel
				.createObjectProperty(METAG + "proper_occurrent_part_of");
		objectProProperOccurrentPartOf.addSuperProperty(objectProOccurrentPartOf);
		ObjectProperty objectProTemporalPartOf = ontModel.createObjectProperty(METAG + "temporal_part_of");
		objectProTemporalPartOf.addSuperProperty(objectProOccurrentPartOf);
		ObjectProperty objectProProperTemporalPartOf = ontModel.createObjectProperty(METAG + "proper_temporal_part_of");
		objectProProperTemporalPartOf.addSuperProperty(objectProTemporalPartOf);
		ObjectProperty objectProOccursIn = ontModel.createObjectProperty(METAG + "occurs_in");
		ObjectProperty objectProParticipatesInAtSomeTime = ontModel
				.createObjectProperty(METAG + "participates_in_at_some_time");
		ObjectProperty objectProIsInputOf = ontModel.createObjectProperty(METAG + "isInputOf");
		objectProIsInputOf.addSuperProperty(objectProParticipatesInAtSomeTime);
		ObjectProperty objectProIsOutputOf = ontModel.createObjectProperty(METAG + "isOutputOf");
		objectProIsOutputOf.addSuperProperty(objectProParticipatesInAtSomeTime);
		ObjectProperty objectProIsSpecifiedOutputOf = ontModel.createObjectProperty(METAG + "isSpecifiedOutputOf");
		objectProIsSpecifiedOutputOf.addSuperProperty(objectProIsOutputOf);		
		ObjectProperty objectProParticipatesInAtAllTimes = ontModel
				.createObjectProperty(METAG + "participates_in_at_all_times");
		objectProParticipatesInAtAllTimes.addSuperProperty(objectProParticipatesInAtSomeTime);
		ObjectProperty objectProPrecededBy = ontModel.createObjectProperty(METAG + "preceded_by");
		ObjectProperty objectProPrecedes = ontModel.createObjectProperty(METAG + "precedes");
		ObjectProperty objectProProcessCharacteristicOf = ontModel.createObjectProperty(METAG + "processCharacteristicOf");
		ObjectProperty objectProRealizes = ontModel.createObjectProperty(METAG + "realizes");
		ObjectProperty objectProRecognizedByAtSomeTime = ontModel.createObjectProperty(METAG + "recognizedByAtSomeTime");
		ObjectProperty objectProRecognizesAtSomeTime = ontModel.createObjectProperty(METAG + "recognizesAtSomeTime");
		ObjectProperty objectProRequirementSatisfiedBy = ontModel.createObjectProperty(METAG + "requirementSatisfiedBy");
		ObjectProperty objectProSatisfiesRequirement = ontModel.createObjectProperty(METAG + "satisfiesRequirement");
		ObjectProperty objectProSpatiallyProjectsOntoAtSomeTime = ontModel
				.createObjectProperty(METAG + "spatially_projects_onto_at_some_time");
		ObjectProperty objectProSpatiallyProjectsOntoAtAllTimes = ontModel
				.createObjectProperty(METAG + "spatially_projects_onto_at_all_times");
		objectProSpatiallyProjectsOntoAtAllTimes.addSuperProperty(objectProSpatiallyProjectsOntoAtSomeTime);
		ObjectProperty objectProSpecificallyDependedOnBy = ontModel
				.createObjectProperty(METAG + "specifically_depended_on_by");
		ObjectProperty objectProBearerOf = ontModel.createObjectProperty(METAG + "bearer_of");
		objectProBearerOf.addSuperProperty(objectProSpecificallyDependedOnBy);
		ObjectProperty objectProHasCapability = ontModel.createObjectProperty(METAG + "hasCapability");
		objectProHasCapability.addSuperProperty(objectProBearerOf);
		ObjectProperty objectProHasDisposition= ontModel.createObjectProperty(METAG + "hasDisposition");
		objectProHasDisposition.addSuperProperty(objectProBearerOf);
		ObjectProperty objectProHasFunction = ontModel.createObjectProperty(METAG + "hasFunction");
		objectProHasFunction.addSuperProperty(objectProBearerOf);
		ObjectProperty objectProHasQuality = ontModel.createObjectProperty(METAG + "hasQuality");
		objectProHasQuality.addSuperProperty(objectProBearerOf);
		ObjectProperty objectProHasRole = ontModel.createObjectProperty(METAG + "hasRole");
		objectProHasRole.addSuperProperty(objectProBearerOf);
		ObjectProperty objectProSpecificallyDependsOn = ontModel
				.createObjectProperty(METAG + "specifically_depends_on");
		ObjectProperty objectProInheresIn = ontModel.createObjectProperty(METAG + "inheres_in");
		objectProInheresIn.addSuperProperty(objectProSpecificallyDependsOn);
		ObjectProperty objectProCapabilityOf = ontModel.createObjectProperty(METAG + "capabilityOf");
		objectProCapabilityOf.addSuperProperty(objectProInheresIn);
		ObjectProperty objectProDispositionOf = ontModel.createObjectProperty(METAG + "dispositionOf");
		objectProDispositionOf.addSuperProperty(objectProInheresIn);
		ObjectProperty objectProFunctionOf = ontModel.createObjectProperty(METAG + "functionOf");
		objectProFunctionOf.addSuperProperty(objectProInheresIn);
		ObjectProperty objectProQualityOf = ontModel.createObjectProperty(METAG + "qualityOf");
		objectProQualityOf.addSuperProperty(objectProInheresIn);
		ObjectProperty objectProRoleOf = ontModel.createObjectProperty(METAG + "roleOf");
		objectProRoleOf.addSuperProperty(objectProInheresIn);
		ObjectProperty objectProTemporallyProjectsOnto = ontModel
				.createObjectProperty(METAG + "temporally_projects_onto");
		ObjectProperty objectProConsistent = ontModel
				.createObjectProperty(METAG + "consistent");

	}
}
