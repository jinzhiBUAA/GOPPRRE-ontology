package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.util.Iterator;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;

public class Table2Owl {
	public static void generateTable(IProject metagProject, OntModel ontModel,boolean isBFO) throws CoreException, DocumentException {
		IFolder tableFolder = null;
		IFolder tableFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder tableFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (tableFolder1.exists()) {
			tableFolder = tableFolder1;
		} else if (tableFolder2.exists()) {
			tableFolder = tableFolder2;
		}
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		OntClass owlTableClass = ontModel.createClass(METAG + "Table");
		OntClass owlColumnClass = ontModel.createClass(METAG + "Table_Columns");
		owlTableClass.addSubClass(owlColumnClass);
		OntClass owlRowClass = ontModel.createClass(METAG + "Table_Rows");
		owlTableClass.addSubClass(owlRowClass);
		OntClass owlLinkClass = ontModel.createClass(METAG + "Table_Links");
		owlTableClass.addSubClass(owlLinkClass);

		// 创建annotaiton property
		AnnotationProperty annotationProName = ontModel.createAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationProlocalLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationProId = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationProname = ontModel.createAnnotationProperty(METAG + "name");
		AnnotationProperty annotationProWidth = ontModel.createAnnotationProperty(METAG + "width");
		AnnotationProperty annotationPronum = ontModel.createAnnotationProperty(METAG + "num");		
		AnnotationProperty annotationProLink_text = ontModel.createAnnotationProperty(METAG + "link_text");	
		AnnotationProperty annotationProLocation = ontModel.createAnnotationProperty(METAG + "location");		
		
		// 增加table标记语言
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");
		
		// 创建Object Property
		ObjectProperty objectProOwn = ontModel.createObjectProperty(METAG + "own");
		if(isBFO) {
			OntClass owlKarmaClass = ontModel.getOntClass(METAG + "KARMA");
			owlKarmaClass.addSubClass(owlTableClass);
		}

		for (IResource fileLanguage : tableFolder.members()) {
			if (fileLanguage.getType() == IResource.FOLDER) {
				IFolder languageFolder = (IFolder) fileLanguage;
				IFolder fileModel = null;
				IFolder fileModel1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
				IFolder fileModel2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
				if (fileModel1 != null) {
					fileModel = fileModel1;
				} else if (fileModel2 != null) {
					fileModel = fileModel2;
				}
				for (IResource f : fileModel.members()) {
					if (f.getName().endsWith(".table")) {
						// 读Table文件
						File file = new File(f.getLocation().toOSString());
						SAXReader reader = new SAXReader();
						Document document = reader.read(file);
						Element root = document.getRootElement();
						String tableName = root.element("Table").attribute("Name").getValue();
						String fileName = tableName ;						
						// 每一个owlTableIndividual属于一个Table
						Individual owlTableIndividual = ontModel.createIndividual(METAG + tableName, owlTableClass);
						owlTableIndividual.addProperty(annotationProName, tableName);
						if (root.element("Table").attribute("localLabel") != null) {
							String localLabel = root.element("Table").attribute("localLabel").getValue();	
							owlTableIndividual.addProperty(annotationProlocalLabel, localLabel);
						}
						
						// 增加table标记语言
						OntClass owlLanguage = ontModel.getOntClass(METAG + languageFolder.getName());
						if (owlLanguage == null) {
							String languageId = SaveKarInformation.getLanguageId(languageFolder);
							OntClass ontClass = ontModel.getOntClass(METAG + languageId);
							owlTableIndividual.addProperty(annotationPropertyModelLocation, languageFolder.getName());
						} else {
							owlTableIndividual.addProperty(annotationPropertyModelLocation, owlLanguage.getLocalName());
						}

						// columns
						Element columns = root.element("Table").element("columns");
						if (columns.elements() != null) {
							for (Iterator<Element> it = columns.elementIterator(); it.hasNext();) {
								Element column = it.next();
								String column_Id = column.attribute("id").getValue().toString();
								String column_Name = column.attribute("name").getValue().toString();
								Individual column_Individual = ontModel.createIndividual(METAG + tableName+"_column_"+ column_Id,
										owlColumnClass);
								column_Individual.addProperty(annotationProId, column_Id);
								column_Individual.addProperty(annotationProname, column_Name);
								if(column.attribute("width")!=null) {
									String column_Width = column.attribute("width").getValue().toString();
									column_Individual.addProperty(annotationProWidth, column_Width);
								}								
								owlTableIndividual.addProperty(objectProOwn, column_Individual);
							}
						}
						// rows
						Element rows = root.element("Table").element("rows");
						String rows_num = rows.attribute("num").getValue();
						Individual owlRowIndividual = ontModel.createIndividual(METAG + tableName+"__" + "rows",
								owlRowClass);
						owlRowIndividual.addProperty(annotationPronum, rows_num);
						owlTableIndividual.addProperty(objectProOwn, owlRowIndividual);
						// links
						Element links = root.element("Table").element("links");
						if (links.elements() != null) {
							for (Iterator<Element> it = links.elementIterator(); it.hasNext();) {
								Element link = it.next();
								String link_location = link.attribute("location").getValue();
								String link_name = link.attribute("name").getValue();
								String link_text = link.getText();
								Individual link_Individual = ontModel.createIndividual(METAG + tableName+"_link_"+ link_location,
										owlLinkClass);
								link_Individual.addProperty(annotationProLocation, link_location);
								link_Individual.addProperty(annotationProname, link_name);
								link_Individual.addProperty(annotationProLink_text, link_text.replace("\n", "&#xa;"));
								System.out.println(link_text.replace("\n", "&#xa;"));
								owlTableIndividual.addProperty(objectProOwn, link_Individual);
							}
						}
					}
				}
			}
		}
	}
}
