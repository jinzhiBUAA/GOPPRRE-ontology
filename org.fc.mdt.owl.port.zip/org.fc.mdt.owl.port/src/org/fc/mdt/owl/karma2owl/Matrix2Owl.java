package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.util.Iterator;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;

public class Matrix2Owl {
	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
	static int flagR = 0;
	static int flagC = 0;
	public static void generateMatrix(IProject metagProject, OntModel ontModel, boolean isBFO)
			throws CoreException, DocumentException {
		IFolder matrixFolder = null;
		IFolder matrixFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder matrixFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (matrixFolder1.exists()) {
			matrixFolder = matrixFolder1;
		} else if (matrixFolder2.exists()) {
			matrixFolder = matrixFolder2;
		}
		OntClass owlMatrixClass = ontModel.createClass(METAG + "Matrix");
		if (isBFO) {
			OntClass owlDirectiveIceClass = ontModel.getOntClass(METAG + "Directive_Information_Content_Entity");// 从ontModel获得这个节点
			owlDirectiveIceClass.addSubClass(owlMatrixClass);
		}
		OntClass owlMatrixRowClass = ontModel.createClass(METAG + "Matrix_Row");
		OntClass owlMatrixColumnClass = ontModel.createClass(METAG + "Matrix_Column");
		OntClass owlMatrixRelationClass = ontModel.createClass(METAG + "Matrix_Relation");
		owlMatrixClass.addSubClass(owlMatrixRowClass);
		owlMatrixClass.addSubClass(owlMatrixColumnClass);
		owlMatrixClass.addSubClass(owlMatrixRelationClass);

		// 创建/获取annotaiton property
		AnnotationProperty annotationPro_id = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationPro_localLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationPro_text = ontModel.createAnnotationProperty(METAG + "text");
		AnnotationProperty annotationPro_name = ontModel.createAnnotationProperty(METAG + "name");
		AnnotationProperty annotationPro_direction = ontModel.createAnnotationProperty(METAG + "direction");
		AnnotationProperty annotationPro_location = ontModel.createAnnotationProperty(METAG + "location");
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");

		// 创建object property
		ObjectProperty objectPro_ref = ontModel.createObjectProperty(METAG + "ref");
		ObjectProperty objectPro_linkRelationshipAndSourceRole = ontModel.createObjectProperty(METAG + "linkRelationshipAndSourceRole");
		ObjectProperty objectPro_linkRelationshipAndTargetRole = ontModel.createObjectProperty(METAG + "linkRelationshipAndTargetRole");
		//创建矩阵Matrix和其中行、列以及关系的属性
		ObjectProperty objectPro_matrixHasRelation = ontModel.createObjectProperty(METAG + "matrixHasRelation");
		
		for (IResource fileLanguage : matrixFolder.members()) {
			if (fileLanguage.getType() == IResource.FOLDER) {
				IFolder languageFolder = (IFolder) fileLanguage;
				IFolder fileModel = null;
				IFolder fileModel1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
				IFolder fileModel2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
				if (fileModel1 != null) {
					fileModel = fileModel1;
				} else if (fileModel2 != null) {
					fileModel = fileModel2;
				}
				for (IResource f : fileModel.members()) {
					if (f.getName().endsWith(".matrix")) {
						// 读matrix文件
						File file = new File(f.getLocation().toOSString());
						SAXReader reader = new SAXReader();
						Document document = reader.read(file);
						Element root = document.getRootElement();
						String matrix_id = root.element("Matrix").attribute("id").getValue();
						String matrix_localLabel = root.element("Matrix").attribute("localLabel").getValue();
						String matrix_text = root.element("Matrix").attribute("text").getValue();

						// 每一个owlMatrixIndividual属于一个matrix
						Individual owlMatrixIndividual = ontModel.createIndividual(METAG + matrix_id, owlMatrixClass);
						owlMatrixIndividual.addProperty(annotationPro_id, matrix_id);
						owlMatrixIndividual.addProperty(annotationPro_localLabel, matrix_localLabel);
						owlMatrixIndividual.addProperty(annotationPro_text, matrix_text);

						// 增加matrix标记语言
						OntClass owlLanguage = ontModel.getOntClass(METAG + languageFolder.getName());
						if (owlLanguage == null) {
							String languageId = SaveKarInformation.getLanguageId(languageFolder);
							OntClass ontClass = ontModel.getOntClass(METAG + languageId);
							owlMatrixIndividual.addProperty(annotationPropertyModelLocation, languageFolder.getName());
						} else {
							owlMatrixIndividual.addProperty(annotationPropertyModelLocation,
									owlLanguage.getLocalName());
						}
						
						// ROW_HEADER
						Element rowHeader = root.element("Matrix").element("ROW_HEADER");
						if (rowHeader.elements() != null) {
							for (Iterator<Element> it = rowHeader.elementIterator(); it.hasNext();) {
								// ROW
								Element row = it.next();
								flagR++;
								generateResourceR(row, ontModel,owlMatrixIndividual);
							}
						}
						// COLUMN_HEADER
						Element columnHeader = root.element("Matrix").element("COLUMN_HEADER");
						if (columnHeader.elements() != null) {
							for (Iterator<Element> it = columnHeader.elementIterator(); it.hasNext();) {
								// ROW
								Element column = it.next();
								flagC++;
								generateResourceC(column, ontModel, owlMatrixIndividual);
							}
						}
						// RELATION
						Element RELATION = root.element("Matrix").element("RELATION");
						int matrixRelationSize = RELATION.elements().size();
						for(int i =0; i < matrixRelationSize; i++) {
							Element matrixRelation = RELATION.elements().get(i);
							int	relationSize = matrixRelation.elements().size();
							for(int j =0; j < relationSize; j++) {
								Element relation = matrixRelation.elements().get(j);
								if(relation.attribute("id") != null) {
									String locationxy =  "row_" +i+ "_column_" +j;
									String relation_id = relation.attribute("id").getValue();
									String relation_name = relation.attribute("name").getValue();
									String relation_direction = relation.attribute("direction").getValue();
									Individual owlMatrixRelationIndividual = ontModel.createIndividual(METAG + "matrix_relation_"+ locationxy + relation_id, owlMatrixRelationClass);
									owlMatrixRelationIndividual.addProperty(annotationPro_id, relation_id);
									owlMatrixRelationIndividual.addProperty(annotationPro_name, relation_name);
									owlMatrixRelationIndividual.addProperty(annotationPro_direction, relation_direction);
									int ii = i + 1;
									int jj = j + 1;
									owlMatrixRelationIndividual.addProperty(annotationPro_location, "(" +ii + "," +jj +")");
									OntClass owlRelationshipClass = ontModel.getOntClass(METAG + relation_id); 
									Individual owlModelRelationIndividual = ontModel.createIndividual(METAG + "model_relation_"+ locationxy + relation_id, owlRelationshipClass);
									owlMatrixRelationIndividual.addProperty(objectPro_ref, owlModelRelationIndividual);
									owlMatrixIndividual.addProperty(objectPro_matrixHasRelation,owlMatrixRelationIndividual);
									
									Element source_role = relation.element("source_role");
									String source_role_id = source_role.attribute("id").getValue();
									String source_role_name = source_role.attribute("name").getValue();
									//直接把角色实例创建到GOPPRR-E中角色类的实例
									OntClass owlSourceRoleClass = ontModel.getOntClass(METAG + source_role_id); 
									Individual owlModelSourceRoleIndividual = ontModel.createIndividual(METAG + "model_role_"+ locationxy + source_role_id, owlSourceRoleClass);
									owlModelSourceRoleIndividual.addProperty(annotationPro_id, source_role_id);
									owlModelSourceRoleIndividual.addProperty(annotationPro_name, source_role_name);
									owlMatrixRelationIndividual.addProperty(objectPro_linkRelationshipAndSourceRole, owlModelSourceRoleIndividual);
									
									Element target_role = relation.element("target_role");
									String target_role_id = target_role.attribute("id").getValue();
									String target_role_name = target_role.attribute("name").getValue();
									OntClass owlTargetRoleClass = ontModel.getOntClass(METAG + target_role_id); 
									Individual owlModelTargetRoleIndividual = ontModel.createIndividual(METAG + "model_role_"+ locationxy + target_role_id, owlTargetRoleClass);
									owlModelTargetRoleIndividual.addProperty(annotationPro_id, target_role_id);
									owlModelTargetRoleIndividual.addProperty(annotationPro_name, target_role_name);
									owlMatrixRelationIndividual.addProperty(objectPro_linkRelationshipAndTargetRole, owlModelTargetRoleIndividual);
									
								}
							}
						}
					}
				}
			}
		}
		 flagR = 0;
	     flagC = 0;
	}
	private static Individual generateResourceR(Element row, OntModel ontModel,Individual owlMatrixIndividual) {
		AnnotationProperty annotationPro_id = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationPro_name = ontModel.createAnnotationProperty(METAG + "name");
		AnnotationProperty annotationPro_type = ontModel.createAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPro_resource = ontModel.createAnnotationProperty(METAG + "resource");//表达来源
		AnnotationProperty annotationPro_rowLocation = ontModel.createAnnotationProperty(METAG + "rowLocation");//表达原始位置
		
		// 创建object property
		ObjectProperty objectPro_hasResource = ontModel.createObjectProperty(METAG + "hasResource");//表达来源
		ObjectProperty objectPro_ref = ontModel.createObjectProperty(METAG + "ref");
		ObjectProperty objectPro_hasChildren = ontModel.createObjectProperty(METAG + "hasChildren");//表达层级关系
		//创建矩阵Matrix和其中行、列以及关系的属性
		ObjectProperty objectPro_matrixHasRow = ontModel.createObjectProperty(METAG + "matrixHasRow");
		
		OntClass owlMatrixRowClass = ontModel.createClass(METAG + "Matrix_Row");
		
		String row_id = row.attribute("id").getValue();
		String row_name = row.attribute("name").getValue();
		String row_type = row.attribute("type").getValue();
		String row_resource = row.attribute("resource").getValue();
		Individual owlRowIndividual = ontModel.getIndividual(METAG + row_id);		
		Individual owlMatrixRowIndividual = ontModel.createIndividual(METAG + "matrix_" + row_id,
				owlMatrixRowClass);
		owlMatrixIndividual.addProperty(objectPro_matrixHasRow,owlMatrixRowIndividual);
		owlMatrixRowIndividual.addProperty(annotationPro_rowLocation,  Integer.toString(flagR));

		owlMatrixRowIndividual.addProperty(objectPro_ref, owlRowIndividual);
		owlMatrixRowIndividual.addProperty(annotationPro_id, row_id);
		owlMatrixRowIndividual.addProperty(annotationPro_name, row_name);
		owlMatrixRowIndividual.addProperty(annotationPro_type, row_type);
		if (row_type.equals("object")) {
			Individual modelObjectIndividual = ontModel.getIndividual(METAG + row_resource);
			owlMatrixRowIndividual.addProperty(objectPro_hasResource, modelObjectIndividual);
		} else if (row_type.equals("point")) {
			Individual modelPointIndividual = ontModel.getIndividual(METAG + row_resource);
			owlMatrixRowIndividual.addProperty(objectPro_hasResource, modelPointIndividual);

		} else if (row_type.equals("specObject")) {
			owlMatrixRowIndividual.addProperty(annotationPro_resource, row_resource);
		}
		else {
			owlMatrixRowIndividual.addProperty(annotationPro_resource, row_resource);
		}
		for (Iterator<Element> it = row.elementIterator(); it.hasNext();) {
			flagR ++; 
			Element childElement = it.next();
			Individual childIndividual = generateResourceR(childElement, ontModel, owlMatrixIndividual);
			owlMatrixRowIndividual.addProperty(objectPro_hasChildren, childIndividual);
		}
		 return owlMatrixRowIndividual;
	}
	private static Individual generateResourceC(Element column, OntModel ontModel,Individual owlMatrixIndividual) {
		AnnotationProperty annotationPro_id = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationPro_name = ontModel.createAnnotationProperty(METAG + "name");
		AnnotationProperty annotationPro_type = ontModel.createAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPro_resource = ontModel.createAnnotationProperty(METAG + "resource");//表达来源
		AnnotationProperty annotationPro_columnLocation = ontModel.createAnnotationProperty(METAG + "columnLocation");//表达原始位置
		
		// 创建object property
		ObjectProperty objectPro_hasResource = ontModel.createObjectProperty(METAG + "hasResource");//表达来源
		ObjectProperty objectPro_ref = ontModel.createObjectProperty(METAG + "ref");
		ObjectProperty objectPro_hasChildren = ontModel.createObjectProperty(METAG + "hasChildren");//表达层级关系
		//创建矩阵Matrix和其中行、列以及关系的属性
		ObjectProperty objectPro_matrixHasColumn = ontModel.createObjectProperty(METAG + "matrixHasColumn");
		
		OntClass owlMatrixColumnClass = ontModel.createClass(METAG + "Matrix_Column");
		
		String column_id = column.attribute("id").getValue();
		String column_name = column.attribute("name").getValue();
		String column_type = column.attribute("type").getValue();
		String column_resource = column.attribute("resource").getValue();
		Individual owlColumnIndividual = ontModel.getIndividual(METAG + column_id);
		Individual owlMatrixColumnIndividual = ontModel.createIndividual(METAG + "matrix_" + column_id,
					owlMatrixColumnClass);
		owlMatrixIndividual.addProperty(objectPro_matrixHasColumn,owlMatrixColumnIndividual);
		owlMatrixColumnIndividual.addProperty(annotationPro_columnLocation,  Integer.toString(flagC));

		owlMatrixColumnIndividual.addProperty(objectPro_ref, owlColumnIndividual);
		owlMatrixColumnIndividual.addProperty(annotationPro_id, column_id);
		owlMatrixColumnIndividual.addProperty(annotationPro_name, column_name);
		owlMatrixColumnIndividual.addProperty(annotationPro_type, column_type);
		if (column_type.equals("object")) {
			Individual modelObjectIndividual = ontModel.getIndividual(METAG + column_resource);
			owlMatrixColumnIndividual.addProperty(objectPro_hasResource, modelObjectIndividual);
		} else if (column_type.equals("point")) {
			Individual modelPointIndividual = ontModel.getIndividual(METAG + column_resource);
			owlMatrixColumnIndividual.addProperty(objectPro_hasResource, modelPointIndividual);

		} else if (column_type.equals("specObject")) {
			owlMatrixColumnIndividual.addProperty(annotationPro_resource, column_resource);
		}
		else {
			owlMatrixColumnIndividual.addProperty(annotationPro_resource, column_resource);
		}
		for (Iterator<Element> it = column.elementIterator(); it.hasNext();) {
			flagC ++; 
			Element childElement = it.next();
			Individual childIndividual = generateResourceC(childElement, ontModel, owlMatrixIndividual);
			owlMatrixColumnIndividual.addProperty(objectPro_hasChildren, childIndividual);
		}
		 return owlMatrixColumnIndividual;
	}
}
