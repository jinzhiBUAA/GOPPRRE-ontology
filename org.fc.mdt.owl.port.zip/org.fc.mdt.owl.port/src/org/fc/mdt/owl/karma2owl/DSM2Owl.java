package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;
import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;
import org.fc.mdt.owl.port.messages.Messages;

public class DSM2Owl {

	public static void generateDSM(IProject metagProject, OntModel ontModel, boolean isBFO) throws CoreException, DocumentException {
		IFolder dsmFolder = null;
		IFolder dsmFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder dsmFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (dsmFolder1.exists()) {
			dsmFolder = dsmFolder1;
		} else if (dsmFolder2.exists()) {
			dsmFolder = dsmFolder2;
		}

		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		OntClass owlDSMClass;// 从ontModel获得这个节点
		if (isBFO) {
			owlDSMClass = ontModel.getOntClass(METAG + "DSM");// 从ontModel获得这个节点
		}
		else {
			owlDSMClass = ontModel.createClass(METAG + "DSM");			
		}
		// 在DSM节点下创建ReqIF和KARMA两类元素
		OntClass owlReqIFModelElementClass = ontModel.createClass(METAG + "ReqIF_Model_Element");
		owlDSMClass.addSubClass(owlReqIFModelElementClass);
		OntClass owlKarmaModelElementClass = ontModel.createClass(METAG + "KARMA_Model_Element");
		owlDSMClass.addSubClass(owlKarmaModelElementClass);

		// 创建annotaiton property
		AnnotationProperty annotationProIdentifier = ontModel.getAnnotationProperty(METAG + "identifier");
		AnnotationProperty annotationProName = ontModel.createAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");
		AnnotationProperty annotationProlocalLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		
		AnnotationProperty annotationProDSM_Element_Id = ontModel.createAnnotationProperty(METAG + "DSM_Element_id");
		AnnotationProperty annotationProModel_Id = ontModel.createAnnotationProperty(METAG + "model_id");
		AnnotationProperty annotationProMeta_Model = ontModel.createAnnotationProperty(METAG + "meta_model");
		AnnotationProperty annotationProText = ontModel.createAnnotationProperty(METAG + "text");
		AnnotationProperty annotationProMeta_Property_Instance_Id = ontModel
						.createAnnotationProperty(METAG + "meta_property_instance_id");
		AnnotationProperty annotationProMeta_Property_Instance_Type = ontModel
						.createAnnotationProperty(METAG + "meta_property_instance_type");
		AnnotationProperty annotationProMeta_Property_Instance_Text = ontModel
						.createAnnotationProperty(METAG + "meta_property_instance_text");
		
		// 创建object property
		System.out.println(Messages.getValue("satisfy"));
		ObjectProperty objectProCopy = ontModel.createObjectProperty(METAG + Messages.getValue("copy"));
		ObjectProperty objectProTrace = ontModel.createObjectProperty(METAG + Messages.getValue("trace"));
		ObjectProperty objectProSatisfy = ontModel.createObjectProperty(METAG + Messages.getValue("satisfy"));
		ObjectProperty objectProVerify = ontModel.createObjectProperty(METAG + Messages.getValue("verify"));
		ObjectProperty objectProRefine = ontModel.createObjectProperty(METAG + Messages.getValue("refine"));
		ObjectProperty objectProDerive = ontModel.createObjectProperty(METAG + Messages.getValue("derive"));
		ObjectProperty objectProCompose = ontModel.createObjectProperty(METAG + Messages.getValue("compose"));
		ObjectProperty objectProContain = ontModel.createObjectProperty(METAG + Messages.getValue("contain"));
		ObjectProperty objectProDSM_Ref_ReqIF = ontModel.createObjectProperty(METAG + "DSM_Ref_ReqIF");
		ObjectProperty objectProDSM_Ref_KARMA = ontModel.createObjectProperty(METAG + "DSM_Ref_KARMA");
		ObjectProperty objectProEqual = ontModel.getObjectProperty(METAG + "equal_to");
		for (IResource fileLanguage : dsmFolder.members()) {
			if (fileLanguage.getType() == IResource.FOLDER) {
				IFolder languageFolder = (IFolder) fileLanguage;

				IFolder fileModel = null;
				IFolder fileModel1 = (IFolder)languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
				IFolder fileModel2 = (IFolder)languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
				if (fileModel1 != null) {
					fileModel = fileModel1;
				} else if (fileModel2 != null) {
					fileModel = fileModel2;
				}

				for(IResource f : fileModel.members()) {
					if(f.getName().endsWith(".dsm")) {
						// 读DSM文件
						File file = new File(f.getLocation().toOSString());
						SAXReader reader = new SAXReader();
						Document document = reader.read(file);
						Element root = document.getRootElement();
						String dsmName = root.element("Table").attribute("Name").getValue();

						// 每一个DSMIndividual属于一个DSM
						Individual owlDSMIndividual = ontModel.createIndividual(METAG + dsmName, owlDSMClass);
						owlDSMIndividual.addProperty(annotationProName, dsmName);
						if (root.element("Table").attribute("localLabel") != null) {
							String localLabel = root.element("Table").attribute("localLabel").getValue();
							owlDSMIndividual.addProperty(annotationProlocalLabel, localLabel);
						}
						
						// 增加DSM标记语言
						OntClass owlLanguage = ontModel.getOntClass(METAG + languageFolder.getName());
						if (owlLanguage == null) {
							String languageId = SaveKarInformation.getLanguageId(languageFolder);
							OntClass ontClass = ontModel.getOntClass(METAG + languageId);
							owlDSMIndividual.addProperty(annotationPropertyModelLocation, languageFolder.getName());
						} else {
							owlDSMIndividual.addProperty(annotationPropertyModelLocation, owlLanguage.getLocalName());
						}
						//读取DSM中的元素
						Element theHeader = root.element("Table").element("THE-HEADER");
						for (Iterator<Element> it = theHeader.elementIterator(); it.hasNext();) {
							Element elementRowColumn = it.next();
							//以row为参考生成individual，row和column内容一致
							if(elementRowColumn.getName().equals("ROW-HEADER")) {
								Element row = elementRowColumn;
								//通过model_id判断是否KARMA模型
								if(row.attributeValue("model_id")!=null) {
									String row_Name= row.attributeValue("Name").toString();
									String row_DSM_Element_id= row.attributeValue("DSM_Element_id").toString();
									Individual row_Individual = ontModel.createIndividual(
											METAG + dsmName + "_refer_" + row_DSM_Element_id, owlKarmaModelElementClass);
									row_Individual.addProperty(annotationProName, row_Name);									
									row_Individual.addProperty(annotationProDSM_Element_Id, row_DSM_Element_id);
									String row_model_id= row.attributeValue("model_id").toString();
									row_Individual.addProperty(annotationProModel_Id, row_model_id);
									if (row.attribute("meta_model") != null) {
										String meta_Model = row.attributeValue("meta_model").toString();
										row_Individual.addProperty(annotationProMeta_Model, meta_Model);
									}
									String row_text = row.getText();
									row_Individual.addProperty(annotationProText, row_text);
									if (row.element("meta_property_instance") != null) {
										Element meta_Property_Instance = row.element("meta_property_instance");
										if (meta_Property_Instance.attribute("meta_property_instance_id") != null) {
											String meta_Property_Instance_Id = meta_Property_Instance
													.attribute("meta_property_instance_id").getValue().toString();
											row_Individual.addProperty(annotationProMeta_Property_Instance_Id,
													meta_Property_Instance_Id);
										}
										if (meta_Property_Instance.attribute("meta_property_instance_type") != null) {
											String meta_Property_Instance_Type = meta_Property_Instance
													.attribute("meta_property_instance_type").getValue().toString();
											row_Individual.addProperty(annotationProMeta_Property_Instance_Type,
													meta_Property_Instance_Type);
										}
										if (meta_Property_Instance.getText() != null) {
											String meta_Property_Instance_Text = meta_Property_Instance.getText();
											row_Individual.addProperty(annotationProMeta_Property_Instance_Text,
													meta_Property_Instance_Text);
										}
								}
									// 将该实例与KARMA下的实例关联
									Individual owlKARMAIndividual = ontModel.getIndividual(METAG + row_DSM_Element_id);
									row_Individual.addProperty(objectProEqual,owlKARMAIndividual);
									// 与dsm文件绑定
									owlDSMIndividual.addProperty(objectProDSM_Ref_KARMA,row_Individual);
							}
								else {
									String row_Name= row.attributeValue("Name").toString();
									String row_DSM_Element_id= row.attributeValue("DSM_Element_id").toString();
									Individual row_Individual = ontModel.createIndividual(
											METAG + dsmName + "_refer_" + row_DSM_Element_id, owlReqIFModelElementClass);
									row_Individual.addProperty(annotationProName, row_Name);									
									row_Individual.addProperty(annotationProDSM_Element_Id, row_DSM_Element_id);
									String row_text = row.getText();
									row_Individual.addProperty(annotationProText, row_text);
									// 将该实例与ReqIF下的实例关联
									Individual owlReqIFIndividual = ontModel.getIndividual(METAG + row_DSM_Element_id);
									row_Individual.addProperty(objectProEqual,owlReqIFIndividual);
									// 与dsm文件绑定
									owlDSMIndividual.addProperty(objectProDSM_Ref_ReqIF,row_Individual);
								}								
							}						
						}
						//读取DSM中的元素关系
						Element table = root.element("Table");
						for (Iterator<Element> it0 = table.elementIterator(); it0.hasNext();) {
							Element tableElement = it0.next();
							if (tableElement.getName().equals("Row")) {
								Element rowElement = tableElement;
								String dsmRowElementID = rowElement.attributeValue("row").toString();
								Individual dsmRowIndividual = ontModel
										.getIndividual(METAG + dsmName + "_refer_" + dsmRowElementID);
								for (Iterator<Element> it = rowElement.elementIterator(); it.hasNext();) {
									Element cellElement = it.next();
									String dsmCellElementID = cellElement.attributeValue("line").toString();
									Individual dsmCellIndividual = ontModel
											.getIndividual(METAG + dsmName + "_refer_" + dsmCellElementID);
									String relationship = cellElement.getText();
									if(relationship!=null&&relationship!="") {
										ObjectProperty objectProRelationship = ontModel.getObjectProperty(METAG + relationship);
										if(objectProRelationship!=null) {
											dsmRowIndividual.addProperty(objectProRelationship, dsmCellIndividual);
										}
										else{
											objectProRelationship = ontModel.createObjectProperty(METAG + relationship);
											dsmRowIndividual.addProperty(objectProRelationship, dsmCellIndividual);
										}
									}
									
								}
							}							
						}
					}
				}
			}
		}
	}
}