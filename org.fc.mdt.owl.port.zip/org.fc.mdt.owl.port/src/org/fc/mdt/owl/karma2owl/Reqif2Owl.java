package org.fc.mdt.owl.karma2owl;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.SomeValuesFromRestriction;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.QName;
import org.dom4j.io.SAXReader;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;
import org.fc.mdt.core.utils.log.console.MdtLogConsole;
import org.fc.mdt.core.utils.log.console.MdtLogConsoleFactory;
import org.fc.mdt.owl.port.messages.Messages;
//20231201修改记录Individual owlReqIFIndividual = ontModel.createIndividual(METAG + reqIFIdentifier,owlReqIFClass);改成reqif文件id
//String fileName = document.getName().substring( document.getName().lastIndexOf("/")+1,document.getName().indexOf("."));
//reqIFIdentifier-->fileName
public class Reqif2Owl {
	private static MdtLogConsole console = MdtLogConsoleFactory.getInstance().getConsole();

	public static void generateReqif(IProject metagProject, OntModel ontModel) throws CoreException, DocumentException {	
		
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		OntClass owlReqIFClass = ontModel.getOntClass(METAG + "ReqIF");// 从ontModel获得这个节点
		// 创建ReqIF本体的Class
		// 控制台报错
		// 20220802加控制台报错
		for (Iterator It = ontModel.listClasses(); It.hasNext();) {
			OntClass classExist = (OntClass) It.next();
			if (classExist.getLocalName() != null) {
				if (classExist.getLocalName().equals("Attribute_Definition")
						|| classExist.getLocalName().equals("Column") || classExist.getLocalName().equals("DataTypes")
						|| classExist.getLocalName().equals("Spec_Hierarchy")
						|| classExist.getLocalName().equals("Spec_Object")
						|| classExist.getLocalName().equals("Spec_Object_doesntHaveType")
						|| classExist.getLocalName().equals("Spec_Object_hasType")
						|| classExist.getLocalName().equals("Spec_Relation")
						|| classExist.getLocalName().equals("Spec_Relation_doesntHaveType")
						|| classExist.getLocalName().equals("Spec_Relation_hasType")
						|| classExist.getLocalName().equals("Spec_Relation_Group")
						|| classExist.getLocalName().equals("Specifications")
						|| classExist.getLocalName().equals("Specification_doesn'tHaveType")
						|| classExist.getLocalName().equals("Specification_hasType")) {
					console.printError(
							Messages.getValue("ExportWizardPage_owlExportError") + classExist.getLocalName());
				}
			}
		}
		
		IFolder reqifFolder = null;
		IFolder reqifFolder1 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE);
		IFolder reqifFolder2 = metagProject.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
		if (reqifFolder1.exists()) {
			reqifFolder = reqifFolder1;
		} else if (reqifFolder2.exists()) {
			reqifFolder = reqifFolder2;
		}
		
		OntClass owlAttribute_DefinitionClass = ontModel.createClass(METAG + "Attribute_Definition");
		owlReqIFClass.addSubClass(owlAttribute_DefinitionClass);
		OntClass owlAttribute_DefinitionStringClass = ontModel.createClass(METAG + "Attribute_Definition_String");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionStringClass);
		OntClass owlAttribute_DefinitionRealClass = ontModel.createClass(METAG + "Attribute_Definition_Real");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionRealClass);
		OntClass owlAttribute_DefinitionIntegerClass = ontModel.createClass(METAG + "Attribute_Definition_Integer");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionIntegerClass);
		OntClass owlAttribute_DefinitionEnumerationClass = ontModel
				.createClass(METAG + "Attribute_Definition_Enumeration");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionEnumerationClass);
		OntClass owlAttribute_DefinitionDateClass = ontModel.createClass(METAG + "Attribute_Definition_Date");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionDateClass);
		OntClass owlAttribute_DefinitionBooleanClass = ontModel.createClass(METAG + "Attribute_Definition_Boolean");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionBooleanClass);
		OntClass owlAttribute_DefinitionXHTMLClass = ontModel.createClass(METAG + "Attribute_Definition_XHTML");
		owlAttribute_DefinitionClass.addSubClass(owlAttribute_DefinitionXHTMLClass);

		OntClass owlDataTypesClass = ontModel.createClass(METAG + "DataTypes");
		owlReqIFClass.addSubClass(owlDataTypesClass);
		OntClass owlDataTypeStringClass = ontModel.createClass(METAG + "DataType_String");
		owlDataTypesClass.addSubClass(owlDataTypeStringClass);
		OntClass owlDataTypeRealClass = ontModel.createClass(METAG + "DataType_Real");
		owlDataTypesClass.addSubClass(owlDataTypeRealClass);
		OntClass owlDataTypeIntegerClass = ontModel.createClass(METAG + "DataType_Integer");
		owlDataTypesClass.addSubClass(owlDataTypeIntegerClass);
		OntClass owlDataTypeEnumerationClass = ontModel.createClass(METAG + "DataType_Enumeration");
		owlDataTypesClass.addSubClass(owlDataTypeEnumerationClass);
		OntClass owlDataTypeDateClass = ontModel.createClass(METAG + "DataType_Date");
		owlDataTypesClass.addSubClass(owlDataTypeDateClass);
		OntClass owlDataTypeBooleanClass = ontModel.createClass(METAG + "DataType_Boolean");
		owlDataTypesClass.addSubClass(owlDataTypeBooleanClass);
		OntClass owlDataTypeXHTMLClass = ontModel.createClass(METAG + "DataType_XHTML");
		owlDataTypesClass.addSubClass(owlDataTypeXHTMLClass);

		OntClass owlSpec_HierarchyClass = ontModel.createClass(METAG + "Spec_Hierarchy");
		owlReqIFClass.addSubClass(owlSpec_HierarchyClass);

		OntClass owlSpec_ObjectClass = ontModel.createClass(METAG + "Spec_Object");
		owlReqIFClass.addSubClass(owlSpec_ObjectClass);
		OntClass owlSpec_Object_doesntHaveTypeClass = ontModel.createClass(METAG + "Spec_Object_doesntHaveType");
		owlSpec_ObjectClass.addSubClass(owlSpec_Object_doesntHaveTypeClass);
		OntClass owlSpec_Object_hasTypeClass = ontModel.createClass(METAG + "Spec_Object_hasType");
		owlSpec_ObjectClass.addSubClass(owlSpec_Object_hasTypeClass);
		OntClass owlSpec_RelationClass = ontModel.createClass(METAG + "Spec_Relation");
		owlReqIFClass.addSubClass(owlSpec_RelationClass);
		OntClass owlSpec_Relation_doesntHaveTypeClass = ontModel.createClass(METAG + "Spec_Relation_doesntHaveType");
		owlSpec_RelationClass.addSubClass(owlSpec_Relation_doesntHaveTypeClass);
		OntClass owlSpec_Relation_hasTypeClass = ontModel.createClass(METAG + "Spec_Relation_hasType");
		owlSpec_RelationClass.addSubClass(owlSpec_Relation_hasTypeClass);
		OntClass owlSpec_Relation_GroupClass = ontModel.createClass(METAG + "Spec_Relation_Group");
		owlReqIFClass.addSubClass(owlSpec_Relation_GroupClass);
		OntClass owlSpec_Relation_Group_doesntHaveTypeClass = ontModel
				.createClass(METAG + "Spec_Relation_Group_doesntHaveType");
		owlSpec_Relation_GroupClass.addSubClass(owlSpec_Relation_Group_doesntHaveTypeClass);
		OntClass owlSpec_Relation_GrouphasTypeClass = ontModel.createClass(METAG + "Spec_Relation_Group_hasType");
		owlSpec_Relation_GroupClass.addSubClass(owlSpec_Relation_GrouphasTypeClass);
		OntClass owlSpecificationsClass = ontModel.createClass(METAG + "Specifications");
		owlReqIFClass.addSubClass(owlSpecificationsClass);
		OntClass owlSpecification_doesntHaveTypeClass = ontModel.createClass(METAG + "Specification_doesn'tHaveType");
		owlSpecificationsClass.addSubClass(owlSpecification_doesntHaveTypeClass);
		OntClass owlSpecification_hasTypeClass = ontModel.createClass(METAG + "Specification_hasType");
		owlSpecificationsClass.addSubClass(owlSpecification_hasTypeClass);

		OntClass owlSpecViewConfigurationsClass = ontModel.createClass(METAG + "specViewConfigurations");
		owlReqIFClass.addSubClass(owlSpecViewConfigurationsClass);
		OntClass owlColumnsClass = ontModel.createClass(METAG + "columns");
		owlSpecViewConfigurationsClass.addSubClass(owlColumnsClass);
		OntClass owlColumnClass = ontModel.createClass(METAG + "Column");
		owlColumnsClass.addSubClass(owlColumnClass);
		OntClass owlUnifiedColumnClass = ontModel.createClass(METAG + "UnifiedColumn");
		owlColumnsClass.addSubClass(owlUnifiedColumnClass);
		OntClass owlLeftHeaderColumnClass = ontModel.createClass(METAG + "leftHeaderColumn");
		owlSpecViewConfigurationsClass.addSubClass(owlLeftHeaderColumnClass);
		OntClass owlGeneralConfigurationClass = ontModel.createClass(METAG + "generalConfiguration");
		owlReqIFClass.addSubClass(owlGeneralConfigurationClass);
		OntClass owlLabelConfigurationClass = ontModel.createClass(METAG + "LabelConfiguration");
		owlGeneralConfigurationClass.addSubClass(owlLabelConfigurationClass);
		OntClass owlPresentationConfigurationsClass = ontModel.createClass(METAG + "presentationConfigurations");
		owlReqIFClass.addSubClass(owlPresentationConfigurationsClass);
		OntClass owLinewrapConfigurationClass = ontModel.createClass(METAG + "LinewrapConfiguration");
		owlPresentationConfigurationsClass.addSubClass(owLinewrapConfigurationClass);
		OntClass owIdConfigurationClass = ontModel.createClass(METAG + "IdConfiguration");
		owlPresentationConfigurationsClass.addSubClass(owIdConfigurationClass);
		OntClass owHeadlineConfigurationClass = ontModel.createClass(METAG + "HeadlineConfiguration");
		owlPresentationConfigurationsClass.addSubClass(owHeadlineConfigurationClass);

		// 创建AnnotationProperty
		AnnotationProperty annotationProIdentifier = ontModel.createAnnotationProperty(METAG + "identifier");//2023/11/14与IoF-Core中的Identifier Class重复
		AnnotationProperty annotationProTitle = ontModel.createAnnotationProperty(METAG + "TITLE");
		AnnotationProperty annotationProLast_Change = ontModel.createAnnotationProperty(METAG + "Last_Change");
		AnnotationProperty annotationProLong_Name = ontModel.createAnnotationProperty(METAG + "Long_Name");
		AnnotationProperty annotationProKey = ontModel.createAnnotationProperty(METAG + "Key");
		AnnotationProperty annotationProOtherContent = ontModel.createAnnotationProperty(METAG + "OtherContent");
		AnnotationProperty annotationProDesc = ontModel.createAnnotationProperty(METAG + "Desc");
		AnnotationProperty annotationProTheValue = ontModel.createAnnotationProperty(METAG + "TheValue");
		AnnotationProperty annotationProDefalutValue = ontModel.createAnnotationProperty(METAG + "DefalutValue");
		AnnotationProperty annotationProXHTMLDiv = ontModel.createAnnotationProperty(METAG + "xhtmldiv");//2023/11/14xhtml:div会被owl识别错误成Prefix
		AnnotationProperty annotationProDefalutLabel = ontModel.createAnnotationProperty(METAG + "DefalutLabel");
		AnnotationProperty annotationProMax_Length = ontModel.createAnnotationProperty(METAG + "Max_Length");
		AnnotationProperty annotationProMax = ontModel.createAnnotationProperty(METAG + "Max");
		AnnotationProperty annotationProMin = ontModel.createAnnotationProperty(METAG + "Min");
		AnnotationProperty annotationProPrefix = ontModel.createAnnotationProperty(METAG + "prefix");
		AnnotationProperty annotationProCount = ontModel.createAnnotationProperty(METAG + "count");
		AnnotationProperty annotationProSize = ontModel.createAnnotationProperty(METAG + "size");
		AnnotationProperty annotationProVerticalAlign = ontModel.createAnnotationProperty(METAG + "verticalAlign");
		AnnotationProperty annotationProWidth = ontModel.createAnnotationProperty(METAG + "Width");
		AnnotationProperty annotationProLabel = ontModel.createAnnotationProperty(METAG + "Label");
		AnnotationProperty annotationProSequence = ontModel.createAnnotationProperty(METAG + "sequence");
		AnnotationProperty annotationProReqIFComment = ontModel.createAnnotationProperty(METAG + "COMMENT");
		AnnotationProperty annotationProReqIFCreationtime = ontModel.createAnnotationProperty(METAG + "CREATION-TIME");
		AnnotationProperty annotationProReqIFToolId = ontModel.createAnnotationProperty(METAG + "REQ-IF-TOOL-ID");
		AnnotationProperty annotationProReqIFVesion = ontModel.createAnnotationProperty(METAG + "REQ-IF-VERSION");
		AnnotationProperty annotationProSourceId = ontModel.createAnnotationProperty(METAG + "SOURCE-TOOL-ID");
		AnnotationProperty annotationProIsSimplified = ontModel.createAnnotationProperty(METAG + "isSimplified");
		AnnotationProperty annotationProSpecObjectType = ontModel.createAnnotationProperty(METAG + "SpecObjectType");
		AnnotationProperty annotationProSpecificationType = ontModel.createAnnotationProperty(METAG + "SpecificationType");
		AnnotationProperty annotationProSpecRelationType = ontModel.createAnnotationProperty(METAG + "SpecRelationType");
		AnnotationProperty annotationProRelationGroupType = ontModel.createAnnotationProperty(METAG + "RelationGroupType");
		AnnotationProperty annotationProMark = ontModel.createAnnotationProperty(METAG + "mark");
		AnnotationProperty annotationProAttributeDefinitionType = ontModel.createAnnotationProperty(METAG + "AttributeDefinitionType");
		
		AnnotationProperty annotationProDataTypesStructure = ontModel.createAnnotationProperty(METAG + "dataTypesStructure");
		AnnotationProperty annotationProSpecTypesStructure = ontModel.createAnnotationProperty(METAG + "specTypesStructure");
		AnnotationProperty annotationProSpecAttributesStructure = ontModel.createAnnotationProperty(METAG + "specAttributesStructure");
		AnnotationProperty annotationProSpecObjectsStructure = ontModel.createAnnotationProperty(METAG + "specObjectsStructure");
		AnnotationProperty annotationProSpecRelationsStructure = ontModel.createAnnotationProperty(METAG + "specRelationsStructure");
		AnnotationProperty annotationProValuesStructure = ontModel.createAnnotationProperty(METAG + "valuesStructure");
		AnnotationProperty annotationProSpecificationsStructure = ontModel.createAnnotationProperty(METAG + "specificationsStructure");
		AnnotationProperty annotationProSpecRelationGroupStructure = ontModel.createAnnotationProperty(METAG + "specificationsStructure");
		AnnotationProperty annotationProChildrenStructure = ontModel.createAnnotationProperty(METAG + "childrenStructure");
		// 增加reqif标记语言
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");

		// 创建ObjectProperty
		ObjectProperty objectProAttributeDefinition_Ref_DataType = ontModel.createObjectProperty(METAG + "AttributeDefinition_Ref_DataType");
		ObjectProperty objectProSpecObjectType_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "SpecObjectType_has_AttributeDefinition");
		ObjectProperty objectProSpecificationType_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "SpecificationType_has_AttributeDefinition");
		ObjectProperty objectProSpecRelationType_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "SpecRelationType_has_AttributeDefinition");
		ObjectProperty objectProRelationGroupType_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "RelationGroupType_has_AttributeDefinition");
		ObjectProperty objectProSpecObject_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "SpecObject_has_AttributeDefinition");
		ObjectProperty objectProSpecification_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "Specification_has_AttributeDefinition");
		ObjectProperty objectProSpecRelation_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "SpecRelation_has_AttributeDefinition");
//		ObjectProperty objectProRelationGroup_has_AttributeDefinition = ontModel.createObjectProperty(METAG + "RelationGroup_has_AttributeDefinition");
		ObjectProperty objectProSpecification_has_Column = ontModel.createObjectProperty(METAG + "Specification_has_Column");
		ObjectProperty objectProLinewrapConfiguration_Apply_DataType = ontModel.createObjectProperty(METAG + "LinewrapConfiguration_Apply_DataType");
		ObjectProperty objectProIdConfiguration_Apply_DataType = ontModel.createObjectProperty(METAG + "IdConfiguration_Apply_DataType");
		ObjectProperty objectProHeadlineConfiguration_Apply_DataType = ontModel.createObjectProperty(METAG + "HeadlineConfiguration_Apply_DataType");
		ObjectProperty objectProSpecObject_Ref_EnumAttributeDefinition = ontModel.createObjectProperty(METAG + "SpecObject_Ref_EnumAttributeDefinition");
		ObjectProperty objectProSpecObject_Ref_EnumValue = ontModel.createObjectProperty(METAG + "SpecObject_Ref_EnumValue");
		ObjectProperty objectProSpecRelation_Ref_EnumAttributeDefinition = ontModel.createObjectProperty(METAG + "SpecRelation_Ref_EnumAttributeDefinition");
		ObjectProperty objectProSpecRelation_Ref_EnumValue = ontModel.createObjectProperty(METAG + "SpecRelation_Ref_EnumValue");
		ObjectProperty objectProSpecification_Ref_EnumAttributeDefinition = ontModel.createObjectProperty(METAG + "Specification_Ref_EnumAttributeDefinition");
		ObjectProperty objectProSpecification_Ref_EnumValue = ontModel.createObjectProperty(METAG + "Specification_Ref_EnumValue");
//		ObjectProperty objectProRelationGroup_Ref_EnumAttributeDefinition = ontModel.createObjectProperty(METAG + "RelationGroup_Ref_EnumAttributeDefinition");
//		ObjectProperty objectProRelationGroup_Ref_EnumValue = ontModel.createObjectProperty(METAG + "RelationGroup_Ref_EnumValue");
		
		ObjectProperty objectProRelationGoup_Ref_SpecRelation = ontModel.createObjectProperty(METAG + "RelationGoup_Ref_SpecRelation");
		ObjectProperty objectProRelationGoup_sourceRef_Specification = ontModel.createObjectProperty(METAG + "RelationGoup_sourceRef_Specification");
		ObjectProperty objectProRelationGoup_targetRef_Specification = ontModel.createObjectProperty(METAG + "RelationGoup_targetRef_Specification");
		ObjectProperty objectProSpecRelation_sourceRef_SpecObject = ontModel.createObjectProperty(METAG + "SpecRelation_sourceRef_SpecObject");
		ObjectProperty objectProSpecRelation_targetRef_SpecObject = ontModel.createObjectProperty(METAG + "SpecRelation_targetRef_SpecObject");
		ObjectProperty objectProReqIFOwnDefaultLabel = ontModel.createObjectProperty(METAG + "ReqIF_own_defaultLabel");
		ObjectProperty objectProReqIFOwnLinewrapConfiguration = ontModel.createObjectProperty(METAG + "ReqIF_own_LinewrapConfiguration");
		ObjectProperty objectProReqIFOwnIdConfiguration = ontModel.createObjectProperty(METAG + "ReqIF_own_IdConfiguration");
		ObjectProperty objectProReqIFOwnHeadlineConfiguration = ontModel.createObjectProperty(METAG + "ReqIF_own_HeadlineConfiguration");
		ObjectProperty objectProReqIFOwnDataType = ontModel.createObjectProperty(METAG + "ReqIF_own_DataType");
		ObjectProperty objectProReqIFOwnSpecObjectType = ontModel.createObjectProperty(METAG + "ReqIF_own_SpecObjectType");
		ObjectProperty objectProReqIFOwnSpecificationType = ontModel.createObjectProperty(METAG + "ReqIF_own_SpecificationType");
		ObjectProperty objectProReqIFOwnSpecRelationType = ontModel.createObjectProperty(METAG + "ReqIF_own_SpecRelationType");
		ObjectProperty objectProReqIFOwnRelationGroupType = ontModel.createObjectProperty(METAG + "ReqIF_own_RelationGroupType");
		ObjectProperty objectProReqIFOwnSpecObject = ontModel.createObjectProperty(METAG + "ReqIF_own_SpecObject");
		ObjectProperty objectProReqIFOwnSpecification = ontModel.createObjectProperty(METAG + "ReqIF_own_Specification");
		ObjectProperty objectProReqIFOwnSpecRelation = ontModel.createObjectProperty(METAG + "ReqIF_own_SpecRelation");
		ObjectProperty objectProReqIFOwnRelationGroup = ontModel.createObjectProperty(METAG + "ReqIF_own_RelationGroup");
		
		for (IResource fileLanguage : reqifFolder.members()) {
			if (fileLanguage.getType() == IResource.FOLDER) {
				IFolder languageFolder = (IFolder) fileLanguage;
				IFolder fileModel = null;
				IFolder fileModel1 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL);
				IFolder fileModel2 = (IFolder) languageFolder.findMember("/" + PackagePath.TYPE_MODEL_ZH);
				if (fileModel1 != null) {
					fileModel = fileModel1;
				} else if (fileModel2 != null) {
					fileModel = fileModel2;
				}
				for (IResource f : fileModel.members()) {
					if (f.getName().endsWith(".reqif")) {
						// 读ReqIF文件
						File file = new File(f.getLocation().toOSString());
						SAXReader reader = new SAXReader();
						Document document = reader.read(file);
						Element root = document.getRootElement();
						// The Header,ReqIF文件信息
						String fileName = document.getName().substring( document.getName().lastIndexOf("/")+1,document.getName().indexOf("."));
						Element reqIFHeader = root.element("THE-HEADER").element("REQ-IF-HEADER");
						String reqIFIdentifier = reqIFHeader.attribute("IDENTIFIER").getValue();
						Individual owlReqIFIndividual = ontModel.createIndividual(METAG + fileName,
								owlReqIFClass);
						// 增加reqif标记语言
						OntClass owlLanguage = ontModel.getOntClass(METAG + languageFolder.getName());
						if (owlLanguage == null) {
							String languageId = SaveKarInformation.getLanguageId(languageFolder);
							OntClass ontClass = ontModel.getOntClass(METAG + languageId);
							owlReqIFIndividual.addProperty(annotationPropertyModelLocation, languageFolder.getName());
						} else {
							owlReqIFIndividual.addProperty(annotationPropertyModelLocation, owlLanguage.getLocalName());
						}
						owlReqIFIndividual.addProperty(annotationProIdentifier, reqIFIdentifier);
						String reqIFFileName = "";
						if (reqIFHeader.element("TITLE") != null) {
							Element title = reqIFHeader.element("TITLE");
							reqIFFileName = title.getText();
							owlReqIFIndividual.addProperty(annotationProTitle, reqIFFileName);
						}

						Element reqIFComment = root.element("THE-HEADER").element("REQ-IF-HEADER").element("COMMENT");
						String comment = reqIFComment.getText();
						owlReqIFIndividual.addProperty(annotationProReqIFComment, comment);

						Element reqIFCreationtime = root.element("THE-HEADER").element("REQ-IF-HEADER")
								.element("CREATION-TIME");
						String creationTime = reqIFCreationtime.getText();
						owlReqIFIndividual.addProperty(annotationProReqIFCreationtime, creationTime);

						Element reqIFToolId = root.element("THE-HEADER").element("REQ-IF-HEADER")
								.element("REQ-IF-TOOL-ID");
						String toolId = reqIFToolId.getText();
						owlReqIFIndividual.addProperty(annotationProReqIFToolId, toolId);

						Element reqIFVersion = root.element("THE-HEADER").element("REQ-IF-HEADER")
								.element("REQ-IF-VERSION");
						String version = reqIFVersion.getText();
						owlReqIFIndividual.addProperty(annotationProReqIFVesion, version);

						Element sourceID = root.element("THE-HEADER").element("REQ-IF-HEADER")
								.element("SOURCE-TOOL-ID");
						String sourceId = sourceID.getText();
						owlReqIFIndividual.addProperty(annotationProSourceId, sourceId);

						// 读取ReqIF的<DATATYPES>并生成
						try {
							if(root.element("CORE-CONTENT").element("REQ-IF-CONTENT").element("DATATYPES") != null) {
								owlReqIFIndividual.addProperty(annotationProDataTypesStructure, "hasStructure_DATATYPES");
								Element dataTypes = root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
										.element("DATATYPES");
								for (Iterator<Element> it = dataTypes.elementIterator(); it.hasNext();) {
									Element dataTypesChild = it.next();
									String dataTypesName = dataTypesChild.getName();
									String[] strs = dataTypesName.split("-");

									String identifier = dataTypesChild.attribute("IDENTIFIER").getValue();
									String lastChange = dataTypesChild.attribute("LAST-CHANGE").getValue();

									OntClass owldataTypeClass = ontModel.createClass(METAG + identifier);
									if (strs[2].equals("STRING")) {
										owlDataTypeStringClass.addSubClass(owldataTypeClass);
									}
									if (strs[2].equals("REAL")) {
										owlDataTypeRealClass.addSubClass(owldataTypeClass);
									}
									if (strs[2].equals("INTEGER")) {
										owlDataTypeIntegerClass.addSubClass(owldataTypeClass);
									}
									if (strs[2].equals("ENUMERATION")) {
										owlDataTypeEnumerationClass.addSubClass(owldataTypeClass);
									}
									if (strs[2].equals("DATE")) {
										owlDataTypeDateClass.addSubClass(owldataTypeClass);
									}
									if (strs[2].equals("BOOLEAN")) {
										owlDataTypeBooleanClass.addSubClass(owldataTypeClass);
									}
									if (strs[2].equals("XHTML")) {
										owlDataTypeXHTMLClass.addSubClass(owldataTypeClass);
									}

									owldataTypeClass.addProperty(annotationProIdentifier, identifier);
									owldataTypeClass.addProperty(annotationProLast_Change, lastChange);
									if (dataTypesChild.attribute("DESC") != null) {
										String desc = dataTypesChild.attribute("DESC").getValue();
										owldataTypeClass.addProperty(annotationProDesc, desc);
									}
									if (dataTypesChild.attribute("LONG-NAME") != null) {
										String longName = dataTypesChild.attribute("LONG-NAME").getValue();
										owldataTypeClass.addProperty(annotationProLong_Name, longName);
									}
									if (dataTypesChild.attribute("MAX-LENGTH") != null) {
										String maxLength = dataTypesChild.attribute("MAX-LENGTH").getValue();
										owldataTypeClass.addProperty(annotationProMax_Length, maxLength);
									}
									if (dataTypesChild.attribute("MAX") != null) {
										String max = dataTypesChild.attribute("MAX").getValue();
										owldataTypeClass.addProperty(annotationProMax, max);
									}
									if (dataTypesChild.attribute("MIN") != null) {
										String min = dataTypesChild.attribute("MIN").getValue();
										owldataTypeClass.addProperty(annotationProMin, min);
									}

									if (strs[2].equals("ENUMERATION")) {
										if (dataTypesChild.element("SPECIFIED-VALUES") != null) {
											Element specifiedValues = dataTypesChild.element("SPECIFIED-VALUES");
											for (Iterator<Element> it2 = specifiedValues.elementIterator(); it2
													.hasNext();) {
												Element enumValue = it2.next();
												String enumValueIdentifier = enumValue.attribute("IDENTIFIER").getValue();
												String enumValueLastChange = enumValue.attribute("LAST-CHANGE").getValue();
												OntClass owlEnumValueClass = ontModel
														.createClass(METAG + enumValueIdentifier);
												owldataTypeClass.addSubClass(owlEnumValueClass);

												owlEnumValueClass.addProperty(annotationProIdentifier, enumValueIdentifier);
												owlEnumValueClass.addProperty(annotationProLast_Change,
														enumValueLastChange);

												if (enumValue.attribute("LONG-NAME") != null) {
													String longName = enumValue.attribute("LONG-NAME").getValue();
													owlEnumValueClass.addProperty(annotationProLong_Name, longName);
												}

												Element properties = enumValue.element("PROPERTIES");
												Element embeddedValue = properties.element("EMBEDDED-VALUE");
												if (enumValue.attribute("KEY") != null) {
													String key = embeddedValue.attribute("KEY").getValue();
													owlEnumValueClass.addProperty(annotationProKey, key);
												}
												if (enumValue.attribute("OTHER-CONTENT") != null) {
													String otherContent = embeddedValue.attribute("OTHER-CONTENT")
															.getValue();
													owlEnumValueClass.addProperty(annotationProOtherContent, otherContent);
												}

											}
										}
									}
									//20231112
//									owlReqIFIndividual.addProperty(objectProReqIFOwnDataType, owldataTypeClass);// 绑定到该ReqIF实例
									Individual owldataTypeIndividual = ontModel.createIndividual(METAG + "0" + identifier,
											owldataTypeClass);
									owlReqIFIndividual.addProperty(objectProReqIFOwnDataType, owldataTypeIndividual);// 绑定到该ReqIF实例
								}	
							}
						} catch (NullPointerException npe) {
							System.out.println("Can not find!");
						}
						// 读取ReqIF的<SPEC-TYPES>并生成
						try {
							if(root.element("CORE-CONTENT").element("REQ-IF-CONTENT").element("SPEC-TYPES")!=null) {
								owlReqIFIndividual.addProperty(annotationProSpecTypesStructure, "hasStructure_SPEC-TYPES");
								Element specTypes = root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
										.element("SPEC-TYPES");
								for (Iterator<Element> it = specTypes.elementIterator(); it.hasNext();) {
									Element specTypesChild = it.next();
									// 读取ReqIF的SPEC-OBJECT-TYPE并生成
									if (specTypesChild.getName().equals("SPEC-OBJECT-TYPE")) {
										String identifier = specTypesChild.attribute("IDENTIFIER").getValue();
										String lastChange = specTypesChild.attribute("LAST-CHANGE").getValue();

										OntClass owlSpecObjectTypeClass = ontModel.createClass(METAG + identifier);
										owlSpec_Object_hasTypeClass.addSubClass(owlSpecObjectTypeClass);
										owlSpecObjectTypeClass.addProperty(annotationProIdentifier, identifier);
										owlSpecObjectTypeClass.addProperty(annotationProLast_Change, lastChange);
										if (specTypesChild.attribute("LONG-NAME") != null) {
											String longName = specTypesChild.attribute("LONG-NAME").getValue();
											owlSpecObjectTypeClass.addProperty(annotationProLong_Name, longName);
										}
										if (specTypesChild.element("SPEC-ATTRIBUTES") != null) {
											owlSpecObjectTypeClass.addProperty(annotationProSpecAttributesStructure, "hasStructure_SPEC-ATTRIBUTES");
											// 读取SPEC-OBJECT-TYPE的SPEC-ATTRIBUTES并生成
											Element specAttributes = specTypesChild.element("SPEC-ATTRIBUTES");
											for (Iterator<Element> it2 = specAttributes.elementIterator(); it2.hasNext();) {
												Element specAttributeChild = it2.next();
												String identifier2 = specAttributeChild.attribute("IDENTIFIER").getValue();
												String lastChange2 = specAttributeChild.attribute("LAST-CHANGE").getValue();

												OntClass owlspecAttributeClass = ontModel.createClass(METAG + identifier2);
												String attributTypesName = specAttributeChild.getName();
												String[] strs = attributTypesName.split("-");
												if (strs[2].equals("STRING")) {
													owlAttribute_DefinitionStringClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("REAL")) {
													owlAttribute_DefinitionRealClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("INTEGER")) {
													owlAttribute_DefinitionIntegerClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("ENUMERATION")) {
													owlAttribute_DefinitionEnumerationClass
															.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("DATE")) {
													owlAttribute_DefinitionDateClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("BOOLEAN")) {
													owlAttribute_DefinitionBooleanClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("XHTML")) {
													owlAttribute_DefinitionXHTMLClass.addSubClass(owlspecAttributeClass);
												}

												owlspecAttributeClass.addProperty(annotationProIdentifier, identifier2);
												owlspecAttributeClass.addProperty(annotationProLast_Change, lastChange2);
												if (specAttributeChild.attribute("DESC") != null) {
													String desc2 = specAttributeChild.attribute("DESC").getValue();
													owlspecAttributeClass.addProperty(annotationProDesc, desc2);
												}
												if (specAttributeChild.attribute("LONG-NAME") != null) {
													String longName2 = specAttributeChild.attribute("LONG-NAME").getValue();
													owlspecAttributeClass.addProperty(annotationProLong_Name, longName2);
												}

												if (specAttributeChild.element("TYPE") != null) {
													// 读取SPEC-ATTRIBUTES引用的数据类型并生成
													Element attributeDefinitionType = specAttributeChild.element("TYPE");
													List<Element> type = attributeDefinitionType.elements();
													if (type.size() != 0) {
														Element dataTypeDefinitionType = type.get(0);
														String dataTypeDefinitionTypeID = dataTypeDefinitionType.getText();
														OntClass owlDatatypeRefClass = ontModel
																.getOntClass(METAG + dataTypeDefinitionTypeID);
														SomeValuesFromRestriction sometype = ontModel
																.createSomeValuesFromRestriction(null, objectProAttributeDefinition_Ref_DataType,
																		owlDatatypeRefClass);
														owlspecAttributeClass.addEquivalentClass(sometype);
													}
												}
												if (specAttributeChild.element("DEFAULT-VALUE") != null) {
													// 读取DEFAULT-VALUE
													Element defaultValue = specAttributeChild.element("DEFAULT-VALUE");
													for (Iterator<Element> it3 = defaultValue.elementIterator(); it3
															.hasNext();) {
														Element attributeValueType = it3.next();
														if (attributeValueType.attribute("THE-VALUE") != null) {
															String theValue = attributeValueType.attribute("THE-VALUE")
																	.getValue();
															Element definition = attributeValueType.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
//																Element attributeDefinitionTypeRef = type.get(0);
//																String attributeDefinitionTypeRefID = attributeDefinitionTypeRef.getText();

//																OntClass owlattributeDefinitionTypeRefClass = ontModel
//																		.getOntClass(METAG + attributeDefinitionTypeRefID);//就是owlspecAttributeClass

																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
														} else {
															// 枚举型
															if (strs[2].equals("ENUMERATION")) {
																if (attributeValueType.element("DEFINITION") != null) {
																	Element definition = attributeValueType
																			.element("DEFINITION");
																	Element attributionDefinitionEnum = definition.element(
																			"ATTRIBUTE-DEFINITION-ENUMERATION-REF");
																	String theValue = attributionDefinitionEnum.getText();
																	owlspecAttributeClass.addProperty(
																			annotationProDefalutValue, theValue);
																}
															}
															// XHTML
															// 需要与最初工具验证
															if (attributeValueType.attribute("IS-SIMPLIFIED") != null) {
																String isSimplified = attributeValueType
																		.attribute("IS-SIMPLIFIED").getValue();
																owlspecAttributeClass.addProperty(annotationProIsSimplified, isSimplified);
																if (defaultValue.element("THE-ORIGINAL-VALUE") != null) {
																	Element theOriginValue = defaultValue
																			.element("THE-ORIGINAL-VALUE");
																}
																if (defaultValue.element("THE-VALUE") != null) {
																	Element theValue = defaultValue.element("THE-VALUE");
																}
//																owlspecAttributeClass.addProperty(objectProHas_defalut_value,theValue);
															}
														}
													}

												}

												// 读取SPEC-OBJECT-TYPE拥有属性SPEC-ATTRIBUTES并生成
												SomeValuesFromRestriction someattribute = ontModel
														.createSomeValuesFromRestriction(null, objectProSpecObjectType_has_AttributeDefinition,
																owlspecAttributeClass);
												owlSpecObjectTypeClass.addEquivalentClass(someattribute);
												//20231112
//												owlReqIFIndividual.addProperty(objectProReqIFOwnSpecObjectType, owlSpecObjectTypeClass);// 绑定到该ReqIF实例
												Individual owlSpecObjectTypeIndividual = ontModel.createIndividual(METAG + "0" + identifier,
														owlSpecObjectTypeClass);
												owlReqIFIndividual.addProperty(objectProReqIFOwnSpecObjectType, owlSpecObjectTypeIndividual);// 绑定到该ReqIF实例
											}
										}

									}
									// 读取ReqIF的SPECIFICATION-TYPE并生成
									else if (specTypesChild.getName().equals("SPECIFICATION-TYPE")) {

										String identifier = specTypesChild.attribute("IDENTIFIER").getValue();
										String lastChange = specTypesChild.attribute("LAST-CHANGE").getValue();

										OntClass owlSpecificationTypeClass = ontModel.createClass(METAG + identifier);
										owlSpecification_hasTypeClass.addSubClass(owlSpecificationTypeClass);
										if (specTypesChild.attribute("LONG-NAME") != null) {
											String longName = specTypesChild.attribute("LONG-NAME").getValue();
											owlSpecificationTypeClass.addProperty(annotationProLong_Name, longName);
										}
										owlSpecificationTypeClass.addProperty(annotationProIdentifier, identifier);
										owlSpecificationTypeClass.addProperty(annotationProLast_Change, lastChange);

										// 读取SPECIFICATION-TYPE的SPEC-ATTRIBUTES并生成
										if (specTypesChild.element("SPEC-ATTRIBUTES") != null) {
											owlSpecificationTypeClass.addProperty(annotationProSpecAttributesStructure, "hasStructure_SPEC-ATTRIBUTES");
											Element specAttributes = specTypesChild.element("SPEC-ATTRIBUTES");
											for (Iterator<Element> it2 = specAttributes.elementIterator(); it2.hasNext();) {
												Element specAttributeChild = it2.next();
												String identifier2 = specAttributeChild.attribute("IDENTIFIER").getValue();
												String lastChange2 = specAttributeChild.attribute("LAST-CHANGE").getValue();

												OntClass owlspecAttributeClass = ontModel.createClass(METAG + identifier2);
												String attributTypesName = specAttributeChild.getName();
												String[] strs = attributTypesName.split("-");
												if (strs[2].equals("STRING")) {
													owlAttribute_DefinitionStringClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("REAL")) {
													owlAttribute_DefinitionRealClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("INTEGER")) {
													owlAttribute_DefinitionIntegerClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("ENUMERATION")) {
													owlAttribute_DefinitionEnumerationClass
															.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("DATE")) {
													owlAttribute_DefinitionDateClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("BOOLEAN")) {
													owlAttribute_DefinitionBooleanClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("XHTML")) {
													owlAttribute_DefinitionXHTMLClass.addSubClass(owlspecAttributeClass);
												}

												owlspecAttributeClass.addProperty(annotationProIdentifier, identifier2);
												owlspecAttributeClass.addProperty(annotationProLast_Change, lastChange2);
												if (specAttributeChild.attribute("DESC") != null) {
													String desc2 = specAttributeChild.attribute("DESC").getValue();
													owlspecAttributeClass.addProperty(annotationProDesc, desc2);
												}
												if (specAttributeChild.attribute("LONG-NAME") != null) {
													String longName2 = specAttributeChild.attribute("LONG-NAME").getValue();
													owlspecAttributeClass.addProperty(annotationProLong_Name, longName2);
												}

												if (specAttributeChild.element("TYPE") != null) {
													// 读取SPEC-ATTRIBUTES引用的数据类型并生成
													Element attributeDefinitionType = specAttributeChild.element("TYPE");
													List<Element> type = attributeDefinitionType.elements();
													if (type.size() != 0) {
														Element dataTypeDefinitionType = type.get(0);
														String dataTypeDefinitionTypeID = dataTypeDefinitionType.getText();
														OntClass owlDatatypeRefClass = ontModel
																.getOntClass(METAG + dataTypeDefinitionTypeID);
														SomeValuesFromRestriction sometype = ontModel
																.createSomeValuesFromRestriction(null, objectProAttributeDefinition_Ref_DataType,
																		owlDatatypeRefClass);
														owlspecAttributeClass.addEquivalentClass(sometype);
													}
												}

												if (specAttributeChild.element("DEFAULT-VALUE") != null) {
													// 读取DEFAULT-VALUE
													Element defaultValue = specAttributeChild.element("DEFAULT-VALUE");
													for (Iterator<Element> it3 = defaultValue.elementIterator(); it3
															.hasNext();) {
														Element attributeValueType = it3.next();
														if (attributeValueType.attribute("THE-VALUE") != null) {
															String theValue = attributeValueType.attribute("THE-VALUE")
																	.getValue();
															Element definition = attributeValueType.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
																Element attributeDefinitionTypeRef = type.get(0);
//																String attributeDefinitionTypeRefID = attributeDefinitionTypeRef.getText();

//																OntClass owlattributeDefinitionTypeRefClass = ontModel
//																		.getOntClass(METAG + attributeDefinitionTypeRefID);//就是owlspecAttributeClass
																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
														} else {
															// 枚举型
															if (strs[2].equals("ENUMERATION")) {
																Element definition = attributeValueType
																		.element("DEFINITION");
																Element attributionDefinitionEnum = definition
																		.element("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
																String theValue = attributionDefinitionEnum.getText();
																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
															// XHTML
															// 需要与最初工具验证
															if (attributeValueType.attribute("IS-SIMPLIFIED") != null) {
																String isSimplified = attributeValueType
																		.attribute("IS-SIMPLIFIED").getValue();
																owlspecAttributeClass.addProperty(annotationProIsSimplified, isSimplified);
																if (defaultValue.element("THE-ORIGINAL-VALUE") != null) {
																	Element theOriginValue = defaultValue
																			.element("THE-ORIGINAL-VALUE");
																}
																if (defaultValue.element("THE-VALUE") != null) {
																	Element theValue = defaultValue.element("THE-VALUE");
																}
//																owlspecAttributeClass.addProperty(objectProHas_defalut_value,theValue);
															}
														}
													}
												}

												// 读取SPECIFICATION-TYPE拥有属性SPEC-ATTRIBUTES并生成
												SomeValuesFromRestriction someattribute = ontModel
														.createSomeValuesFromRestriction(null, objectProSpecificationType_has_AttributeDefinition,
																owlspecAttributeClass);
												owlSpecificationTypeClass.addEquivalentClass(someattribute);
												//20231112
//												owlReqIFIndividual.addProperty(objectProReqIFOwnSpecificationType, owlSpecificationTypeClass);// 绑定到该ReqIF实例
												Individual owlSpecificationTypeIndividual = ontModel.createIndividual(METAG + "0" + identifier,
														owlSpecificationTypeClass);
												owlReqIFIndividual.addProperty(objectProReqIFOwnSpecificationType, owlSpecificationTypeIndividual);// 绑定到该ReqIF实例
											}
										}

									}

									// 读取ReqIF的SPEC-RELATION-TYPE并生成
									else if (specTypesChild.getName().equals("SPEC-RELATION-TYPE")) {
										String identifier = specTypesChild.attribute("IDENTIFIER").getValue();
										String lastChange = specTypesChild.attribute("LAST-CHANGE").getValue();

										OntClass owlSpecRelationTypeClass = ontModel.createClass(METAG + identifier);
										owlSpec_Relation_hasTypeClass.addSubClass(owlSpecRelationTypeClass);
										owlSpecRelationTypeClass.addProperty(annotationProIdentifier, identifier);
										owlSpecRelationTypeClass.addProperty(annotationProLast_Change, lastChange);
										if (specTypesChild.attribute("LONG-NAME") != null) {
											String longName = specTypesChild.attribute("LONG-NAME").getValue();
											owlSpecRelationTypeClass.addProperty(annotationProLong_Name, longName);
										}

										if (specTypesChild.element("SPEC-ATTRIBUTES") != null) {
											owlSpecRelationTypeClass.addProperty(annotationProSpecAttributesStructure, "hasStructure_SPEC-ATTRIBUTES");
											// 读取SPEC-RELATION-TYPE的SPEC-ATTRIBUTES并生成
											Element specAttributes = specTypesChild.element("SPEC-ATTRIBUTES");
											for (Iterator<Element> it2 = specAttributes.elementIterator(); it2.hasNext();) {
												Element specAttributeChild = it2.next();

												String identifier2 = specAttributeChild.attribute("IDENTIFIER").getValue();
												String lastChange2 = specAttributeChild.attribute("LAST-CHANGE").getValue();

												OntClass owlspecAttributeClass = ontModel.createClass(METAG + identifier2);
												String attributTypesName = specAttributeChild.getName();
												String[] strs = attributTypesName.split("-");
												if (strs[2].equals("STRING")) {
													owlAttribute_DefinitionStringClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("REAL")) {
													owlAttribute_DefinitionRealClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("INTEGER")) {
													owlAttribute_DefinitionIntegerClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("ENUMERATION")) {
													owlAttribute_DefinitionEnumerationClass
															.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("DATE")) {
													owlAttribute_DefinitionDateClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("BOOLEAN")) {
													owlAttribute_DefinitionBooleanClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("XHTML")) {
													owlAttribute_DefinitionXHTMLClass.addSubClass(owlspecAttributeClass);
												}

												owlspecAttributeClass.addProperty(annotationProIdentifier, identifier2);
												owlspecAttributeClass.addProperty(annotationProLast_Change, lastChange2);
												if (specAttributeChild.attribute("DESC") != null) {
													String desc2 = specAttributeChild.attribute("DESC").getValue();
													owlspecAttributeClass.addProperty(annotationProDesc, desc2);
												}
												if (specAttributeChild.attribute("LONG-NAME") != null) {
													String longName2 = specAttributeChild.attribute("LONG-NAME").getValue();
													owlspecAttributeClass.addProperty(annotationProLong_Name, longName2);
												}
												if (specAttributeChild.element("TYPE") != null) {
													// 读取SPEC-ATTRIBUTES引用的数据类型并生成
													Element attributeDefinitionType = specAttributeChild.element("TYPE");
													List<Element> type = attributeDefinitionType.elements();
													if (type.size() != 0) {
														Element dataTypeDefinitionType = type.get(0);
														String dataTypeDefinitionTypeID = dataTypeDefinitionType.getText();
														OntClass owlDatatypeRefClass = ontModel
																.getOntClass(METAG + dataTypeDefinitionTypeID);
														SomeValuesFromRestriction sometype = ontModel
																.createSomeValuesFromRestriction(null, objectProAttributeDefinition_Ref_DataType,
																		owlDatatypeRefClass);
														owlspecAttributeClass.addEquivalentClass(sometype);
													}
												}

												if (specAttributeChild.element("DEFAULT-VALUE") != null) {
													// 读取DEFAULT-VALUE
													Element defaultValue = specAttributeChild.element("DEFAULT-VALUE");
													for (Iterator<Element> it3 = defaultValue.elementIterator(); it3
															.hasNext();) {
														Element attributeValueType = it3.next();
														if (attributeValueType.attribute("THE-VALUE") != null) {
															String theValue = attributeValueType.attribute("THE-VALUE")
																	.getValue();
															Element definition = attributeValueType.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
																Element attributeDefinitionTypeRef = type.get(0);
//																String attributeDefinitionTypeRefID = attributeDefinitionTypeRef.getText();

//																OntClass owlattributeDefinitionTypeRefClass = ontModel
//																		.getOntClass(METAG + attributeDefinitionTypeRefID);//就是owlspecAttributeClass
																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
														} else {
															// 枚举型
															if (strs[2].equals("ENUMERATION")) {
																Element definition = attributeValueType
																		.element("DEFINITION");
																Element attributionDefinitionEnum = definition
																		.element("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
																String theValue = attributionDefinitionEnum.getText();
																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
															// XHTML
															// 需要与最初工具验证
															if (attributeValueType.attribute("IS-SIMPLIFIED") != null) {
																String isSimplified = attributeValueType
																		.attribute("IS-SIMPLIFIED").getValue();
																owlspecAttributeClass.addProperty(annotationProIsSimplified, isSimplified);
																if (defaultValue.element("THE-ORIGINAL-VALUE") != null) {
																	Element theOriginValue = defaultValue
																			.element("THE-ORIGINAL-VALUE");
																}
																if (defaultValue.element("THE-VALUE") != null) {
																	Element theValue = defaultValue.element("THE-VALUE");
																}
//																owlspecAttributeClass.addProperty(objectProHas_defalut_value,theValue);
															}
														}
													}
												}

												// 读取SPEC-RELATION-TYPE拥有属性SPEC-ATTRIBUTES并生成
												SomeValuesFromRestriction someAttribute = ontModel
														.createSomeValuesFromRestriction(null, objectProSpecRelationType_has_AttributeDefinition,
																owlspecAttributeClass);
												owlSpecRelationTypeClass.addEquivalentClass(someAttribute);
												//20231112
//												owlReqIFIndividual.addProperty(objectProReqIFOwnSpecRelationType, owlSpecRelationTypeClass);// 绑定到该ReqIF实例
												Individual owlSpecRelationTypeIndividual = ontModel.createIndividual(METAG + "0" + identifier,
														owlSpecRelationTypeClass);
												owlReqIFIndividual.addProperty(objectProReqIFOwnSpecRelationType, owlSpecRelationTypeIndividual);// 绑定到该ReqIF实例
											}
										}

									}

									// 读取ReqIF的RELATION-GROUP-TYPE并生成
									else if (specTypesChild.getName().equals("RELATION-GROUP-TYPE")) {
										String identifier = specTypesChild.attribute("IDENTIFIER").getValue();
										String lastChange = specTypesChild.attribute("LAST-CHANGE").getValue();

										OntClass owlRelationGroupTypeClass = ontModel.createClass(METAG + identifier);
										owlSpec_Relation_GrouphasTypeClass.addSubClass(owlRelationGroupTypeClass);
										owlRelationGroupTypeClass.addProperty(annotationProIdentifier, identifier);
										owlRelationGroupTypeClass.addProperty(annotationProLast_Change, lastChange);
										if (specTypesChild.attribute("LONG-NAME") != null) {
											String longName = specTypesChild.attribute("LONG-NAME").getValue();
											owlRelationGroupTypeClass.addProperty(annotationProLong_Name, longName);
										}

										if (specTypesChild.element("SPEC-ATTRIBUTES") != null) {
											owlRelationGroupTypeClass.addProperty(annotationProSpecAttributesStructure, "hasStructure_SPEC-ATTRIBUTES");
											// 读取RELATION-GROUP-TYPE的SPEC-ATTRIBUTES并生成
											Element specAttributes = specTypesChild.element("SPEC-ATTRIBUTES");
											for (Iterator<Element> it2 = specAttributes.elementIterator(); it2.hasNext();) {
												Element specAttributeChild = it2.next();

												String identifier2 = specAttributeChild.attribute("IDENTIFIER").getValue();
												String lastChange2 = specAttributeChild.attribute("LAST-CHANGE").getValue();

												OntClass owlspecAttributeClass = ontModel.createClass(METAG + identifier2);
												String attributTypesName = specAttributeChild.getName();
												String[] strs = attributTypesName.split("-");
												if (strs[2].equals("STRING")) {
													owlAttribute_DefinitionStringClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("REAL")) {
													owlAttribute_DefinitionRealClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("INTEGER")) {
													owlAttribute_DefinitionIntegerClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("ENUMERATION")) {
													owlAttribute_DefinitionEnumerationClass
															.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("DATE")) {
													owlAttribute_DefinitionDateClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("BOOLEAN")) {
													owlAttribute_DefinitionBooleanClass.addSubClass(owlspecAttributeClass);
												}
												if (strs[2].equals("XHTML")) {
													owlAttribute_DefinitionXHTMLClass.addSubClass(owlspecAttributeClass);
												}

												owlspecAttributeClass.addProperty(annotationProIdentifier, identifier2);
												owlspecAttributeClass.addProperty(annotationProLast_Change, lastChange2);
												if (specAttributeChild.attribute("DESC") != null) {
													String desc2 = specAttributeChild.attribute("DESC").getValue();
													owlspecAttributeClass.addProperty(annotationProDesc, desc2);
												}
												if (specAttributeChild.attribute("LONG-NAME") != null) {
													String longName2 = specAttributeChild.attribute("LONG-NAME").getValue();
													owlspecAttributeClass.addProperty(annotationProLong_Name, longName2);
												}
												if (specAttributeChild.element("TYPE") != null) {
													// 读取SPEC-ATTRIBUTES引用的数据类型并生成
													Element attributeDefinitionType = specAttributeChild.element("TYPE");
													List<Element> type = attributeDefinitionType.elements();
													if (type.size() != 0) {
														Element dataTypeDefinitionType = type.get(0);
														String dataTypeDefinitionTypeID = dataTypeDefinitionType.getText();
														OntClass owlDatatypeRefClass = ontModel
																.getOntClass(METAG + dataTypeDefinitionTypeID);
														SomeValuesFromRestriction sometype = ontModel
																.createSomeValuesFromRestriction(null, objectProAttributeDefinition_Ref_DataType,
																		owlDatatypeRefClass);
														owlspecAttributeClass.addEquivalentClass(sometype);
													}
												}

												if (specAttributeChild.element("DEFAULT-VALUE") != null) {
													// 读取DEFAULT-VALUE
													Element defaultValue = specAttributeChild.element("DEFAULT-VALUE");
													for (Iterator<Element> it3 = defaultValue.elementIterator(); it3
															.hasNext();) {
														Element attributeValueType = it3.next();
														if (attributeValueType.attribute("THE-VALUE") != null) {
															String theValue = attributeValueType.attribute("THE-VALUE")
																	.getValue();
															Element definition = attributeValueType.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
																Element attributeDefinitionTypeRef = type.get(0);
//																String attributeDefinitionTypeRefID = attributeDefinitionTypeRef.getText();

//																OntClass owlattributeDefinitionTypeRefClass = ontModel
//																		.getOntClass(METAG + attributeDefinitionTypeRefID);//就是owlspecAttributeClass
																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
														} else {
															// 枚举型
															if (strs[2].equals("ENUMERATION")) {
																Element definition = attributeValueType
																		.element("DEFINITION");
																Element attributionDefinitionEnum = definition
																		.element("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
																String theValue = attributionDefinitionEnum.getText();
																owlspecAttributeClass.addProperty(annotationProDefalutValue,
																		theValue);
															}
															// XHTML
															// 需要与最初工具验证
															if (attributeValueType.attribute("IS-SIMPLIFIED") != null) {
																String isSimplified = attributeValueType
																		.attribute("IS-SIMPLIFIED").getValue();
																owlspecAttributeClass.addProperty(annotationProIsSimplified, isSimplified);
																if (defaultValue.element("THE-ORIGINAL-VALUE") != null) {
																	Element theOriginValue = defaultValue
																			.element("THE-ORIGINAL-VALUE");
																}
																if (defaultValue.element("THE-VALUE") != null) {
																	Element theValue = defaultValue.element("THE-VALUE");
																}
//																owlspecAttributeClass.addProperty(objectProHas_defalut_value,theValue);
															}
														}
													}
												}

												// 读取RELATION-GROUP-TYPE拥有属性SPEC-ATTRIBUTES并生成
												SomeValuesFromRestriction someattribute = ontModel
														.createSomeValuesFromRestriction(null, objectProRelationGroupType_has_AttributeDefinition,
																owlspecAttributeClass);
												owlRelationGroupTypeClass.addEquivalentClass(someattribute);
												//20231112
//												owlReqIFIndividual.addProperty(objectProReqIFOwnRelationGroupType, owlRelationGroupTypeClass);// 绑定到该ReqIF实例
												Individual owlRelationGroupTypeIndividual = ontModel.createIndividual(METAG + "0" + identifier,
														owlRelationGroupTypeClass);
												owlReqIFIndividual.addProperty(objectProReqIFOwnRelationGroupType, owlRelationGroupTypeIndividual);// 绑定到该ReqIF实例
											}
										}

									}
								}
							}
						} catch (NullPointerException npe) {
							npe.printStackTrace();
							System.out.println("Can not find!");
						}
						// 读取ReqIF的<SPEC-OBJECTS>并生成
						try {
							if (root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
									.element("SPEC-OBJECTS") != null) {
								owlReqIFIndividual.addProperty(annotationProSpecObjectsStructure, "hasStructure_SPEC-OBJECTS");
								Element specObjects = root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
										.element("SPEC-OBJECTS");
								for (Iterator<Element> it = specObjects.elementIterator(); it.hasNext();) {
									Element specObjectsChild = it.next();

									String identifier = specObjectsChild.attribute("IDENTIFIER").getValue();
									String lastChange = specObjectsChild.attribute("LAST-CHANGE").getValue();

									// 创建Spec_Object_hasType子类的实例
									if (specObjectsChild.element("TYPE") != null) {
										Element specObjectType = specObjectsChild.element("TYPE")
												.element("SPEC-OBJECT-TYPE-REF");
										String rootclassID = specObjectType.getText();
										OntClass rootClass = ontModel.getOntClass(METAG + rootclassID);
										Individual specObjectIndividual = ontModel.createIndividual(METAG + identifier,
												rootClass);
										specObjectIndividual.addProperty(annotationProIdentifier, identifier);
										specObjectIndividual.addProperty(annotationProLast_Change, lastChange);
										specObjectIndividual.addProperty(annotationProSpecObjectType, rootclassID);
										if(specObjectsChild.attribute("DESC")!=null) {
											String desc = specObjectsChild.attribute("DESC").getValue();
											specObjectIndividual.addProperty(annotationProDesc, desc);
										}
										if(specObjectsChild.attribute("LONG-NAME")!=null) {
											String longName = specObjectsChild.attribute("LONG-NAME").getValue();
											specObjectIndividual.addProperty(annotationProLong_Name, longName);
										}
										// 创建ATTRIBUTE-DEFINITION子类的实例
										if (specObjectsChild.element("VALUES") != null) {
											specObjectIndividual.addProperty(annotationProValuesStructure, "hasStructure_VALUES");
											Element values = specObjectsChild.element("VALUES");
											for (Iterator<Element> it2 = values.elementIterator(); it2.hasNext();) {
												Element valuesChild = it2.next();
												if (valuesChild.attribute("THE-VALUE") != null) {
													String theValue = valuesChild.attribute("THE-VALUE").getValue();
													Element definition = valuesChild.element("DEFINITION");
													List<Element> type = definition.elements();
													if (type.size() != 0) {
														Element attributeDefinitionTypeRef = type.get(0);
														String attributeDefinitionClassID = attributeDefinitionTypeRef
																.getText();
														OntClass attributeDefinitionClass = ontModel
																.getOntClass(METAG + attributeDefinitionClassID);
														String theValueID = UUID.randomUUID().toString();
														Individual attributeDefinitionIndividual = ontModel
																.createIndividual(METAG + theValueID,
																		attributeDefinitionClass);
														attributeDefinitionIndividual.addProperty(annotationProTheValue,
																theValue);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														String[] strs = valuesChild.getName().split("-");
														attributeDefinitionIndividual.addProperty(annotationProMark,
																strs[2]);//便于读取
														// 创建Spec_Object_hasType子类实例拥有ATTRIBUTE-DEFINITION子类实例的关系
														specObjectIndividual.addProperty(objectProSpecObject_has_AttributeDefinition,
																attributeDefinitionIndividual);
													}
												} else {
													// ATTRIBUTE-VALUE-ENUMERATION
													if (valuesChild.element("VALUES") != null) {
														Element enumValues = valuesChild.element("VALUES");
														for (Iterator<Element> it3 = enumValues.elementIterator(); it3
																.hasNext();) {
															Element enumValueRef = it3.next();
															String enumValueRefID = enumValueRef.getText();
															OntClass enumValueRefClass = ontModel
																	.getOntClass(METAG + enumValueRefID);
//															String enumValue;
//															if(enumValueRefClass.getPropertyValue(annotationProLong_Name) != null) {
//																enumValue = enumValueRefClass.getPropertyValue(annotationProLong_Name).toString();
//															}
//															else {
//																enumValue = enumValueRefID;
//															}
															Element definition = valuesChild.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
																Element attributeDefinitionTypeRef = type.get(0);
																String attributeDefinitionClassID = attributeDefinitionTypeRef
																		.getText();
																OntClass attributeDefinitionClass = ontModel
																		.getOntClass(
																				METAG + attributeDefinitionClassID);
//																String enumValueID = UUID.randomUUID().toString();
//																Individual attributeDefinitionIndividual = ontModel
//																		.createIndividual(METAG + enumValueID, attributeDefinitionClass);
//																attributeDefinitionIndividual.addProperty(annotationProEnumValue, enumValue);
																// 注释部分为另一种方法
																//20231112class和class之间添加关系
//																attributeDefinitionClass.addProperty(objectProSpecObject_Ref_EnumValue,
//																		enumValueRefClass);
//																specObjectIndividual.addProperty(objectProSpecObject_Ref_EnumAttributeDefinition,
//																		attributeDefinitionClass);
																attributeDefinitionClass.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
																		objectProSpecObject_Ref_EnumValue, enumValueRefClass));
																Individual attributeDefinitionIndividual = ontModel.createIndividual(METAG + "0" + attributeDefinitionClassID,
																		attributeDefinitionClass);
																specObjectIndividual.addProperty(objectProSpecObject_Ref_EnumAttributeDefinition,
																		attributeDefinitionIndividual);
															}
														}

													}
													// ATTRIBUTE-VALUE-XHTML
													if (valuesChild.element("THE-VALUE") != null) {
														Element xhtmlDiv = valuesChild.element("THE-VALUE")
																.element("div");
														String xhtmlDivValue = xhtmlDiv.getText();
														Element definition = valuesChild.element("DEFINITION");
														Element definitionXHTML = definition
																.element("ATTRIBUTE-DEFINITION-XHTML-REF");
														String attributeDefinitionClassID = definitionXHTML.getText();
														OntClass attributeDefinitionClass = ontModel
																.getOntClass(METAG + attributeDefinitionClassID);
														String theValueID = UUID.randomUUID().toString();
														Individual attributeDefinitionIndividual = ontModel
																.createIndividual(METAG + theValueID,
																		attributeDefinitionClass);
														attributeDefinitionIndividual.addProperty(annotationProXHTMLDiv,
																xhtmlDivValue);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														String[] strs = valuesChild.getName().split("-");
														attributeDefinitionIndividual.addProperty(annotationProMark,
																strs[2]);//便于读取
														// 创建Spec_Object_hasType子类实例拥有ATTRIBUTE-DEFINITION子类实例的关系
														specObjectIndividual.addProperty(objectProSpecObject_has_AttributeDefinition,
																attributeDefinitionIndividual);
													}
												}

											}
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnSpecObject, specObjectIndividual);// 绑定到该ReqIF实例
									}
									// 创建Spec_Object_doesn'tHaveType的实例
									else {
										Individual specObjectdoesntHaveTypeIndividual = ontModel.createIndividual(
												METAG + identifier, owlSpec_Object_doesntHaveTypeClass);
										specObjectdoesntHaveTypeIndividual.addProperty(annotationProIdentifier,
												identifier);
										specObjectdoesntHaveTypeIndividual.addProperty(annotationProLast_Change,
												lastChange);
										if(specObjectsChild.attribute("DESC")!=null) {
											String desc = specObjectsChild.attribute("DESC").getValue();
											specObjectdoesntHaveTypeIndividual.addProperty(annotationProDesc, desc);
										}
										if(specObjectsChild.attribute("LONG-NAME")!=null) {
											String longName = specObjectsChild.attribute("LONG-NAME").getValue();
											specObjectdoesntHaveTypeIndividual.addProperty(annotationProLong_Name, longName);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnSpecObject,
												specObjectdoesntHaveTypeIndividual);// 绑定到该ReqIF实例
									}

								}

							}
						} catch (NullPointerException npe) {
							System.out.println("Can not find!");
							npe.printStackTrace();
						}
						// 读取ReqIF的<SPEC-RELATIONS>并生成
						try {
							if (root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
									.element("SPEC-RELATIONS") != null) {
								owlReqIFIndividual.addProperty(annotationProSpecRelationsStructure, "hasStructure_SPEC-RELATIONS");
								Element specRelations = root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
										.element("SPEC-RELATIONS");
								for (Iterator<Element> it = specRelations.elementIterator(); it.hasNext();) {
									Element specRelationsChild = it.next();

									String identifier = specRelationsChild.attribute("IDENTIFIER").getValue();
									String lastChange = specRelationsChild.attribute("LAST-CHANGE").getValue();

									// 创建Spec_Relation_hasType子类的实例
									if (specRelationsChild.element("TYPE") != null) {
										Element specRelationType = specRelationsChild.element("TYPE")
												.element("SPEC-RELATION-TYPE-REF");
										String specRelationClassID = specRelationType.getText();
										OntClass specRelationClass = ontModel.getOntClass(METAG + specRelationClassID);
										Individual specRelationIndividual = ontModel
												.createIndividual(METAG + identifier, specRelationClass);
										specRelationIndividual.addProperty(annotationProIdentifier, identifier);
										specRelationIndividual.addProperty(annotationProLast_Change, lastChange);
										specRelationIndividual.addProperty(annotationProSpecRelationType, specRelationClassID);
										if(specRelationsChild.attribute("DESC")!=null) {
											String desc = specRelationsChild.attribute("DESC").getValue();
											specRelationIndividual.addProperty(annotationProDesc, desc);
										}
										if(specRelationsChild.attribute("LONG-NAME")!=null) {
											String longName = specRelationsChild.attribute("LONG-NAME").getValue();
											specRelationIndividual.addProperty(annotationProLong_Name, longName);
										}
										if (specRelationsChild.element("VALUES") != null) {
											specRelationIndividual.addProperty(annotationProValuesStructure, "hasStructure_VALUES");
											// 创建ATTRIBUTE-DEFINITION子类的实例
											Element values = specRelationsChild.element("VALUES");
											for (Iterator<Element> it2 = values.elementIterator(); it2.hasNext();) {
												Element valuesChild = it2.next();
												if (valuesChild.attribute("THE-VALUE") != null) {
													String theValue = valuesChild.attribute("THE-VALUE").getValue();
													Element definition = valuesChild.element("DEFINITION");
													List<Element> type = definition.elements();
													if (type.size() != 0) {
														Element attributeDefinitionTypeRef = type.get(0);
														String attributeDefinitionClassID = attributeDefinitionTypeRef
																.getText();
														OntClass attributeDefinitionClass = ontModel
																.getOntClass(METAG + attributeDefinitionClassID);
														String theValueID = UUID.randomUUID().toString();
														Individual attributeDefinitionIndividual = ontModel
																.createIndividual(METAG + theValueID,
																		attributeDefinitionClass);
														attributeDefinitionIndividual.addProperty(annotationProTheValue,
																theValue);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														String[] strs = valuesChild.getName().split("-");
														attributeDefinitionIndividual.addProperty(annotationProMark,
																strs[2]);//便于读取
														// 创建Spec_Relation_hasType子类实例拥有ATTRIBUTE-DEFINITION子类实例的关系
														specRelationIndividual.addProperty(objectProSpecRelation_has_AttributeDefinition,
																attributeDefinitionIndividual);
													}
												} else {
													// ATTRIBUTE-VALUE-ENUMERATION
													if (valuesChild.element("VALUES") != null) {
														Element enumValues = valuesChild.element("VALUES");
														for (Iterator<Element> it3 = enumValues.elementIterator(); it3
																.hasNext();) {
															Element enumValueRef = it3.next();
															String enumValueRefID = enumValueRef.getText();
															OntClass enumValueRefClass = ontModel
																	.getOntClass(METAG + enumValueRefID);
															Element definition = valuesChild.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
																Element attributeDefinitionTypeRef = type.get(0);
																String attributeDefinitionClassID = attributeDefinitionTypeRef
																		.getText();
																OntClass attributeDefinitionClass = ontModel
																		.getOntClass(
																				METAG + attributeDefinitionClassID);
																//20231112class和class之间添加关系
//																attributeDefinitionClass.addProperty(objectProSpecRelation_Ref_EnumValue,
//																		enumValueRefClass);
//																specRelationIndividual.addProperty(objectProSpecRelation_Ref_EnumAttributeDefinition,
//																		attributeDefinitionClass);
																attributeDefinitionClass.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
																		objectProSpecRelation_Ref_EnumValue, enumValueRefClass));
																Individual attributeDefinitionIndividual = ontModel.createIndividual(METAG + "0" + attributeDefinitionClassID,
																		attributeDefinitionClass);
																specRelationIndividual.addProperty(objectProSpecRelation_Ref_EnumAttributeDefinition,
																		attributeDefinitionIndividual);
															}
														}

													}
													// ATTRIBUTE-VALUE-XHTML
													if (valuesChild.element("THE-VALUE") != null) {
														Element xhtmlDiv = valuesChild.element("THE-VALUE")
																.element("div");
														String xhtmlDivValue = xhtmlDiv.getText();
														Element definition = valuesChild.element("DEFINITION");
														Element definitionXHTML = definition
																.element("ATTRIBUTE-DEFINITION-XHTML-REF");
														String attributeDefinitionClassID = definitionXHTML.getText();
														OntClass attributeDefinitionClass = ontModel
																.getOntClass(METAG + attributeDefinitionClassID);
														String theValueID = UUID.randomUUID().toString();
														Individual attributeDefinitionIndividual = ontModel
																.createIndividual(METAG + theValueID,
																		attributeDefinitionClass);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														String[] strs = valuesChild.getName().split("-");
														attributeDefinitionIndividual.addProperty(annotationProMark,
																strs[2]);//便于读取
														attributeDefinitionIndividual.addProperty(annotationProXHTMLDiv,
																xhtmlDivValue);
														// 创建Spec_Relation_hasType子类实例拥有ATTRIBUTE-DEFINITION子类实例的关系
														specRelationIndividual.addProperty(objectProSpecRelation_has_AttributeDefinition,
																attributeDefinitionIndividual);
													}
												}

											}
										}

										// 创建Spec_Relation_hasType子类实例关联的源和目标实例关系
										if (specRelationsChild.element("TARGET") != null) {
											Element Target = specRelationsChild.element("TARGET");
											String targetInstance = Target.element("SPEC-OBJECT-REF").getText();
											Individual targetIndividual = ontModel
													.getIndividual(METAG + targetInstance);
											specRelationIndividual.addProperty(objectProSpecRelation_targetRef_SpecObject, targetIndividual);
										}

										if (specRelationsChild.element("SOURCE") != null) {
											Element Source = specRelationsChild.element("SOURCE");
											String sourceInstance = Source.element("SPEC-OBJECT-REF").getText();
											Individual sourceIndividual = ontModel
													.getIndividual(METAG + sourceInstance);
											specRelationIndividual.addProperty(objectProSpecRelation_sourceRef_SpecObject, sourceIndividual);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnSpecRelation, specRelationIndividual);// 绑定到该ReqIF实例
									}
									// 创建Spec_Relation_doesn’tHaveType的实例
									else {
										Individual specRelation_doesntHaveTypeIndividual = ontModel.createIndividual(
												METAG + identifier, owlSpec_Relation_doesntHaveTypeClass);
										specRelation_doesntHaveTypeIndividual.addProperty(annotationProIdentifier,
												identifier);
										specRelation_doesntHaveTypeIndividual.addProperty(annotationProLast_Change,
												lastChange);
										if(specRelationsChild.attribute("DESC")!=null) {
											String desc = specRelationsChild.attribute("DESC").getValue();
											specRelation_doesntHaveTypeIndividual.addProperty(annotationProDesc, desc);
										}
										if(specRelationsChild.attribute("LONG-NAME")!=null) {
											String longName = specRelationsChild.attribute("LONG-NAME").getValue();
											specRelation_doesntHaveTypeIndividual.addProperty(annotationProLong_Name, longName);
										}
										// 创建Spec_Relation_doesn’tHaveType实例关联的源和目标实例关系
										if (specRelationsChild.element("TARGET") != null) {
											Element Target = specRelationsChild.element("TARGET");
											String targetInstance = Target.element("SPEC-OBJECT-REF").getText();
											Individual targetIndividual = ontModel
													.getIndividual(METAG + targetInstance);
											specRelation_doesntHaveTypeIndividual.addProperty(objectProSpecRelation_targetRef_SpecObject,
													targetIndividual);
										}

										if (specRelationsChild.element("SOURCE") != null) {
											Element Source = specRelationsChild.element("SOURCE");
											String sourceInstance = Source.element("SPEC-OBJECT-REF").getText();
											Individual sourceIndividual = ontModel
													.getIndividual(METAG + sourceInstance);
											specRelation_doesntHaveTypeIndividual.addProperty(objectProSpecRelation_sourceRef_SpecObject,
													sourceIndividual);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnSpecRelation,
												specRelation_doesntHaveTypeIndividual);// 绑定到该ReqIF实例
									}
								}
							}
						} catch (NullPointerException npe) {
							System.out.println("Can not find!");
							npe.printStackTrace();
						}

						// 读取ReqIF的<SPECIFICATIONS>并生成
						try {
							if (root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
									.element("SPECIFICATIONS") != null) {
								owlReqIFIndividual.addProperty(annotationProSpecificationsStructure, "hasStructure_SPECIFICATIONS");
								Element Specifications = root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
										.element("SPECIFICATIONS");
								for (Iterator<Element> it = Specifications.elementIterator(); it.hasNext();) {
									Element specificationsChild = it.next();

									String identifier = specificationsChild.attribute("IDENTIFIER").getValue();
									String lastChange = specificationsChild.attribute("LAST-CHANGE").getValue();

									// 创建Specification_hasType子类的实例
									if (specificationsChild.element("TYPE") != null) {
										Element specificationType = specificationsChild.element("TYPE")
												.element("SPECIFICATION-TYPE-REF");
										String specificationTypeClassID = specificationType.getText();
										OntClass specificationTypeClass = ontModel
												.getOntClass(METAG + specificationTypeClassID);
										Individual specificationIndividual = ontModel
												.createIndividual(METAG + identifier, specificationTypeClass);
										specificationIndividual.addProperty(annotationProIdentifier, identifier);
										specificationIndividual.addProperty(annotationProLast_Change, lastChange);
										specificationIndividual.addProperty(annotationProSpecificationType, specificationTypeClassID);
										if (specificationsChild.attribute("LONG-NAME") != null) {
											String longName = specificationsChild.attribute("LONG-NAME").getValue();
											specificationIndividual.addProperty(annotationProLong_Name, longName);
										}
										if (specificationsChild.attribute("Desc") != null) {
											String desc = specificationsChild.attribute("Desc").getValue();
											specificationIndividual.addProperty(annotationProDesc, desc);
										}
										if (specificationsChild.element("VALUES") != null) {
											specificationIndividual.addProperty(annotationProValuesStructure, "hasStructure_VALUES");
											// 创建ATTRIBUTE-DEFINITION子类的实例
											Element values = specificationsChild.element("VALUES");
											for (Iterator<Element> it2 = values.elementIterator(); it2.hasNext();) {
												Element valuesChild = it2.next();
												if (valuesChild.attribute("THE-VALUE") != null) {
													String theValue = valuesChild.attribute("THE-VALUE").getValue();
													Element definition = valuesChild.element("DEFINITION");
													List<Element> type = definition.elements();
													if (type.size() != 0) {
														Element attributeDefinitionTypeRef = type.get(0);
														String attributeDefinitionClassID = attributeDefinitionTypeRef
																.getText();
														OntClass attributeDefinitionClass = ontModel
																.getOntClass(METAG + attributeDefinitionClassID);
														String theValueID = UUID.randomUUID().toString();
														Individual attributeDefinitionIndividual = ontModel
																.createIndividual(METAG + theValueID,
																		attributeDefinitionClass);
														attributeDefinitionIndividual.addProperty(annotationProTheValue,
																theValue);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														String[] strs = valuesChild.getName().split("-");
														attributeDefinitionIndividual.addProperty(annotationProMark,
																strs[2]);//便于读取
														// 创建Specification_hasType子类实例拥有ATTRIBUTE-DEFINITION子类实例的关系
														specificationIndividual.addProperty(objectProSpecification_has_AttributeDefinition,
																attributeDefinitionIndividual);
													}
												} else {
													// ATTRIBUTE-VALUE-ENUMERATION
													if (valuesChild.element("VALUES") != null) {
														Element enumValues = valuesChild.element("VALUES");
														for (Iterator<Element> it3 = enumValues.elementIterator(); it3
																.hasNext();) {
															Element enumValueRef = it3.next();
															String enumValueRefID = enumValueRef.getText();
															OntClass enumValueRefClass = ontModel
																	.getOntClass(METAG + enumValueRefID);
															Element definition = valuesChild.element("DEFINITION");
															List<Element> type = definition.elements();
															if (type.size() != 0) {
																Element attributeDefinitionTypeRef = type.get(0);
																String attributeDefinitionClassID = attributeDefinitionTypeRef
																		.getText();
																OntClass attributeDefinitionClass = ontModel
																		.getOntClass(
																				METAG + attributeDefinitionClassID);
																//20231112class和class之间添加关系
//																attributeDefinitionClass.addProperty(objectProSpecification_Ref_EnumValue,
//																		enumValueRefClass);
//																specificationIndividual.addProperty(objectProSpecification_Ref_EnumAttributeDefinition,
//																		attributeDefinitionClass);
																attributeDefinitionClass.addEquivalentClass(ontModel.createSomeValuesFromRestriction(null,
																		objectProSpecification_Ref_EnumValue, enumValueRefClass));
																Individual attributeDefinitionIndividual = ontModel.createIndividual(METAG + "0" + attributeDefinitionClassID,
																		attributeDefinitionClass);
																specificationIndividual.addProperty(objectProSpecification_Ref_EnumAttributeDefinition,
																		attributeDefinitionIndividual);
															}
														}

													}
													// ATTRIBUTE-VALUE-XHTML
													if (valuesChild.element("THE-VALUE") != null) {
														Element xhtmlDiv = valuesChild.element("THE-VALUE")
																.element("div");
														String xhtmlDivValue = xhtmlDiv.getText();
														Element definition = valuesChild.element("DEFINITION");
														Element definitionXHTML = definition
																.element("ATTRIBUTE-DEFINITION-XHTML-REF");
														String attributeDefinitionClassID = definitionXHTML.getText();
														OntClass attributeDefinitionClass = ontModel
																.getOntClass(METAG + attributeDefinitionClassID);
														String theValueID = UUID.randomUUID().toString();
														Individual attributeDefinitionIndividual = ontModel
																.createIndividual(METAG + theValueID,
																		attributeDefinitionClass);
														attributeDefinitionIndividual.addProperty(annotationProXHTMLDiv,
																xhtmlDivValue);
														attributeDefinitionIndividual.addProperty(annotationProAttributeDefinitionType,
																attributeDefinitionClassID);
														String[] strs = valuesChild.getName().split("-");
														attributeDefinitionIndividual.addProperty(annotationProMark,
																strs[2]);//便于读取
														// 创建Specification_hasType子类实例拥有ATTRIBUTE-DEFINITION子类实例的关系
														specificationIndividual.addProperty(objectProSpecification_has_AttributeDefinition,
																attributeDefinitionIndividual);
													}
												}

											}
										}
										if (specificationsChild.element("CHILDREN") != null) {
											specificationIndividual.addProperty(annotationProChildrenStructure,"hasStructure_CHILDREN");
											// 创建Spec_Hierarchy的实例
											generateChildren(specificationsChild, ontModel, specificationIndividual, owlReqIFIndividual);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnSpecification, specificationIndividual);// 绑定到该ReqIF实例
									}
									// 创建Specification_doesn'tHaveType的实例
									else {
										Individual specification_doesntHaveTypeIndividual = ontModel.createIndividual(
												METAG + identifier, owlSpecification_doesntHaveTypeClass);
										specification_doesntHaveTypeIndividual.addProperty(annotationProIdentifier,
												identifier);
										specification_doesntHaveTypeIndividual.addProperty(annotationProLast_Change,
												lastChange);
										if (specificationsChild.attribute("LONG-NAME") != null) {
											String longName = specificationsChild.attribute("LONG-NAME").getValue();
											specification_doesntHaveTypeIndividual.addProperty(annotationProLong_Name, longName);
										}
										if (specificationsChild.attribute("Desc") != null) {
											String desc = specificationsChild.attribute("Desc").getValue();
											specification_doesntHaveTypeIndividual.addProperty(annotationProDesc, desc);
										}
										if (specificationsChild.element("CHILDREN") != null) {
											specification_doesntHaveTypeIndividual.addProperty(annotationProChildrenStructure,"hasStructure_CHILDREN");
											// 创建Spec_Hierarchy的实例
											generateChildren(specificationsChild, ontModel, specification_doesntHaveTypeIndividual,owlReqIFIndividual);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnSpecification,
												specification_doesntHaveTypeIndividual);// 绑定到该ReqIF实例
									}
								}
							}

						} catch (NullPointerException npe) {
							System.out.println("Can not find!");
							npe.printStackTrace();
						}
						// 读取ReqIF的<SPEC-RELATION-GROUPS>并生成
						try {
							if (root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
									.element("SPEC-RELATION-GROUPS") != null) {
								owlReqIFIndividual.addProperty(annotationProSpecRelationGroupStructure, "hasStructure_ SPEC-RELATION-GROUPS");
								owlReqIFIndividual.addProperty(annotationProSpecificationsStructure, "hasStructure_SPECIFICATIONS");
								Element specRelationGroups = root.element("CORE-CONTENT").element("REQ-IF-CONTENT")
										.element("SPEC-RELATION-GROUPS");
								for (Iterator<Element> it = specRelationGroups.elementIterator(); it.hasNext();) {
									Element relationGroup = it.next();

									String identifier = relationGroup.attribute("IDENTIFIER").getValue();
									String lastChange = relationGroup.attribute("LAST-CHANGE").getValue();
									
									// 创建Spec_Relation_Group_hasType子类的实例
									if (relationGroup.element("TYPE") != null) {
										Element relationGroupType = relationGroup.element("TYPE")
												.element("RELATION-GROUP-TYPE-REF");
										String relationGroupClassID = relationGroupType.getText();
										OntClass relationGroupClass = ontModel.getOntClass(METAG + relationGroupClassID);
										Individual relationGroupIndividual = ontModel
												.createIndividual(METAG + identifier, relationGroupClass);
										relationGroupIndividual.addProperty(annotationProIdentifier, identifier);
										relationGroupIndividual.addProperty(annotationProLast_Change, lastChange);
										relationGroupIndividual.addProperty(annotationProRelationGroupType, relationGroupClassID);
										if(relationGroup.attribute("DESC")!=null) {
											String desc = relationGroup.attribute("DESC").getValue();
											relationGroupIndividual.addProperty(annotationProDesc, desc);
										}
										if(relationGroup.attribute("LONG-NAME")!=null) {
											String longName = relationGroup.attribute("LONG-NAME").getValue();
											relationGroupIndividual.addProperty(annotationProLong_Name, longName);
										}
										if (relationGroup.element("SPEC-RELATIONS") != null) {
											Element specRelations = relationGroup.element("SPEC-RELATIONS");
											for (Iterator<Element> it2 = specRelations.elementIterator(); it2.hasNext();) {
												Element specRelationRef = it2.next();
												String specRelationID = specRelationRef.getText();
												Individual specRelationIndividual = ontModel.getIndividual(METAG + specRelationID);
												relationGroupIndividual.addProperty(objectProRelationGoup_Ref_SpecRelation, specRelationIndividual);
											}
										}
										if (relationGroup.element("SOURCE-SPECIFICATION") != null) {
											Element specificationRef = relationGroup.element("SOURCE-SPECIFICATION").element("SPECIFICATION-REF");
											String specificationID = specificationRef.getText();
											Individual specificationIndividual = ontModel.getIndividual(METAG + specificationID);
											relationGroupIndividual.addProperty(objectProRelationGoup_sourceRef_Specification, specificationIndividual);
										}
										if (relationGroup.element("TARGET-SPECIFICATION") != null) {
											Element specificationRef = relationGroup.element("TARGET-SPECIFICATION").element("SPECIFICATION-REF");
											String specificationID = specificationRef.getText();
											Individual specificationIndividual = ontModel.getIndividual(METAG + specificationID);
											relationGroupIndividual.addProperty(objectProRelationGoup_targetRef_Specification, specificationIndividual);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnRelationGroup, relationGroupIndividual);// 绑定到该ReqIF实例
									}
									// 创建Spec_Relation_Group_doesn’tHaveType的实例
									else {
										Individual relationGroup_doesntHaveTypeIndividual = ontModel.createIndividual(
												METAG + identifier, owlSpec_Relation_Group_doesntHaveTypeClass);
										relationGroup_doesntHaveTypeIndividual.addProperty(annotationProIdentifier,
												identifier);
										relationGroup_doesntHaveTypeIndividual.addProperty(annotationProLast_Change,
												lastChange);
										if(relationGroup.attribute("DESC")!=null) {
											String desc = relationGroup.attribute("DESC").getValue();
											relationGroup_doesntHaveTypeIndividual.addProperty(annotationProDesc, desc);
										}
										if(relationGroup.attribute("LONG-NAME")!=null) {
											String longName = relationGroup.attribute("LONG-NAME").getValue();
											relationGroup_doesntHaveTypeIndividual.addProperty(annotationProLong_Name, longName);
										}
										if (relationGroup.element("SPEC-RELATIONS") != null) {
											Element specRelations = relationGroup.element("SPEC-RELATIONS");
											for (Iterator<Element> it2 = specRelations.elementIterator(); it2.hasNext();) {
												Element specRelationRef = it2.next();
												String specRelationID = specRelationRef.getText();
												Individual specRelationIndividual = ontModel.getIndividual(METAG + specRelationID);
												relationGroup_doesntHaveTypeIndividual.addProperty(objectProRelationGoup_Ref_SpecRelation, specRelationIndividual);
											}
										}
										if (relationGroup.element("SOURCE-SPECIFICATION") != null) {
											Element specificationRef = relationGroup.element("SOURCE-SPECIFICATION").element("SPECIFICATION-REF");
											String specificationID = specificationRef.getText();
											Individual specificationIndividual = ontModel.getIndividual(METAG + specificationID);
											relationGroup_doesntHaveTypeIndividual.addProperty(objectProRelationGoup_sourceRef_Specification, specificationIndividual);
										}
										if (relationGroup.element("TARGET-SPECIFICATION") != null) {
											Element specificationRef = relationGroup.element("TARGET-SPECIFICATION").element("SPECIFICATION-REF");
											String specificationID = specificationRef.getText();
											Individual specificationIndividual = ontModel.getIndividual(METAG + specificationID);
											relationGroup_doesntHaveTypeIndividual.addProperty(objectProRelationGoup_targetRef_Specification, specificationIndividual);
										}
										owlReqIFIndividual.addProperty(objectProReqIFOwnRelationGroup, relationGroup_doesntHaveTypeIndividual);// 绑定到该ReqIF实例
									}
								}
							}
						} catch (NullPointerException npe) {
							System.out.println("Can not find!");
							npe.printStackTrace();
						}
						// 生成Annotation Properties即进行Configuration
						// configuration:specViewConfigurations
						try {
							Element REQIFTOOLEXTENSION = root.element("TOOL-EXTENSIONS")
									.element("REQ-IF-TOOL-EXTENSION");
							Namespace namespace = Namespace.get("http://eclipse.org/rmf/pror/toolextensions/1.0");
							Element prorToolExtension = REQIFTOOLEXTENSION
									.element(QName.get("ProrToolExtension", namespace));
							for (Iterator<Element> it = prorToolExtension.elementIterator(); it.hasNext();) {
								Element configurationType = it.next();
								// specViewConfigurations
								if (configurationType.getName().equals("specViewConfigurations")) {
									Element specViewConfigurations = configurationType;
									for (Iterator<Element> it2 = specViewConfigurations.elementIterator(); it2
											.hasNext();) {
										Element ProrSpecViewConfiguration = it2.next();
										//20231020可能存在reqifProrSpecViewConfiguration.attribute("specification")没有的冗余情况
										if(ProrSpecViewConfiguration.attribute("specification")!=null) {
											String specificationID = ProrSpecViewConfiguration.attribute("specification")
													.getValue();
											Individual specificationIndividual = ontModel
													.getIndividual(METAG + specificationID);
											for (Iterator<Element> it3 = ProrSpecViewConfiguration.elementIterator(); it3
													.hasNext();) {
												Element columnType = it3.next();
												if (columnType.getName().equals("columns")) {
													Element columns = columnType;
													int s = 1;
													for (Iterator<Element> it4 = columns.elementIterator(); it4
															.hasNext(); s++) {
														Element column = it4.next();
														String columnID = UUID.randomUUID().toString();
														Individual columnIndividual = null;
														if (column.getName().equals("UnifiedColumn")) {
															columnIndividual = ontModel.createIndividual(METAG + columnID,
																	owlUnifiedColumnClass);
															columnIndividual.addProperty(annotationProMark, "UnifiedColumn");
														} else {
															columnIndividual = ontModel.createIndividual(METAG + columnID,
																	owlColumnClass);
														}
														if (column.attributeValue("label") != null) {
															String label = column.attributeValue("label");
															columnIndividual.addProperty(annotationProLabel, label);
														}
														if (column.attributeValue("width") != null) {
															String width = column.attributeValue("width");
															columnIndividual.addProperty(annotationProWidth, width);
														}
														String se = String.valueOf(s);
														columnIndividual.addProperty(annotationProSequence,se);
														specificationIndividual.addProperty(objectProSpecification_has_Column, columnIndividual);// 绑定
													}
												} else {
													Element leftHeaderColumn = columnType;
													Element column = leftHeaderColumn
															.element(QName.get("Column", namespace));
													String columnID = UUID.randomUUID().toString();
													Individual columnIndividual = ontModel
															.createIndividual(METAG + columnID, owlLeftHeaderColumnClass);
													String label = column.attributeValue("label");
													columnIndividual.addProperty(annotationProLabel, label);
													columnIndividual.addProperty(annotationProMark, "leftHeaderColumn");
													if (column.attributeValue("width") != null) {
														String width = column.attributeValue("width");
														columnIndividual.addProperty(annotationProWidth, width);
													}
													specificationIndividual.addProperty(objectProSpecification_has_Column, columnIndividual);// 绑定
												}
											}
										}
									}
								}
								// generalConfiguration
								if (configurationType.getName().equals("generalConfiguration")) {
									Element generalConfiguration = configurationType;
									Element labelConfiguration = generalConfiguration
											.element(QName.get("ProrGeneralConfiguration", namespace))
											.element(QName.get("labelConfiguration", namespace))
											.element(QName.get("LabelConfiguration", namespace));
									int s = 1;
									for (Iterator<Element> it2 = labelConfiguration.elementIterator(); it2.hasNext();s++) {
										Element defaultLabel = it2.next();
										String defaultLabelValue = defaultLabel.getText();
										String defaultLabelID = UUID.randomUUID().toString();
										Individual defaultLabelIndividual = ontModel
												.createIndividual(METAG + defaultLabelID, owlLabelConfigurationClass);
										defaultLabelIndividual.addProperty(annotationProDefalutLabel,
												defaultLabelValue);
										String se = String.valueOf(s);
										defaultLabelIndividual.addProperty(annotationProSequence,se);
										owlReqIFIndividual.addProperty(objectProReqIFOwnDefaultLabel, defaultLabelIndividual);// 绑定到该ReqIF实例
									}
								}
								// presentationConfigurations
								if (configurationType.getName().equals("presentationConfigurations")) {
									Element presentationConfigurations = configurationType;
									Element ProrPresentationConfigurations = presentationConfigurations
											.element(QName.get("ProrPresentationConfigurations", namespace));
									if (ProrPresentationConfigurations
											.element(QName.get("presentationConfigurations", namespace)) != null) {
										Element presentationConfigurationsIn = ProrPresentationConfigurations
												.element(QName.get("presentationConfigurations", namespace));
										for (Iterator<Element> it2 = presentationConfigurationsIn.elementIterator(); it2
												.hasNext();) {
											Element presentationType = it2.next();
											// LinewrapConfiguration
											if (presentationType.getName().equals("LinewrapConfiguration")) {
												Element linewrapConfiguration = presentationType;
												String linewrapConfigurationID = UUID.randomUUID().toString();
												Individual linewrapConfigurationIndividual = ontModel.createIndividual(
														METAG + linewrapConfigurationID, owLinewrapConfigurationClass);
												if (linewrapConfiguration.attributeValue("datatype") != null) {
													String datatype = linewrapConfiguration.attributeValue("datatype");
													OntClass datatypeClass = ontModel.getOntClass(METAG + datatype);
													//20231112individual和class之间创建关系
//													linewrapConfigurationIndividual.addProperty(objectProLinewrapConfiguration_Apply_DataType,
//															datatypeClass);
													Individual datatypeIndividual = ontModel.getIndividual(METAG + "0" + datatype);
													linewrapConfigurationIndividual.addProperty(objectProLinewrapConfiguration_Apply_DataType,
															datatypeIndividual);
													
												}
												owlReqIFIndividual.addProperty(objectProReqIFOwnLinewrapConfiguration, linewrapConfigurationIndividual);// 绑定到该ReqIF实例
											}
											// IdConfiguration
											if (presentationType.getName().equals("IdConfiguration")) {
												Element idConfiguration = presentationType;
												String idConfigurationID = UUID.randomUUID().toString();
												Individual idConfigurationIndividual = ontModel.createIndividual(
														METAG + idConfigurationID, owIdConfigurationClass);
												if (idConfiguration.attributeValue("prefix") != null) {
													String prefix = idConfiguration.attributeValue("prefix").toString();
													idConfigurationIndividual.addProperty(annotationProPrefix, prefix);
												}
												if (idConfiguration.attributeValue("datatype") != null) {
													String datatype = idConfiguration.attributeValue("datatype".toString());
													OntClass datatypeClass = ontModel.getOntClass(METAG + datatype);
													//20231112individual和class之间创建关系
//													idConfigurationIndividual.addProperty(objectProIdConfiguration_Apply_DataType,
//															datatypeClass);
													Individual datatypeIndividual = ontModel.getIndividual(METAG + "0" + datatype);
													idConfigurationIndividual.addProperty(objectProIdConfiguration_Apply_DataType,
															datatypeIndividual);
												}
												if (idConfiguration.attributeValue("count") != null) {
													String count = idConfiguration.attributeValue("count").toString();
													idConfigurationIndividual.addProperty(annotationProCount, count);
												}
												if (idConfiguration.attributeValue("verticalAlign") != null) {
													String verticalAlign = idConfiguration.attributeValue("verticalAlign").toString();
													idConfigurationIndividual.addProperty(annotationProVerticalAlign, verticalAlign);
												}
												owlReqIFIndividual.addProperty(objectProReqIFOwnIdConfiguration, idConfigurationIndividual);// 绑定到该ReqIF实例
											}
											// HeadlineConfiguration
											if (presentationType.getName().equals("HeadlineConfiguration")) {
												Element headlineConfiguration = presentationType;
												String headlineConfigurationID = UUID.randomUUID().toString();
												Individual headlineConfigurationIndividual = ontModel.createIndividual(
														METAG + headlineConfigurationID, owHeadlineConfigurationClass);
												if (headlineConfiguration.attributeValue("datatype") != null) {
													String datatype = headlineConfiguration.attributeValue("datatype").toString();
													OntClass datatypeClass = ontModel.getOntClass(METAG + datatype);
													//20231112individual和class之间创建关系
//													headlineConfigurationIndividual.addProperty(objectProHeadlineConfiguration_Apply_DataType,
//															datatypeClass);
													Individual datatypeIndividual = ontModel.getIndividual(METAG + "0" + datatype);
													headlineConfigurationIndividual.addProperty(objectProHeadlineConfiguration_Apply_DataType,
															datatypeIndividual);
												}
												if (headlineConfiguration.attributeValue("size") != null) {
													String size = headlineConfiguration.attributeValue("size").toString();
													headlineConfigurationIndividual.addProperty(annotationProSize, size);
												}
												owlReqIFIndividual.addProperty(objectProReqIFOwnHeadlineConfiguration, headlineConfigurationIndividual);// 绑定到该ReqIF实例
											}
										}
									}
								}
							}
						} catch (NullPointerException npe) {
							System.out.println("Can not find!");
							npe.printStackTrace();
						}
					}
				}
			}
		}

	}

	private static void generateChildren(Element father, OntModel ontModel, Individual specificationIndividual,Individual owlReqIFIndividual) {
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
		OntClass owlSpec_HierarchyClass = ontModel.getOntClass(METAG + "Spec_Hierarchy");
		AnnotationProperty annotationProIdentifier = ontModel.getAnnotationProperty(METAG + "identifier");
		AnnotationProperty annotationProLast_Change = ontModel.getAnnotationProperty(METAG + "Last_Change");
		ObjectProperty objectProSpecHierarchy_Ref_SpecObject = ontModel.createObjectProperty(METAG + "SpecHierarchy_Ref_SpecObject");
		ObjectProperty objectProSpecification_has_SpecHierarchy = ontModel.createObjectProperty(METAG + "Specification_has_SpecHierarchy");
		ObjectProperty objectProSpecHierarchy_has_SpecHierarchy = ontModel.createObjectProperty(METAG + "SpecHierarchy_has_SpecHierarchy");
		
		Individual indFather = ontModel.getIndividual(METAG + father.attribute("IDENTIFIER").getValue());

		Element children = father.element("CHILDREN");
		if (children != null) {
			for (Iterator<Element> it3 = children.elementIterator(); it3.hasNext();) {
				Element childrenChild = it3.next();

				String identifier3 = childrenChild.attribute("IDENTIFIER").getValue();
				String lastChange3 = childrenChild.attribute("LAST-CHANGE").getValue();

				Individual Spec_HierarchyIndividual = ontModel.createIndividual(METAG + identifier3,
						owlSpec_HierarchyClass);
				if(indFather.equals(specificationIndividual)) {
					indFather.addProperty(objectProSpecification_has_SpecHierarchy, Spec_HierarchyIndividual);
				}
				else {
					indFather.addProperty(objectProSpecHierarchy_has_SpecHierarchy, Spec_HierarchyIndividual);
				}

				Spec_HierarchyIndividual.addProperty(annotationProIdentifier, identifier3);
				Spec_HierarchyIndividual.addProperty(annotationProLast_Change, lastChange3);
				String objectID = childrenChild.element("OBJECT").element("SPEC-OBJECT-REF").getText();
				// 引用Spec Object
				Individual object = ontModel.getIndividual(METAG + objectID);
				Spec_HierarchyIndividual.addProperty(objectProSpecHierarchy_Ref_SpecObject, object);

				generateChildren(childrenChild, ontModel, specificationIndividual, owlReqIFIndividual);

			}
		} else
			return;
	}
}
