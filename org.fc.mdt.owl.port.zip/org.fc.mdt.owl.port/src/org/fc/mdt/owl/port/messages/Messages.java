package org.fc.mdt.owl.port.messages;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.Platform;

public final class Messages {

    private Messages() {

    }

    /**
     *
     */
    private static HashMap<String, String> messageMap = null;

    /**
     *
     * @param key
     * @return value
     */
    public static String getValue(final String key) {

        if (messageMap == null) {
			final String nl = Platform.getNL();
			if (nl != null && nl.equals("zh_CN")) {
                messageMap = getAllMessage(
                        "org/fc/mdt/owl/port/messages/owl_port_messages_zh");
			} else {
                messageMap = getAllMessage(
                        "org/fc/mdt/owl/port/messages/owl_port_messages_en");
			}
        }
        String value = messageMap.get(key);
        if (value == null) {
            return "";
        } else {
            return value;
        }
    }

    private static HashMap<String, String> getAllMessage(final String propertyName) {
        // 获得资源包
        String fileName = propertyName.trim();
        ResourceBundle rb = ResourceBundle.getBundle(fileName);
        // 通过资源包拿到所有的key
        Enumeration<String> allKey = rb.getKeys();
        // 遍历key 得到 value
        HashMap<String, String> map = new HashMap<String, String>();
        while (allKey.hasMoreElements()) {
            String key = allKey.nextElement();
            String value = (String) rb.getString(key);
            map.put(key, value);
        }
        return map;
    }
}
