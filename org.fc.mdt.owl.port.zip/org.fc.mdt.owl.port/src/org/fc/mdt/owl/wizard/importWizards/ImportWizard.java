package org.fc.mdt.owl.wizard.importWizards;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.apache.jena.ontology.OntClass;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.mdt.components.exceptions.MdtException;
import org.eclipse.sirius.ui.tools.api.project.ModelingProjectManager;
import org.eclipse.ui.IImportWizard;
import org.eclipse.ui.IWorkbench;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.visitor.exceptions.MDTKarmaVisitorException;
import org.fc.mdt.owl.owl2Karma.Owl2Gantt;
import org.fc.mdt.owl.owl2Karma.Owl2Karma;
import org.fc.mdt.owl.owl2Karma.Owl2KarmaUtil;
import org.fc.mdt.owl.owl2Karma.Owl2MTable;
import org.fc.mdt.owl.owl2Karma.Owl2NodeUtil;
import org.fc.mdt.owl.owl2Karma.Owl2Table;
import org.fc.mdt.owl.port.messages.Messages;

public class ImportWizard extends Wizard implements IImportWizard {

	ImportWizardPage mainPage;

	public ImportWizard() {
		super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.wizard.Wizard#performFinish()
	 */
	public boolean performFinish() {
		boolean finished = true;
		try {
			final String projectName = mainPage.getProjectName();
			String owlFilePath = mainPage.getOwlPath();
			getContainer().run(true, false, new IRunnableWithProgress() {

				@Override
				public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
					try {
						doFinish(projectName, owlFilePath, monitor);
					} catch (final CoreException e) {
						throw new InvocationTargetException(e);
					}
				}
			});
		} catch (InvocationTargetException e) {
			finished = false;
		} catch (InterruptedException e) {
			finished = false;
		}
		return finished;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IWorkbenchWizard#init(org.eclipse.ui.IWorkbench,
	 * org.eclipse.jface.viewers.IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		setWindowTitle(Messages.getValue("ImportWizard_windowTitle")); // NON-NLS-1
		setNeedsProgressMonitor(true);
		mainPage = new ImportWizardPage(); // NON-NLS-1
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.wizard.IWizard#addPages()
	 */
	public void addPages() {
		super.addPages();
		addPage(mainPage);
	}

	protected void doFinish(String projectName, String owlFilePath, IProgressMonitor monitor) throws CoreException {
//		IProject project = ModelingProjectManager.INSTANCE.createNewModelingProject(projectName, true, monitor);
		String location = Platform.getLocation().toString();
    	IPath path = Path.fromOSString(location + "\\" + projectName);
    	if (mainPage.getPath() != null) {
    		path = Path.fromOSString(mainPage.getPath() + "\\" + projectName);
		}
		IProject project = ModelingProjectManager.INSTANCE.createNewModelingProject(projectName, path, true, monitor);
//		IFolder languagesFolder = project.getFolder("languages");
//		languagesFolder.create(true, true, monitor);
//		IFolder imagesFolder = project.getFolder("images");
//		imagesFolder.create(true, true, monitor);
//		IFolder iconsFolder = project.getFolder("icons");
//		iconsFolder.create(true, true, monitor);
//		IFolder smtFolder = project.getFolder("SMT");
//		smtFolder.create(true, true, monitor);

		final String nl = Platform.getNL();
		IFolder languagesFolder = null;
		if (nl != null && nl.equals("zh_CN")) {
			languagesFolder = project.getFolder(PackagePath.TYPE_LANGUAGE_ZH);
			languagesFolder.create(true, true, monitor);
			IFolder imagesFolder = project.getFolder(PackagePath.TYPE_IMAGES_ZH);
			imagesFolder.create(true, true, monitor);
			IFolder iconsFolder = project.getFolder(PackagePath.TYPE_ICONS_ZH);
			iconsFolder.create(true, true, monitor);
			IFolder smtFolder = project.getFolder(PackagePath.TYPE_SMT_ZH);
			smtFolder.create(true, true, monitor);
		} else {
			languagesFolder = project.getFolder(PackagePath.TYPE_LANGUAGE);
			languagesFolder.create(true, true, monitor);
			IFolder imagesFolder = project.getFolder(PackagePath.TYPE_IMAGES);
			imagesFolder.create(true, true, monitor);
			IFolder iconsFolder = project.getFolder(PackagePath.TYPE_ICONS);
			iconsFolder.create(true, true, monitor);
			IFolder smtFolder = project.getFolder(PackagePath.TYPE_SMT);
			smtFolder.create(true, true, monitor);
		}

		Owl2NodeUtil.generateLangugage(owlFilePath, languagesFolder, monitor);
		Owl2NodeUtil.generateKarProject(owlFilePath, project);

		Owl2NodeUtil owlutil = new Owl2NodeUtil();
		try {
			owlutil.generatearchitectureDriven(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		try {
			owlutil.generatecodeGeneration(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		try {
			owlutil.generatehybridAutomataSimulation(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		try {
			owlutil.generateMetaProperty(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		try {
			owlutil.generateMetaPoint(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		try {
			owlutil.generateMetaRole(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			owlutil.generateMetaObject(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			owlutil.generateMetaRelationship(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			owlutil.generateMetaGraph(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MdtException | MDTKarmaVisitorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			owlutil.generateModel(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			owlutil.generatePackages(owlFilePath, languagesFolder, monitor);
		} catch (IOException | CoreException | MDTKarmaVisitorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
