package org.fc.mdt.owl.wizard.exportWizards;

import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IExportWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.fc.mdt.core.utils.log.console.MdtLogConsole;
import org.fc.mdt.core.utils.log.console.MdtLogConsoleFactory;
import org.fc.mdt.owl.karma2owl.BFO2Owl;
import org.fc.mdt.owl.karma2owl.DSM2Owl;
import org.fc.mdt.owl.karma2owl.Gantt2Owl;
import org.fc.mdt.owl.karma2owl.Karma2Owl;
import org.fc.mdt.owl.karma2owl.MTable2Owl;
import org.fc.mdt.owl.karma2owl.Matrix2Owl;
import org.fc.mdt.owl.karma2owl.Reqif2Owl;
import org.fc.mdt.owl.karma2owl.Table2Owl;
import org.fc.mdt.owl.port.messages.Messages;
import org.fc.mdt.workbench.dialog.SaveWarningDialog;

public class ExportBfoWizard extends Wizard implements IExportWizard {
	private MdtLogConsole console = MdtLogConsoleFactory.getInstance().getConsole();
	ExportBfoWizardPage mainPage;

	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		setWindowTitle(Messages.getValue("ExportWizard_windowTitle")); // NON-NLS-1
		setNeedsProgressMonitor(true);
		mainPage = new ExportBfoWizardPage();

	}

	@Override
	public void addPages() {
		super.addPages();
		addPage(mainPage);
	}

	@Override
	public boolean performFinish() {
		boolean finished = true;
		try {
//          List projectPath = mainPage.getSelected();
			String outputPath = mainPage.getOutputPath();
			IProject selectedProject = mainPage.getSelectedProject();
			String outputName = mainPage.getOutputName();
			getContainer().run(true, false, new IRunnableWithProgress() {

				@Override
				public void run(final IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
					doFinish(outputPath, selectedProject, outputName, monitor);
				}
			});
		} catch (InvocationTargetException e) {
			finished = false;
		} catch (InterruptedException e) {
			finished = false;
			mainPage.setErrorMessage(Messages.getValue("ExportWizard_errorMessage"));
			mainPage.setPageComplete(false);
		}
		return finished;
	}

	protected void doFinish(String outputPath, IProject selectedProject, String outputName, IProgressMonitor monitor)
			throws InterruptedException {

		final boolean[] unsaved = { false };
		Display.getDefault().asyncExec(new Runnable() {
			@Override
			public void run() {
				IWorkbenchWindow window = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
				IWorkbenchPage activePage = window.getActivePage();
				IEditorPart[] editorParts = activePage.getEditors();
				List<IEditorPart> editors = new ArrayList<>();
				for (IEditorPart iEditorPart : editorParts) {
					IEditorInput editorInput = iEditorPart.getEditorInput();
					boolean dirty = iEditorPart.isDirty();
					if (dirty) {
						IFile adapter = editorInput.getAdapter(IFile.class);
						if (adapter != null) {
							if (selectedProject.getName().equals(adapter.getProject().getName())) {
								unsaved[0] = true;
								editors.add(iEditorPart);
							}
						}
					}
				}
				if (editors.size() > 0) {
					SaveWarningDialog dialog = new SaveWarningDialog(Display.getCurrent().getActiveShell(),
							Messages.getValue("unsaved"));
					if (dialog.open() == SaveWarningDialog.OK) {
						for (IEditorPart iEditorPart : editors) {
							iEditorPart.doSave(new NullProgressMonitor());
						}
						unsaved[0] = false;
					} else {
						return;
					}
				}
				if (unsaved[0]) {
					return;
				}
				try {
					String owlFullPath = outputPath + "\\" + outputName + ".owl";
					// 先写owl一些必要的基本信息
					String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
					OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);

					BFO2Owl.generateBFO(selectedProject, ontModel);
					Karma2Owl.generateKarma(selectedProject, ontModel, true);
					Reqif2Owl.generateReqif(selectedProject, ontModel);
					DSM2Owl.generateDSM(selectedProject, ontModel, true);
					Gantt2Owl.generateGantt(selectedProject, ontModel,true);										
					Table2Owl.generateTable(selectedProject, ontModel, true);
					MTable2Owl.generateMTable(selectedProject, ontModel, true);
					Matrix2Owl.generateMatrix(selectedProject, ontModel, true);
					
					ontModel.write(new FileOutputStream(owlFullPath));
					ontModel.close();
					selectedProject.refreshLocal(IResource.DEPTH_ONE, monitor);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
