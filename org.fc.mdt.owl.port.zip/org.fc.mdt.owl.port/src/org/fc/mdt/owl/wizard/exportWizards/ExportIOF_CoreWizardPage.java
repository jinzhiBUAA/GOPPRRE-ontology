package org.fc.mdt.owl.wizard.exportWizards;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.preference.DirectoryFieldEditor;
import org.eclipse.jface.viewers.ComboViewer;
import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;
import org.fc.mdt.owl.port.messages.Messages;

public class ExportIOF_CoreWizardPage extends WizardPage {
	protected DirectoryFieldEditor editor;
	private Text text;
	private IProject selectedProject;
	private String outputPath;
	private String outputName;
	private ComboViewer comboViewer;
	private static class ViewerLabelProvider extends LabelProvider {
		public Image getImage(Object element) {
			return super.getImage(element);
		}
		public String getText(Object element) {
			return super.getText(element);
		}
	}
	private static class ContentProvider implements IStructuredContentProvider {
		public Object[] getElements(Object inputElement) {
			return new Object[0];
		}
		public void dispose() {
		}
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		}
	}

	public ExportIOF_CoreWizardPage() {
		super("wizardPage");
		setTitle(Messages.getValue("ExportWizardPage_title"));
		setDescription(Messages.getValue("ExportWizardPage_description"));
		setPageComplete(false);
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);

		setControl(container);
		container.setLayout(new GridLayout(1, true));
		
		Group group_1 = new Group(container, SWT.NONE);
		GridLayout gl_group_1 = new GridLayout(2, false);
		gl_group_1.verticalSpacing = 15;
		gl_group_1.marginHeight = 10;
		group_1.setLayout(gl_group_1);
		group_1.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		
		List input = new ArrayList();
        IProject[] projects = ResourcesPlugin.getWorkspace().getRoot()
                .getProjects();
        for (IProject project : projects) {
            if (project.isOpen() && !project.getName().startsWith("bootstrap-")) {
				input.add(project);
			}
        }
		
		
		Label lblSelectProject = new Label(group_1, SWT.NONE);
		lblSelectProject.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		lblSelectProject.setText(Messages.getValue("ExportWizardPage_selectLabel"));
        
		comboViewer = new ComboViewer(group_1, SWT.NONE);
		Combo combo_1 = comboViewer.getCombo();
		combo_1.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        combo_1.setFont(parent.getFont());
        
        Label lblOwlFileName = new Label(group_1, SWT.NONE);
        GridData gd_lblOwlFileName = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
        gd_lblOwlFileName.widthHint = 100;
        lblOwlFileName.setLayoutData(gd_lblOwlFileName);
        lblOwlFileName.setText(Messages.getValue("ExportWizardPage_owlFileNameLabel"));
        
        text = new Text(group_1, SWT.BORDER);
        text.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        text.addModifyListener(e -> {
        	outputName = text.getText();
        	updatePageComplete();
        });

        IContentProvider contentProvider = new ResourceProvider(IResource.FOLDER | IResource.PROJECT, true);
		comboViewer.setContentProvider(contentProvider);
		comboViewer.setLabelProvider(WorkbenchLabelProvider.getDecoratingWorkbenchLabelProvider());
		comboViewer.setInput(input);
		
		
		Composite fileSelectionArea = new Composite(container, SWT.NULL);
		GridData fileSelectionData = new GridData(GridData.FILL_HORIZONTAL);
		fileSelectionArea.setLayoutData(fileSelectionData);

		GridLayout fileSelectionLayout = new GridLayout();
		fileSelectionLayout.numColumns = 3;
		fileSelectionLayout.makeColumnsEqualWidth = false;
		fileSelectionLayout.marginWidth = 0;
		fileSelectionLayout.marginHeight = 0;
		fileSelectionArea.setLayout(fileSelectionLayout);
		editor = new DirectoryFieldEditor("directorySelect", Messages.getValue("ExportWizardPage_directorySelect"), fileSelectionArea);
		editor.getTextControl(fileSelectionArea).addModifyListener(e -> {
			outputPath = editor.getStringValue();
			updatePageComplete();
		});
		
		comboViewer.addSelectionChangedListener(new ISelectionChangedListener(){

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				IStructuredSelection selection = event.getStructuredSelection();
				Object selectedElement = selection.getFirstElement();
				selectedProject = (IProject) selectedElement;
				text.setText(selectedProject.getName() + "_IOF_Core");
				editor.setStringValue(selectedProject.getLocation().toOSString());
				outputPath = editor.getStringValue();
				updatePageComplete();
			}
			
		});
		setErrorMessage(null);
	}
	
	private void updatePageComplete() {
		if(comboViewer.getSelection().isEmpty()) {
			setPageComplete(false);
			setErrorMessage(Messages.getValue("ExportWizardPage_projectIsNUll"));
			return;
		}
		if(StringUtils.isBlank(text.getText())) {
			setPageComplete(false);
			setErrorMessage(Messages.getValue("ExportWizardPage_nameIsNUll"));
			return;
		}
		if(StringUtils.isBlank(editor.getStringValue())) {
			setPageComplete(false);
			setErrorMessage(Messages.getValue("ExportWizardPage_pathIsNUll"));
			return;
		}
		setPageComplete(true);
		setErrorMessage(null);
		return ;
	}

	public IProject getSelectedProject() {
		return this.selectedProject;
	}
	
	public String getOutputPath() {
		return this.outputPath;
	}
	
	public String getOutputName() {
		return this.outputName;
	}
	
	private static class ResourceProvider extends WorkbenchContentProvider {
        private static final Object[] EMPTY = new Object[0];
        private int resourceType;
        private boolean showLinkedResources;

        public ResourceProvider(int resourceType, boolean showLinkedResources) {
            super();
            this.resourceType = resourceType;
            this.showLinkedResources = showLinkedResources;
        }

        @Override
		public Object[] getChildren(Object o) {
            if (o instanceof IContainer) {
                IContainer container = (IContainer) o;
                if (!showLinkedResources && container.isLinked(IResource.CHECK_ANCESTORS)) {
                    // just return an empty set of children
                    return EMPTY;
                }
                IResource[] members = null;
                try {
                    members = container.members();
                } catch (CoreException e) {
                    // just return an empty set of children
                    return EMPTY;
                }

                // filter out the desired resource types
                List<IResource> results = new ArrayList<>();
                for (IResource resource : members) {
                    if (!showLinkedResources && resource.isLinked()) {
                        continue;
                    }
                    if ((resource.getType() & resourceType) > 0) {
                        results.add(resource);
                    }
                }
                return results.toArray();
            }
            // input element case
            if (o instanceof ArrayList) {
                return ((List<?>) o).toArray();
            }
            return EMPTY;
        }
    }
}
