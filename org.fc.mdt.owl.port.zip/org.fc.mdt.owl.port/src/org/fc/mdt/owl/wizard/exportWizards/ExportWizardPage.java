package org.fc.mdt.owl.wizard.exportWizards;


import java.util.List;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.ui.dialogs.WizardExportResourcesPage;

public class ExportWizardPage extends WizardExportResourcesPage{

	protected ExportWizardPage(String pageName, IStructuredSelection selection) {
		super(pageName, selection);
		// TODO Auto-generated constructor stub
	}

	

	@Override
	protected void createDestinationGroup(Composite parent) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void handleEvent(Event event) {
		// TODO Auto-generated method stub
		
	}

	public List getSelected() {
		return this.getSelectedResources();
	}

	
}
