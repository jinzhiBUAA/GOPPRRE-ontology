package org.fc.mdt.owl.owl2Karma;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.jena.ontology.AllValuesFromRestriction;
import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.Restriction;
import org.apache.jena.ontology.SomeValuesFromRestriction;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.eclipse.core.runtime.IPath;

public class Owl2Karma {

	public static void GenerateKarma(String owlFilePath, IPath projectFile) throws IOException {
		
		System.out.println(owlFilePath);
		System.out.println(projectFile.toString());
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";
		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);
		
		StringBuffer res = new StringBuffer();
		String line = null;
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(projectFile.toString() + "/project.karma"), "UTF-8"));
		
		// 获取annotationproperty
		AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
		AnnotationProperty iconAddress = ontModel.getAnnotationProperty(IRI + "#" + "iconAddress");
		AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
		AnnotationProperty shape = ontModel.getAnnotationProperty(IRI + "#" + "shape");
		AnnotationProperty direction = ontModel.getAnnotationProperty(IRI + "#" + "direction");
		AnnotationProperty modelSize = ontModel.getAnnotationProperty(IRI + "#" + "modelSize");
		AnnotationProperty startLocation = ontModel.getAnnotationProperty(IRI + "#" + "startLocation");
		AnnotationProperty endLocation = ontModel.getAnnotationProperty(IRI + "#" + "endLocation");
		AnnotationProperty screenMode = ontModel.getAnnotationProperty(IRI + "#" + "screenMode");
		AnnotationProperty lineColor = ontModel.getAnnotationProperty(IRI + "#" + "lineColor");
		AnnotationProperty textColor = ontModel.getAnnotationProperty(IRI + "#" + "textColor");
		AnnotationProperty fillColor = ontModel.getAnnotationProperty(IRI + "#" + "fillColor");
		AnnotationProperty imageAddress = ontModel.getAnnotationProperty(IRI + "#" + "imageAddress");
		AnnotationProperty lableDisplay = ontModel.getAnnotationProperty(IRI + "#" + "lableDisplay");
		AnnotationProperty matrix = ontModel.getAnnotationProperty(IRI + "#" + "matrix");
		AnnotationProperty time = ontModel.getAnnotationProperty(IRI + "#" + "time");
		// CIF属性
		AnnotationProperty groupPart = ontModel.getAnnotationProperty(IRI + "#" + "groupPart");
		AnnotationProperty locationPart = ontModel.getAnnotationProperty(IRI + "#" + "locationPart");
		AnnotationProperty edgePart = ontModel.getAnnotationProperty(IRI + "#" + "edgePart");
		AnnotationProperty automatonPart = ontModel.getAnnotationProperty(IRI + "#" + "automatonPart");
		AnnotationProperty SVGPart = ontModel.getAnnotationProperty(IRI + "#" + "SVGPart");
		AnnotationProperty ExternalFunctionDeclarePart = ontModel
				.getAnnotationProperty(IRI + "#" + "ExternalFunctionDeclarePart");
		
		res.append("test");
		writer.write(res.toString());
		writer.flush();
		
		// 查找项目
		OntClass project = ontModel.getOntClass(IRI + "#" + "Project");
		
		for (Iterator it = project.listSubClasses(); it.hasNext();) {
			System.out.println(project.getURI());
			OntClass project_i = (OntClass) it.next();
			String project_systemname_i = project_i.getLocalName();
			String project_localname_i = project_i.getPropertyValue(localLabel).toString();
			res.append("Project " + project_systemname_i + " annotation (localLabel=\"" + project_localname_i + "\")\n");
			writer.write(res.toString());
			writer.flush();
			res.setLength(0);
			//语言
			for (Iterator ip = project_i.listEquivalentClasses(); ip.hasNext();) {
				OntClass c = (OntClass) ip.next();
				Restriction r = c.asRestriction();
				OntClass language_i;
				if (r.isSomeValuesFromRestriction()
						&& r.getOnProperty().getLocalName().equals("projectIncludingLanguage")) {
					SomeValuesFromRestriction sr = r.asSomeValuesFromRestriction();
					language_i = (OntClass) sr.getSomeValuesFrom();
				} else {
					continue;
				}
				res.append("     Language " + language_i.getLocalName() + 
						" annotation (localLabel=\"" + language_i.getPropertyValue(localLabel).toString() + "\")\n");
				//属性元模型
				for (Iterator il = language_i.listEquivalentClasses(); il.hasNext();) {
					OntClass c2 = (OntClass) il.next();
					Restriction r2 = c2.asRestriction();
					if (r2.isSomeValuesFromRestriction()
							&& r2.getOnProperty().getLocalName().equals("languageIncludingProperty")) {
						SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
						OntClass GOPPRR_i = (OntClass) sr2.getSomeValuesFrom();
						if (GOPPRR_i.getSuperClass().getLocalName().equals("Property")) {
							res.append("	     String Property " + GOPPRR_i.getLocalName() +
									" annotation (localLabel=\"" + GOPPRR_i.getPropertyValue(localLabel).toString() +
									"\",description=\"meta property\");\n");
						}
					}
				}
				
				writer.write(res.toString());
				writer.flush();
				res.setLength(0);
				//图元模型
				HashSet<OntClass> graphSet = new HashSet<OntClass> ();
				HashSet<OntClass> objectSet = new HashSet<OntClass> ();
				HashSet<OntClass> relationshipSet = new HashSet<OntClass> ();
				HashSet<OntClass> roleSet = new HashSet<OntClass> ();
				HashSet<OntClass> pointSet = new HashSet<OntClass> ();
				for (Iterator il = language_i.listEquivalentClasses(); il.hasNext();) {
					OntClass c2 = (OntClass) il.next();
					Restriction r2 = c2.asRestriction();
					if (r2.isSomeValuesFromRestriction()
							&& r2.getOnProperty().getLocalName().equals("languageIncludingGraph")) {
						SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
						OntClass GOPPRR_i = (OntClass) sr2.getSomeValuesFrom();
						if (GOPPRR_i.getSuperClass().getLocalName().equals("Graph")) {
							graphSet.add(GOPPRR_i);
						}
					}
					if (r2.isSomeValuesFromRestriction()
							&& r2.getOnProperty().getLocalName().equals("languageIncludingObject")) {
						SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
						OntClass GOPPRR_i = (OntClass) sr2.getSomeValuesFrom();
						if (GOPPRR_i.getSuperClass().getLocalName().equals("Object")) {
							objectSet.add(GOPPRR_i);
						}
					}
					if (r2.isSomeValuesFromRestriction()
							&& r2.getOnProperty().getLocalName().equals("languageIncludingRelationship")) {
						SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
						OntClass GOPPRR_i = (OntClass) sr2.getSomeValuesFrom();
						if (GOPPRR_i.getSuperClass().getLocalName().equals("Relationship")) {
							relationshipSet.add(GOPPRR_i);
						}
					}
					if (r2.isSomeValuesFromRestriction()
							&& r2.getOnProperty().getLocalName().equals("languageIncludingRole")) {
						SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
						OntClass GOPPRR_i = (OntClass) sr2.getSomeValuesFrom();
						if (GOPPRR_i.getSuperClass().getLocalName().equals("Role")) {
							roleSet.add(GOPPRR_i);
						}
					}
					if (r2.isSomeValuesFromRestriction()
							&& r2.getOnProperty().getLocalName().equals("languageIncludingPoint")) {
						SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
						OntClass GOPPRR_i = (OntClass) sr2.getSomeValuesFrom();
						if (GOPPRR_i.getSuperClass().getLocalName().equals("point")) {
							pointSet.add(GOPPRR_i);
						}
					}
				}
				writer.write(res.toString());
				writer.flush();
				res.setLength(0);
				//图元模型
				for(OntClass graph_i : graphSet){
					res.append("	     partial Graph " + graph_i.getLocalName() + "\n");
					OntClass MetaGraph_i_connector = null;
					//图元模型ORP
					for(Iterator graph_it = graph_i.listEquivalentClasses(); graph_it.hasNext(); ){
						OntClass c2 = (OntClass) graph_it.next();
						Restriction r2 = c2.asRestriction();
						//some图元模型属性
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaGraph_i_property_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     initial Property " + MetaGraph_i_property_j.getLocalName() + " extends "
									+ MetaGraph_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaGraph_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//all图元模型属性
						if(r2.isAllValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
							OntClass MetaGraph_i_property_j = (OntClass) sr2.getAllValuesFrom();
							res.append("		     initial Property unique " + MetaGraph_i_property_j.getLocalName() + " extends "
									+ MetaGraph_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaGraph_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//图元模型对象
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("graphIncludingObject")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaGraph_i_ORR_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     Object " + MetaGraph_i_ORR_j.getLocalName() + ";\n");
						}
						//图元模型关系
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("graphIncludingRelationship")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaGraph_i_ORR_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     Relationship " + MetaGraph_i_ORR_j.getLocalName() + ";\n");
						}
						//找到图元模型Constraint
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("graphIncludingConnector")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							MetaGraph_i_connector = (OntClass) sr2.getSomeValuesFrom();
						}
					}
					
					//图元模型Constraint
					if(MetaGraph_i_connector != null){
						res.append("		     Constraint(\n");
					for (Iterator connector_i = MetaGraph_i_connector.listEquivalentClasses(); connector_i.hasNext();) {
						OntClass c3 = (OntClass)connector_i.next();
						//设置链接
						if (c3.isIntersectionClass()) {
							String connector_object = null;
							String connector_point = null;
							String connector_role = null;
							String connector_relationship = null;
							for (Iterator and_i = c3.asIntersectionClass().listOperands(); and_i.hasNext();) {
								OntClass and_one = (OntClass) and_i.next();
								if (and_one.isRestriction()) {
									OntClass c4 = (OntClass) and_one.asRestriction()
											.asSomeValuesFromRestriction().getSomeValuesFrom();
									if (c4.getSuperClass().getLocalName().equals("Role")) 
										connector_role = c4.getLocalName();
									if (c4.getSuperClass().getLocalName().equals("Object")) 
										connector_object = c4.getLocalName();
									if (c4.getSuperClass().hasSuperClass()) 
										connector_point = c4.getLocalName();
									if (c4.getSuperClass().getLocalName().equals("Relationship")) 
										connector_relationship = c4.getLocalName();
								}
							}
							if(connector_point == null){
								res.append("		         bind connector(" + connector_object + ", " 
										+ connector_relationship + "." + connector_role + "),\n");
							}
							else{
								res.append("		         bind connector(" + connector_object + "." + connector_point + ", " 
										+ connector_relationship + "." + connector_role + "),\n");
							}
							
						}
						//设置分解剖视
						if (c3.isRestriction()) {
							Restriction c4 = c3.asRestriction();
							String DorE = null;// 记录是分解还是剖视(D or E)
							String DorE_object = null;// 记录分解剖视的对象
							String DorE_graph = null;// 记录分解剖视的图
							if (((OntClass) c4.asSomeValuesFromRestriction().getSomeValuesFrom())
									.isIntersectionClass()) {
								for (Iterator c4_i = ((OntClass) c4.asSomeValuesFromRestriction()
										.getSomeValuesFrom()).asIntersectionClass().listOperands(); c4_i
												.hasNext();) {
									OntClass c4_i_c = (OntClass) c4_i.next();
									if (c4_i_c.isRestriction()) {
										Restriction c4_i_r = c4_i_c.asRestriction();
										if (c4_i_r.isSomeValuesFromRestriction())// 针对对象的等价类：对象拥有点
										{
											DorE = c4_i_r.getOnProperty().getLocalName();
											DorE_graph = c4_i_r.asSomeValuesFromRestriction()
													.getSomeValuesFrom().getLocalName();
										}

									} else {
										DorE_object = c4_i_c.getLocalName();
									}
								}
							}
							res.append("		         " + DorE_object + "." + DorE + "(" + DorE_graph + "),\n");
						}
						
					}
					if(res.charAt(res.length() - 2) == ','){
						res.deleteCharAt(res.length() - 2);
					}
					res.append("		     );\n");
					}
					
					//图元模型annotation
					res.append("		     annotation(\n" + "		     	localLabel=\"" + graph_i.getPropertyValue(localLabel).toString()
							 + "\",\n");
					//description生成有问题
					res.append("		     	description=\"" + (graph_i.hasProperty(description) ? graph_i.getPropertyValue(description).toString() : "") + "\"\n		     );\n");
					res.append("	     end " + graph_i.getLocalName() + ";\n");
				}
				res.append("\n");
				
				writer.write(res.toString());
				writer.flush();
				res.setLength(0);
				
				//对象元模型
				for(OntClass MetaObject_i : objectSet){
					res.append("	     Object " + MetaObject_i.getLocalName() + "\n");
					//对象元模型属性
					for(Iterator object_it = MetaObject_i.listEquivalentClasses(); object_it.hasNext(); ){
						OntClass c2 = (OntClass) object_it.next();
						Restriction r2 = c2.asRestriction();
						//some对象元模型属性
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaObject_i_property_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     initial Property " + MetaObject_i_property_j.getLocalName() + " extends "
									+ MetaObject_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaObject_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//all对象元模型属性
						if(r2.isAllValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
							OntClass MetaObject_i_property_j = (OntClass) sr2.getAllValuesFrom();
							res.append("		     initial Property unique " + MetaObject_i_property_j.getLocalName() + " extends "
									+ MetaObject_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaObject_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//对象元模型上点
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("linkObjectAndPoint")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaObject_i_class_j = (OntClass) sr2.getSomeValuesFrom();
							if (MetaObject_i_class_j.isIntersectionClass()) {
								String pointDir = null;
								OntClass MetaObejct_i_Point_j = null;
								for (Iterator and = MetaObject_i_class_j.asIntersectionClass().listOperands(); and.hasNext();) {
									OntClass and_class = (OntClass) and.next();
									if(!and_class.isRestriction()){
										MetaObejct_i_Point_j = and_class;
									}
									else{
										if (and_class.asRestriction().asHasValueRestriction().getHasValue()
												.toString().equals("输出")) {
											pointDir = "Output";
										}
										if (and_class.asRestriction().asHasValueRestriction().getHasValue()
												.toString().equals("输入")) {
											pointDir = "Input";
										}
									}
								}
								//---------------------------------------//
								//---------------------------------------//
								//--------------owl写完成后删除--------------//
								pointSet.add(MetaObejct_i_Point_j.getSuperClass());
								//---------------------------------------//
								//---------------------------------------//
								res.append("		     " + pointDir + " Point " + MetaObejct_i_Point_j.getLocalName() + " extends "
										+ MetaObejct_i_Point_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
										+ MetaObejct_i_Point_j.getPropertyValue(localLabel).toString() + "\");\n");
							}
						}
						
					}
					//对象元模型annotation
					res.append("		     annotation(\n" + "		     	localLabel=\"" + MetaObject_i.getPropertyValue(localLabel).toString()
							 + "\",\n");
					res.append("		     	description=\"" + MetaObject_i.getPropertyValue(description).toString() + "\",\n");
					res.append("		     	icon=\"" + MetaObject_i.getPropertyValue(iconAddress).toString() + "\",\n");
					res.append("		     	shape=\"" + MetaObject_i.getPropertyValue(shape).toString() + "\"\n");
					res.append("		     	);\n");
					//对象元模型结束
					res.append("	     end " + MetaObject_i.getLocalName() + ";\n");
				}
				res.append("\n");
				
				//关系元模型
				for(OntClass MetaRelationship_i : relationshipSet){
					res.append("	     Relationship " + MetaRelationship_i.getLocalName() + "\n");
					//关系元模型属性和角色
					for(Iterator relationship_it = MetaRelationship_i.listEquivalentClasses(); relationship_it.hasNext(); ){
						OntClass c2 = (OntClass) relationship_it.next();
						Restriction r2 = c2.asRestriction();
						//some关系元模型属性
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaRelationship_i_property_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     initial Property " + MetaRelationship_i_property_j.getLocalName() + " extends "
									+ MetaRelationship_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaRelationship_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//all关系元模型属性
						if(r2.isAllValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
							OntClass MetaRelationship_i_property_j = (OntClass) sr2.getAllValuesFrom();
							res.append("		     initial Property unique " + MetaRelationship_i_property_j.getLocalName() + " extends "
									+ MetaRelationship_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaRelationship_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//关系元模型角色
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("linkRelationshipAndRole")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaRelationship_i_Role_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     Role " + MetaRelationship_i_Role_j.getLocalName() + ";\n");
						}
					}
					//关系元模型annotation
					res.append("		     annotation(\n" + "		     	localLabel=\"" + MetaRelationship_i.getPropertyValue(localLabel).toString()
							 + "\",\n");
					res.append("		     	description=\"" + MetaRelationship_i.getPropertyValue(description).toString() + "\",\n");
					res.append("		     	icon=\"" + MetaRelationship_i.getPropertyValue(iconAddress).toString() + "\",\n");
					res.append("		     	shape=\"" + MetaRelationship_i.getPropertyValue(shape).toString() + "\"\n");
					res.append("		     	);\n");
					//关系元模型结束
					res.append("	     end " + MetaRelationship_i.getLocalName() + ";\n");
				}
				res.append("\n");
				
				//角色元模型
				for(OntClass MetaRole_i : roleSet){
					res.append("	     " + MetaRole_i.getPropertyValue(direction).toString() 
							+ " Role " + MetaRole_i.getLocalName() + "\n");
					//角色元模型属性
					for(Iterator role_it = MetaRole_i.listEquivalentClasses(); role_it.hasNext(); ){
						OntClass c2 = (OntClass) role_it.next();
						Restriction r2 = c2.asRestriction();
						//some角色元模型属性
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaRole_i_property_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     initial Property " + MetaRole_i_property_j.getLocalName() + " extends "
									+ MetaRole_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaRole_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//all角色元模型属性
						if(r2.isAllValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
							OntClass MetaRole_i_property_j = (OntClass) sr2.getAllValuesFrom();
							res.append("		     initial Property unique " + MetaRole_i_property_j.getLocalName() + " extends "
									+ MetaRole_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaRole_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
					}
					//角色元模型annotation
					res.append("		     annotation(\n" + "		     	localLabel=\"" + MetaRole_i.getPropertyValue(localLabel).toString()
							 + "\",\n");
					res.append("		     	description=\"" + MetaRole_i.getPropertyValue(description).toString() + "\",\n");
					res.append("		     	shape=\"" + MetaRole_i.getPropertyValue(shape).toString() + "\"\n");
					res.append("		     	);\n");
					//角色元模型结束
					res.append("	     end " + MetaRole_i.getLocalName() + ";\n");
				}
				res.append("\n");
				
				//点元模型
				for(OntClass MetaPoint_i : pointSet){
					res.append("	     Point " + MetaPoint_i.getLocalName() + "\n");
					//点元模型属性
					for(Iterator point_it = MetaPoint_i.listEquivalentClasses(); point_it.hasNext(); ){
						OntClass c2 = (OntClass) point_it.next();
						Restriction r2 = c2.asRestriction();
						//some点元模型属性
						if(r2.isSomeValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
							OntClass MetaPoint_i_property_j = (OntClass) sr2.getSomeValuesFrom();
							res.append("		     initial Property " + MetaPoint_i_property_j.getLocalName() + " extends "
									+ MetaPoint_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaPoint_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
						//all点元模型属性
						if(r2.isAllValuesFromRestriction()
								&& r2.getOnProperty().getLocalName().equals("hasProperty")){
							AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
							OntClass MetaPoint_i_property_j = (OntClass) sr2.getAllValuesFrom();
							res.append("		     initial Property unique " + MetaPoint_i_property_j.getLocalName() + " extends "
									+ MetaPoint_i_property_j.getSuperClass().getLocalName() + " annotation (localLabel=\"" 
									+ MetaPoint_i_property_j.getPropertyValue(localLabel).toString() + "\");\n");
						}
					}
					//点元模型annotation
					res.append("		     annotation(\n" + "		     	localLabel=\"" + MetaPoint_i.getPropertyValue(localLabel).toString()
							 + "\",\n");
					res.append("		     	description=\"" + MetaPoint_i.getPropertyValue(description).toString() + "\",\n");
					res.append("		     	shape=\"" + MetaPoint_i.getPropertyValue(shape).toString() + "\"\n");
					res.append("		     	);\n");
					//点元模型结束
					res.append("	     end " + MetaPoint_i.getLocalName() + ";\n");
				}
				res.append("\n");
				
				//图模型
				for(OntClass graph_i : graphSet){
					for (Iterator il2 = graph_i.listInstances(); il2.hasNext(); ) {
						Individual graph_Individual = (Individual) il2.next();
						res.append("	     partial Model " + graph_Individual.getLocalName() + " instanceof " + graph_i.getLocalName() + "\n");
						//图属性
						for (Iterator ig = graph_Individual.listProperties(); ig.hasNext();) {
							Statement igs = (Statement) ig.next();
							// 添加属性及属性值
							if (igs.getPredicate().getLocalName().equals("hasProperty")) {
								// 找到属性实例
								Individual graph_property_Individual = ontModel.getIndividual(igs.getResource().getURI());
								//找到属性值
								String graph_property_Individual_value = "";
								for (Iterator igp = graph_property_Individual.listProperties(); igp.hasNext();) {
									Statement igps = (Statement) igp.next();
									if (igps.getPredicate().getLocalName().equals("value")) {
										graph_property_Individual_value = igps.getString();
									}
								}
								res.append("		     Property " + graph_property_Individual.getLocalName() + "=\"" 
										+ graph_property_Individual_value + "\" refer " + graph_property_Individual.getOntClass().getLocalName() + " annotation (localLabel=\"" 
										+ graph_property_Individual.getPropertyValue(localLabel).toString() + "\");\n");
							}
							
							//添加关系实例
							if (igs.getPredicate().getLocalName().equals("graphIncludingRelationship")) {
								
							}
							//添加connector实例
							if (igs.getPredicate().getLocalName().equals("graphIncludingConnector")) {
								
							}
						}
						//图对象
						for (Iterator ig = graph_Individual.listProperties(); ig.hasNext();) {
							Statement igs = (Statement) ig.next();
							//添加对象实例
							if (igs.getPredicate().getLocalName().equals("graphIncludingObject")) {
								// 找到对象实例
								Individual graph_object_Individual = ontModel.getIndividual(igs.getResource().getURI());
								res.append("		     Object " + graph_object_Individual.getLocalName() + " refer " + graph_object_Individual.getOntClass().getLocalName() + "\n");
								//对象实例属性
								for (Iterator igp = graph_object_Individual.listProperties(); igp.hasNext();) {
									Statement igps = (Statement) igp.next();
									if (igps.getPredicate().getLocalName().equals("hasProperty")) {
										// 找到对象实例属性
										Individual object_property_Individual = ontModel.getIndividual(igps.getResource().getURI());
										//找到属性值
										String object_property_Individual_value = "";
										for (Iterator igp2 = object_property_Individual.listProperties(); igp2.hasNext();) {
											Statement igps2 = (Statement) igp2.next();
											if (igps2.getPredicate().getLocalName().equals("value")) {
												object_property_Individual_value = igps2.getString();
											}
										}
										res.append("		     	Property " + object_property_Individual.getLocalName() + "=\"" 
												+ object_property_Individual_value + "\" refer " + object_property_Individual.getOntClass().getLocalName() + " annotation (localLabel=\"" 
												+ object_property_Individual.getPropertyValue(localLabel).toString() + "\");\n");
									}
								}
								//对象实例点
								for (Iterator igp = graph_object_Individual.listProperties(); igp.hasNext();) {
									Statement igps = (Statement) igp.next();
									if (igps.getPredicate().getLocalName().equals("linkObjectAndPoint")) {
										// 点实例
										Individual point_Individual = ontModel.getIndividual(igps.getResource().getURI());
										res.append("		     	Point " + point_Individual.getLocalName() + " refer " + point_Individual.getOntClass().getLocalName() + "\n");
										// 点实例属性
										for(Iterator igp2 = point_Individual.listProperties(); igp2.hasNext();) {
											Statement igps2 = (Statement) igp2.next();
											if (igps2.getPredicate().getLocalName().equals("hasProperty")) {
												// 找到点实例属性
												Individual point_property_Individual = ontModel.getIndividual(igps2.getResource().getURI());
												//找到属性值
												String point_property_Individual_value = "";
												for (Iterator igp3 = point_property_Individual.listProperties(); igp3.hasNext();) {
													Statement igps3 = (Statement) igp3.next();
													if (igps3.getPredicate().getLocalName().equals("value")) {
														point_property_Individual_value = igps3.getString();
													}
												}
												res.append("		     		Property " + point_property_Individual.getLocalName() + "=\"" 
														+ point_property_Individual_value + "\" refer " + point_property_Individual.getOntClass().getLocalName() + " annotation (localLabel=\"" 
														+ point_property_Individual.getPropertyValue(localLabel).toString() + "\");\n");
											}
											if(igps2.getPredicate().getLocalName().equals("decomposePointConnectObject")){
												Individual point_connectorObject_Individual = ontModel.getIndividual(igps2.getResource().getURI());
												res.append("		     		this.connectObject(" + point_connectorObject_Individual.getLocalName() + ");\n");
											}
										}
										//点实例annotation
										res.append("		     		annotation(\n" + "		     			localLabel=\"" + point_Individual.getPropertyValue(localLabel).toString()
												 + "\",\n");
										//res.append("		     			description=\"" + point_Individual.getPropertyValue(description).toString() + "\",\n");
										res.append("		     			shape=\"" + point_Individual.getPropertyValue(shape).toString() + "\",\n");
										res.append("		     			initialLocation=(0,0,0,0),\n");
										res.append("		     			color=(\"113,113,113;121,121,121;220,220,220\")\n");
										res.append("		     		);\n");
										//结束点实例
										res.append("		     	end " + point_Individual.getLocalName() + ";\n");
									}
								}
								//对象实例分解剖视
								for (Iterator igp = graph_object_Individual.listProperties(); igp.hasNext();) {
									Statement igps = (Statement) igp.next();
									if (igps.getPredicate().getLocalName().equals("decompose")) {
										Individual object_decompose_Individual = ontModel.getIndividual(igps.getResource().getURI());
										res.append("		     	this.decompose(" + object_decompose_Individual.getLocalName() +  ");\n");
									}
									if (igps.getPredicate().getLocalName().equals("explode")) {
										Individual object_explode_Individual = ontModel.getIndividual(igps.getResource().getURI());
										res.append("		     	this.explode(" + object_explode_Individual.getLocalName() +  ");\n");
									}
								}
								//对象实例annotation
								res.append("		     	annotation(\n" + "		     		localLabel=\"" + graph_object_Individual.getPropertyValue(localLabel).toString()
										 + "\",\n");
								//res.append("		     		description=\"" + graph_object_Individual.getPropertyValue(description).toString() + "\",\n");
								res.append("		     		imageAddress=\"" + graph_object_Individual.getPropertyValue(imageAddress).toString() +"\",\n");
								res.append("		     		shape=\"" + graph_object_Individual.getPropertyValue(shape).toString() + "\",\n");
								res.append("		     		screenMode=" + graph_object_Individual.getPropertyValue(screenMode).toString() +",\n");
								res.append("		     		layerLocation=0,\n");
								res.append("		     		initialLocation=(0,0,0,0),\n");
								res.append("		     		color=(\"113,113,113;121,121,121;220,220,220\")\n");
								res.append("		     	);\n");
								//结束对象实例
								res.append("		     end " + graph_object_Individual.getLocalName() + ";\n");
							}
						}
						//图关系
						for (Iterator ig = graph_Individual.listProperties(); ig.hasNext();) {
							Statement igs = (Statement) ig.next();
							//添加关系实例
							if (igs.getPredicate().getLocalName().equals("graphIncludingRelationship")) {
								// 找到关系实例
								Individual graph_rela_Individual = ontModel.getIndividual(igs.getResource().getURI());
								res.append("		     Relationship " + graph_rela_Individual.getLocalName() + " refer " + graph_rela_Individual.getOntClass().getLocalName() + "\n");
								//关系实例属性
								for (Iterator igp = graph_rela_Individual.listProperties(); igp.hasNext();) {
									Statement igps = (Statement) igp.next();
									if (igps.getPredicate().getLocalName().equals("hasProperty")) {
										// 找到对象实例属性
										Individual rela_property_Individual = ontModel.getIndividual(igps.getResource().getURI());
										//找到属性值
										String rela_property_Individual_value = "";
										for (Iterator igp2 = rela_property_Individual.listProperties(); igp2.hasNext();) {
											Statement igps2 = (Statement) igp2.next();
											if (igps2.getPredicate().getLocalName().equals("value")) {
												rela_property_Individual_value = igps2.getString();
											}
										}
										res.append("		     	Property " + rela_property_Individual.getLocalName() + "=\"" 
												+ rela_property_Individual_value + "\" refer " + rela_property_Individual.getOntClass().getLocalName() + " annotation (localLabel=\"" 
												+ rela_property_Individual.getPropertyValue(localLabel).toString() + "\");\n");
									}
								}
								//关系实例角色
								for (Iterator igp = graph_rela_Individual.listProperties(); igp.hasNext();) {
									Statement igps = (Statement) igp.next();
									if (igps.getPredicate().getLocalName().equals("linkRelationshipAndRole")) {
										// 角色实例
										Individual role_Individual = ontModel.getIndividual(igps.getResource().getURI());
										res.append("		     	Role " + role_Individual.getLocalName() + " refer " + role_Individual.getOntClass().getLocalName() + "\n");
										// 角色实例属性
										for(Iterator igp2 = role_Individual.listProperties(); igp2.hasNext();) {
											Statement igps2 = (Statement) igp2.next();
											if (igps2.getPredicate().getLocalName().equals("hasProperty")) {
												// 找到角色实例属性
												Individual role_property_Individual = ontModel.getIndividual(igps2.getResource().getURI());
												//找到属性值
												String role_property_Individual_value = "";
												for (Iterator igp3 = role_property_Individual.listProperties(); igp3.hasNext();) {
													Statement igps3 = (Statement) igp3.next();
													if (igps3.getPredicate().getLocalName().equals("value")) {
														role_property_Individual_value = igps3.getString();
													}
												}
												res.append("		     		Property " + role_property_Individual.getLocalName() + "=\"" 
														+ role_property_Individual_value + "\" refer " + role_property_Individual.getOntClass().getLocalName() + " annotation (localLabel=\"" 
														+ role_property_Individual.getPropertyValue(localLabel).toString() + "\");\n");
											}
										}
										//角色实例annotation
										res.append("		     		annotation(\n" + "		     			localLabel=\"" + role_Individual.getPropertyValue(localLabel).toString()
												 + "\",\n");
										//res.append("		     			description=\"" + role_Individual.getPropertyValue(description).toString() + "\",\n");
										
										res.append("		     			shape=\"" + role_Individual.getPropertyValue(shape).toString() + "\",\n");
										
										res.append("		     		);\n");
										//结束角色实例
										res.append("		     	end " + role_Individual.getLocalName() + ";\n");
									}
								}
								//关系实例annotation
								res.append("		     	annotation(\n" + "		     		localLabel=\"" + graph_rela_Individual.getPropertyValue(localLabel).toString()
										 + "\",\n");
								res.append("		     		description=\"" + graph_rela_Individual.getPropertyValue(description).toString() + "\",\n");
								//res.append("		     		imageAddress=\"" + graph_rela_Individual.getPropertyValue(imageAddress).toString() +"\",\n");
								res.append("		     		shape=\"" + graph_rela_Individual.getPropertyValue(shape).toString() + "\",\n");
								res.append("		     		screenMode=" + graph_rela_Individual.getPropertyValue(screenMode).toString() +",\n");
								res.append("		     		layerLocation=0,\n");
								res.append("		     		initialLocation=(0,0,0,0),\n");
								res.append("		     		color=(\"113,113,113;121,121,121;220,220,220\")\n");
								res.append("		     	);\n");
								//结束关系实例
								res.append("		     end " + graph_rela_Individual.getLocalName() + ";\n");
							}
						}
						//链接
						
						//图annotation
						res.append("		     annotation(\n" + "			localLabel=\"" + graph_Individual.getPropertyValue(localLabel).toString()+ "\",\n");
						res.append("			);\n");
						//结束图模型
						res.append("	     end " + graph_Individual.getLocalName() + ";\n");
					}
				}
				
				res.append(" end " + language_i.getLocalName()+ ";\n");
			}//语言结束
			res.append(" end " + project_i.getLocalName()+ ";\n");
			writer.write(res.toString());
			writer.flush();
			System.out.println("karma文件生成成功");
			res.setLength(0);
		}
		writer.close();
	}
}
