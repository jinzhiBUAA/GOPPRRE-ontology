package org.fc.mdt.owl.owl2Karma;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;

public class Owl2Gantt {

	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
	
	/**
	 * 读取owl文件
	 * @author xiaodu
	 * @param owlFilePath
	 */
	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}
	
	/** 生成Gantt的方法重载
	 * @author xiaodu
	 * */
	public static void GenerateGantt(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException {
		OntModel ontModel = readOwlFile(owlFilePath);
		GenerateGantt(ontModel, languagesFolder, monitor);
	}

	public static void GenerateGantt(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */

		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);

		// 获取类
		OntClass owlGanttPluginClass = ontModel.getOntClass(METAG + "GanttPlugin");
		OntClass owlGanttChartClass = ontModel.getOntClass(METAG + "GanttChart");
		OntClass owlGanttSectionClass = ontModel.getOntClass(METAG + "GanttSection");
		OntClass owlEventClass = ontModel.getOntClass(METAG + "Event");

		// 获取AnnotationProperty
		AnnotationProperty annotationProName = ontModel.getAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationProActualStartDate = ontModel.getAnnotationProperty(METAG + "ActualStartDate");
		AnnotationProperty annotationProActualActualStartTimeInMillis = ontModel
				.getAnnotationProperty(METAG + "ActualStartTimeInMillis");
		AnnotationProperty annotationProActualEndDate = ontModel.getAnnotationProperty(METAG + "ActualEndDate");
		AnnotationProperty annotationProActualEndTimeInMillis = ontModel
				.getAnnotationProperty(METAG + "ActualEndTimeInMillis");
		AnnotationProperty annotationProPlannedStartDate = ontModel.getAnnotationProperty(METAG + "PlannedStartDate");
		AnnotationProperty annotationProPlannedStartTimeInMillis = ontModel
				.getAnnotationProperty(METAG + "PlannedStartTimeInMillis");
		AnnotationProperty annotationProPlannedEndDate = ontModel.getAnnotationProperty(METAG + "PlannedEndDate");
		AnnotationProperty annotationProPlannedEndTimeInMillis = ontModel
				.getAnnotationProperty(METAG + "PlannedEndTimeInMillis");
		AnnotationProperty annotationProPercentComplete = ontModel.getAnnotationProperty(METAG + "PercentComplete");
		AnnotationProperty annotationPropertyModelLocation = ontModel.getAnnotationProperty(METAG + "modelLocation");
		AnnotationProperty annotationProId = ontModel.getAnnotationProperty(METAG + "id");
		AnnotationProperty annotationProlocalLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationProlocalValue = ontModel.getAnnotationProperty(METAG + "event_value");

		// 一个gantt individual是一个Gantt文件
		for (Iterator it = owlGanttPluginClass.listInstances(); it.hasNext();) {
			Individual owlGanttIndividual = (Individual) it.next();
			String filename;
			String name = owlGanttIndividual.getPropertyValue(annotationProName).toString();						
			Document document = DocumentHelper.createDocument();
			Element KARMA_external_plugin = document.addElement("KARMA_external_plugin");
			Element Gantt = KARMA_external_plugin.addElement("Gantt");
			Gantt.addAttribute("Name", name);
			if(owlGanttIndividual.getPropertyValue(annotationProlocalLabel)!=null) {
				String localLabel = owlGanttIndividual.getPropertyValue(annotationProlocalLabel).toString();
				Gantt.addAttribute("localLabel", localLabel);
				filename = localLabel;
			}			
			else {
				filename = owlGanttIndividual.getLocalName();
				filename = filename.replace("_", " ");
			}
			Boolean state = false;
			for (Iterator It = owlGanttIndividual.listProperties(); It.hasNext();) {
				Statement owlGanttIndividualPro = (Statement) It.next();
				if (owlGanttIndividualPro.getPredicate().getLocalName().equals("own")) {
					Individual owlGanttIndividualEvent = ontModel
							.getIndividual(owlGanttIndividualPro.getResource().getURI());
					if (owlEventClass.listInstances() != null) {
						for (Iterator it_event = owlEventClass.listInstances(); it_event.hasNext();) {
							Individual owlEventElement = (Individual) it_event.next();
							if (owlGanttIndividualEvent.getLocalName().equals(owlEventElement.getLocalName())) {
								state = true;
							}
						}
					}
				}
			}
			if (state) {
				Element GanttChart = Gantt.addElement("GanttChart");
				Element GanttSection = GanttChart.addElement("GanttSection");
				for (Iterator It = owlGanttIndividual.listProperties(); It.hasNext();) {
					Statement owlGanttIndividualPro = (Statement) It.next();
					if (owlGanttIndividualPro.getPredicate().getLocalName().equals("own")) {
						Individual owlGanttIndividualEvent = ontModel
								.getIndividual(owlGanttIndividualPro.getResource().getURI());
						if (owlEventClass.listInstances() != null) {
							for (Iterator it_event = owlEventClass.listInstances(); it_event.hasNext();) {
								Individual owlEventElement = (Individual) it_event.next();
								if (owlGanttIndividualEvent.getLocalName().equals(owlEventElement.getLocalName())) {
									Element Event = GanttSection.addElement("Event");
									String event_Name = owlEventElement.getPropertyValue(annotationProName).toString();
									String event_ActualStartDate = owlEventElement
											.getPropertyValue(annotationProActualStartDate).toString();
									String event_ActualStartTimeInMillis = owlEventElement
											.getPropertyValue(annotationProActualActualStartTimeInMillis).toString();
									String event_ActualEndDate = owlEventElement
											.getPropertyValue(annotationProActualEndDate).toString();
									String event_ActualEndTimeInMillis = owlEventElement
											.getPropertyValue(annotationProActualEndTimeInMillis).toString();
									String event_PlannedStartDate = owlEventElement
											.getPropertyValue(annotationProPlannedStartDate).toString();
									String event_PlannedStartTimeInMillis = owlEventElement
											.getPropertyValue(annotationProPlannedStartTimeInMillis).toString();
									String event_PlannedEndDate = owlEventElement
											.getPropertyValue(annotationProPlannedEndDate).toString();
									String event_PlannedEndTimeInMillis = owlEventElement
											.getPropertyValue(annotationProPlannedEndTimeInMillis).toString();
									String event_PercentComplete = owlEventElement
											.getPropertyValue(annotationProPercentComplete).toString();
																		
									Event.addAttribute("Name", event_Name);
									Event.addAttribute("ActualStartDate", event_ActualStartDate);
									Event.addAttribute("ActualStartTimeInMillis", event_ActualStartTimeInMillis);
									Event.addAttribute("ActualEndDate", event_ActualEndDate);
									Event.addAttribute("ActualEndTimeInMillis", event_ActualEndTimeInMillis);
									Event.addAttribute("PlannedStartDate", event_PlannedStartDate);
									Event.addAttribute("PlannedStartTimeInMillis", event_PlannedStartTimeInMillis);
									Event.addAttribute("PlannedEndDate", event_PlannedEndDate);
									Event.addAttribute("PlannedEndTimeInMillis", event_PlannedEndTimeInMillis);
									Event.addAttribute("PercentComplete", event_PercentComplete);
									if(owlEventElement.getPropertyValue(annotationProId)!=null) {
										String event_Id = owlEventElement.getPropertyValue(annotationProId).toString();
										Event.addAttribute("id", event_Id);
									}
									if(owlEventElement.getPropertyValue(annotationProlocalLabel)!=null) {
										String event_LocalLabel = owlEventElement.getPropertyValue(annotationProlocalLabel)
												.toString();
										Event.addAttribute("localLabel", event_LocalLabel);
									}
									if(owlEventElement.getPropertyValue(annotationProlocalValue)!=null) {
										String event_Value = owlEventElement.getPropertyValue(annotationProlocalValue)
												.toString();
										Event.addAttribute("value", event_Value);
									}
								}
							}
						}

					}
				}
			}

			else {
				Element GanttChart = Gantt.addElement("GanttChart");
				Element GanttSection = GanttChart.addElement("GanttSection");
			}
			IFolder languageFolder = languagesFolder
					.getFolder(owlGanttIndividual.getPropertyValue(annotationPropertyModelLocation).toString());
			IFolder modelFolder = null;
			IFolder modelFolder1 = languageFolder.getFolder(PackagePath.TYPE_MODEL);
			IFolder modelFolder2 = languageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
			if (modelFolder1.exists()) {
				modelFolder = modelFolder1;
			} else if (modelFolder2.exists()) {
				modelFolder = modelFolder2;
			}
			String fileName = modelFolder.getLocation().toOSString() + "/" + filename + ".gantt";
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("UTF-8");
			format.setNewLineAfterDeclaration(false);
			XMLWriter writer = new XMLWriter(new FileOutputStream(new File(fileName)), format);
			writer.write(document);
			writer.close();
			IFile modelFile = modelFolder.getFile(filename + ".gantt");
			modelFile.refreshLocal(IResource.DEPTH_ZERO, null);
		}
	}

}
