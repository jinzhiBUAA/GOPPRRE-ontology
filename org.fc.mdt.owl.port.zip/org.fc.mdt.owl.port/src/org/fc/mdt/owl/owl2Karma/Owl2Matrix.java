package org.fc.mdt.owl.owl2Karma;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;

public class Owl2Matrix {
	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";

	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}

	public static void GenerateMatrix(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException {
		OntModel ontModel = readOwlFile(owlFilePath);
		GenerateMatrix(ontModel, languagesFolder, monitor);
	}

	public static void GenerateMatrix(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException {
		/*
		 * 输入为OntModel,所以注释掉此处 edited by xiaodu OntModel ontModel =
		 * ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM); String path =
		 * owlFilePath; ontModel.read(path);
		 */

		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);

		// 获取类
		OntClass owlMatrixClass = ontModel.getOntClass(METAG + "Matrix");
		OntClass owlMatrixRowClass = ontModel.getOntClass(METAG + "Matrix_Row");
		OntClass owlMatrixColumnClass = ontModel.getOntClass(METAG + "Matrix_Column");
		OntClass owlMatrixRelationClass = ontModel.getOntClass(METAG + "Matrix_Relation");

		// 获取annotaiton property
		AnnotationProperty annotationPro_id = ontModel.getAnnotationProperty(METAG + "id");
		AnnotationProperty annotationPro_localLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationPro_text = ontModel.getAnnotationProperty(METAG + "text");
		AnnotationProperty annotationPro_name = ontModel.getAnnotationProperty(METAG + "name");
		AnnotationProperty annotationPro_direction = ontModel.getAnnotationProperty(METAG + "direction");
		AnnotationProperty annotationPro_location = ontModel.getAnnotationProperty(METAG + "location");
		AnnotationProperty annotationPropertyModelLocation = ontModel.getAnnotationProperty(METAG + "modelLocation");
		AnnotationProperty annotationPro_type = ontModel.getAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPro_resource = ontModel.getAnnotationProperty(METAG + "resource");// 表达来源
		AnnotationProperty annotationPro_rowLocation = ontModel.getAnnotationProperty(METAG + "rowLocation");// 表达原始位置
		AnnotationProperty annotationPro_columnLocation = ontModel.getAnnotationProperty(METAG + "columnLocation");// 表达原始位置

		// 获取object property
		ObjectProperty objectPro_linkRelationshipAndSourceRole = ontModel
				.getObjectProperty(METAG + "linkRelationshipAndSourceRole");
		ObjectProperty objectPro_linkRelationshipAndTargetRole = ontModel
				.getObjectProperty(METAG + "linkRelationshipAndTargetRole");
		ObjectProperty objectPro_matrixHasRelation = ontModel.getObjectProperty(METAG + "matrixHasRelation");
		ObjectProperty objectPro_hasResource = ontModel.createObjectProperty(METAG + "hasResource");// 表达来源
		ObjectProperty objectPro_ref = ontModel.createObjectProperty(METAG + "ref");
		ObjectProperty objectPro_hasChildren = ontModel.createObjectProperty(METAG + "hasChildren");// 表达层级关系
		ObjectProperty objectPro_matrixHasRow = ontModel.createObjectProperty(METAG + "matrixHasRow");
		ObjectProperty objectPro_matrixHasColumn = ontModel.createObjectProperty(METAG + "matrixHasColumn");

		// 一个owlMatrixIndividual是一个matrix文件
		for (Iterator it = owlMatrixClass.listInstances(); it.hasNext();) {
			Individual owlMatrixIndividual = (Individual) it.next();
			String id = owlMatrixIndividual.getPropertyValue(annotationPro_id).toString();
			String filename = id;
			Document document = DocumentHelper.createDocument();
			Element KARMA_external_plugin = document.addElement("KARMA_external_plugin");
			Element Matrix = KARMA_external_plugin.addElement("Matrix");
			Matrix.addAttribute("id", id);
			String localLabel = owlMatrixIndividual.getPropertyValue(annotationPro_localLabel).toString();
			String text = owlMatrixIndividual.getPropertyValue(annotationPro_text).toString();
			Matrix.addAttribute("localLabel", localLabel);
			Matrix.addAttribute("text", text);
			// ROW_HEADER
			Element ROW_HEADER = Matrix.addElement("ROW_HEADER");
			List<Individual> rowList = new ArrayList<>();
			for (Iterator It = owlMatrixIndividual.listProperties(); It.hasNext();) {
				Statement owlMatrixIndividualPro = (Statement) It.next();
				if (owlMatrixIndividualPro.getPredicate().getLocalName().equals("matrixHasRow")) {
					Individual owlMatrixRowIndividual = ontModel
							.getIndividual(owlMatrixIndividualPro.getResource().getURI());
					rowList.add(owlMatrixRowIndividual);
				}
			}
			// 根据row_location排序列表
			rowList.sort(Comparator.comparingInt(individual -> {
				String row_location = individual.getPropertyValue(annotationPro_rowLocation).toString();
				try {
					return Integer.parseInt(row_location);
				} catch (NumberFormatException e) {
					// 如果转换失败，默认返回一个足够小的值，以便将其放到列表的开头
					return Integer.MIN_VALUE;
				}
			}));

			if(!rowList.isEmpty()) {
				Individual owlMatrixRowIndividual = rowList.get(0);
				Element row = ROW_HEADER.addElement("row");
				String row_id = owlMatrixRowIndividual.getPropertyValue(annotationPro_id).toString();
				String row_name = owlMatrixRowIndividual.getPropertyValue(annotationPro_name).toString();
				String row_type = owlMatrixRowIndividual.getPropertyValue(annotationPro_type).toString();
				String row_resource = null;
				if (owlMatrixRowIndividual.getPropertyValue(annotationPro_resource) != null) {
					row_resource = owlMatrixRowIndividual.getPropertyValue(annotationPro_resource).toString();
				} else {
					for (Iterator igp = owlMatrixRowIndividual.listProperties(); igp.hasNext();) {
						Statement igps = (Statement) igp.next();
						if (igps.getPredicate().getLocalName().equals("hasResource")) {
							Individual owlResourceIndividual = ontModel.getIndividual(igps.getResource().getURI());
							row_resource = owlResourceIndividual.getLocalName();
						}
					}
				}
				row.addAttribute("id", row_id);
				row.addAttribute("name", row_name);
				row.addAttribute("type", row_type);
				row.addAttribute("resource", row_resource);
				generateElementR(row, ontModel, owlMatrixRowIndividual);
			}
			
			// COLUMN_HEADER
			Element COLUMN_HEADER = Matrix.addElement("COLUMN_HEADER");
			List<Individual> columnList = new ArrayList<>();
			for (Iterator It = owlMatrixIndividual.listProperties(); It.hasNext();) {
				Statement owlMatrixIndividualPro = (Statement) It.next();
				if (owlMatrixIndividualPro.getPredicate().getLocalName().equals("matrixHasColumn")) {
					Individual owlMatrixColumnIndividual = ontModel
							.getIndividual(owlMatrixIndividualPro.getResource().getURI());
					columnList.add(owlMatrixColumnIndividual);
				}
			}
			// 根据column_location排序列表
			columnList.sort(Comparator.comparingInt(individual -> {
				String column_location = individual.getPropertyValue(annotationPro_columnLocation).toString();
				try {
					return Integer.parseInt(column_location);
				} catch (NumberFormatException e) {
					// 如果转换失败，默认返回一个足够小的值，以便将其放到列表的开头
					return Integer.MIN_VALUE;
				}
			}));

			if(!columnList.isEmpty()) {
				Individual owlMatrixColumnIndividual = columnList.get(0);
				Element column = COLUMN_HEADER.addElement("column");
				String column_id = owlMatrixColumnIndividual.getPropertyValue(annotationPro_id).toString();
				String column_name = owlMatrixColumnIndividual.getPropertyValue(annotationPro_name).toString();
				String column_type = owlMatrixColumnIndividual.getPropertyValue(annotationPro_type).toString();
				String column_resource = null;
				if (owlMatrixColumnIndividual.getPropertyValue(annotationPro_resource) != null) {
					column_resource = owlMatrixColumnIndividual.getPropertyValue(annotationPro_resource).toString();
				} else {
					for (Iterator igp = owlMatrixColumnIndividual.listProperties(); igp.hasNext();) {
						Statement igps = (Statement) igp.next();
						if (igps.getPredicate().getLocalName().equals("hasResource")) {
							Individual owlResourceIndividual = ontModel.getIndividual(igps.getResource().getURI());
							column_resource = owlResourceIndividual.getLocalName();
						}
					}
				}
				column.addAttribute("id", column_id);
				column.addAttribute("name", column_name);
				column.addAttribute("type", column_type);
				column.addAttribute("resource", column_resource);
				generateElementC(column, ontModel, owlMatrixColumnIndividual);
			}
			
			// RELATION
			Element RELATION = Matrix.addElement("RELATION");
			int rowSize = rowList.size();
			int columnSize = columnList.size();
			for(int i = 0; i < rowSize; i++) {
				Element Matrix_Relation = RELATION.addElement("Matrix_Relation");
				for(int j = 0; j < columnSize; j++){
					Element relation = Matrix_Relation.addElement("relation");
					int ii = i + 1;
					int jj = j + 1;
					String relationLocation  = "(" +ii + "," +jj +")";
					for (Iterator It = owlMatrixIndividual.listProperties(); It.hasNext();) {
						Statement owlMatrixIndividualPro = (Statement) It.next();
						if (owlMatrixIndividualPro.getPredicate().getLocalName().equals("matrixHasRelation")) {
							Individual owlMatrixRelationIndividual = ontModel
									.getIndividual(owlMatrixIndividualPro.getResource().getURI());
							if(owlMatrixRelationIndividual.getPropertyValue(annotationPro_location).toString().equals(relationLocation)) {
								String relation_id = owlMatrixRelationIndividual.getPropertyValue(annotationPro_id).toString();
								String relation_name = owlMatrixRelationIndividual.getPropertyValue(annotationPro_name).toString();
								String relation_direction = owlMatrixRelationIndividual.getPropertyValue(annotationPro_direction).toString();
								relation.addAttribute("id", relation_id);
								relation.addAttribute("name", relation_name);
								relation.addAttribute("direction", relation_direction);
								Element source_role = relation.addElement("source_role");
								Element target_role = relation.addElement("target_role");
								
								for (Iterator Itr = owlMatrixRelationIndividual.listProperties(); Itr.hasNext();) {
									Statement owlMatrixRelationIndividualPro = (Statement) Itr.next();
									if (owlMatrixRelationIndividualPro.getPredicate().getLocalName().equals("linkRelationshipAndSourceRole")) {
										Individual owlSourceRoleIndividual = ontModel
												.getIndividual(owlMatrixRelationIndividualPro.getResource().getURI());									
										String source_role_id = owlSourceRoleIndividual.getPropertyValue(annotationPro_id).toString();
										String source_role_name = owlSourceRoleIndividual.getPropertyValue(annotationPro_name).toString();
										source_role.addAttribute("id", source_role_id);
										source_role.addAttribute("name", source_role_name);
									}
									if (owlMatrixRelationIndividualPro.getPredicate().getLocalName().equals("linkRelationshipAndTargetRole")) {
										Individual owlTargetRoleIndividual = ontModel
												.getIndividual(owlMatrixRelationIndividualPro.getResource().getURI());									
										String target_role_id = owlTargetRoleIndividual.getPropertyValue(annotationPro_id).toString();
										String target_role_name = owlTargetRoleIndividual.getPropertyValue(annotationPro_name).toString();
										target_role.addAttribute("id", target_role_id);
										target_role.addAttribute("name", target_role_name);
									}
								}
							}
						}
					}
				}
			}

			// 后期工作
			IFolder languageFolder = languagesFolder
					.getFolder(owlMatrixIndividual.getPropertyValue(annotationPropertyModelLocation).toString());
			IFolder modelFolder = null;
			IFolder modelFolder1 = languageFolder.getFolder(PackagePath.TYPE_MODEL);
			IFolder modelFolder2 = languageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
			if (modelFolder1.exists()) {
				modelFolder = modelFolder1;
			} else if (modelFolder2.exists()) {
				modelFolder = modelFolder2;
			}
			String fileName = modelFolder.getLocation().toOSString() + "/" + filename + ".matrix";
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("UTF-8");
			format.setNewLineAfterDeclaration(false);
			XMLWriter writer = new XMLWriter(new FileOutputStream(new File(fileName)), format);
			writer.write(document);
			writer.close();

			IFile modelFile = modelFolder.getFile(filename + ".matrix");
			modelFile.refreshLocal(IResource.DEPTH_ZERO, null);
		}
	}

	private static void generateElementR(Element row, OntModel ontModel, Individual owlMatrixRowIndividual) {
		// 获取annotaiton property
		AnnotationProperty annotationPro_id = ontModel.getAnnotationProperty(METAG + "id");
		AnnotationProperty annotationPro_name = ontModel.getAnnotationProperty(METAG + "name");
		AnnotationProperty annotationPro_type = ontModel.getAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPro_resource = ontModel.getAnnotationProperty(METAG + "resource");// 表达来源
		AnnotationProperty annotationPro_rowLocation = ontModel.getAnnotationProperty(METAG + "rowLocation");// 表达原始位置

		List<Individual> rowList = new ArrayList<>();
		for (Iterator igp = owlMatrixRowIndividual.listProperties(); igp.hasNext();) {
			Statement igps = (Statement) igp.next();
			if (igps.getPredicate().getLocalName().equals("hasChildren")) {
				Individual owlMatrixRowRowIndividual = ontModel.getIndividual(igps.getResource().getURI());
				rowList.add(owlMatrixRowRowIndividual);
			}
		}
		// 根据row_location排序列表
		rowList.sort(Comparator.comparingInt(individual -> {
			String row_location = individual.getPropertyValue(annotationPro_rowLocation).toString();
			try {
				return Integer.parseInt(row_location);
			} catch (NumberFormatException e) {
				// 如果转换失败，默认返回一个足够小的值，以便将其放到列表的开头
				return Integer.MIN_VALUE;
			}
		}));
		for (Individual owlMatrixRowRowIndividual : rowList) {
			Element rowrow = row.addElement("row");
			String rowrow_id = owlMatrixRowRowIndividual.getPropertyValue(annotationPro_id).toString();
			String rowrow_name = owlMatrixRowRowIndividual.getPropertyValue(annotationPro_name).toString();
			String rowrow_type = owlMatrixRowRowIndividual.getPropertyValue(annotationPro_type).toString();
			String rowrow_resource = null;
			if (owlMatrixRowRowIndividual.getPropertyValue(annotationPro_resource) != null) {
				rowrow_resource = owlMatrixRowRowIndividual.getPropertyValue(annotationPro_resource).toString();
			} else {
				for (Iterator igp = owlMatrixRowRowIndividual.listProperties(); igp.hasNext();) {
					Statement igps = (Statement) igp.next();
					if (igps.getPredicate().getLocalName().equals("hasResource")) {
						Individual owlResourceIndividual = ontModel.getIndividual(igps.getResource().getURI());
						rowrow_resource = owlResourceIndividual.getLocalName();
					}
				}
			}
			rowrow.addAttribute("id", rowrow_id);
			rowrow.addAttribute("name", rowrow_name);
			rowrow.addAttribute("type", rowrow_type);
			rowrow.addAttribute("resource", rowrow_resource);
			generateElementR(rowrow, ontModel, owlMatrixRowRowIndividual);
		}

	}
	private static void generateElementC(Element column, OntModel ontModel, Individual owlMatrixColumnIndividual) {
		// 获取annotaiton property
		AnnotationProperty annotationPro_id = ontModel.getAnnotationProperty(METAG + "id");
		AnnotationProperty annotationPro_name = ontModel.getAnnotationProperty(METAG + "name");
		AnnotationProperty annotationPro_type = ontModel.getAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPro_resource = ontModel.getAnnotationProperty(METAG + "resource");// 表达来源
		AnnotationProperty annotationPro_columnLocation = ontModel.getAnnotationProperty(METAG + "columnLocation");// 表达原始位置
	
		List<Individual> columnList = new ArrayList<>();
		for (Iterator igp = owlMatrixColumnIndividual.listProperties(); igp.hasNext();) {
			Statement igps = (Statement) igp.next();
			if (igps.getPredicate().getLocalName().equals("hasChildren")) {
				Individual owlMatrixColumnColumnIndividual = ontModel.getIndividual(igps.getResource().getURI());
				columnList.add(owlMatrixColumnColumnIndividual);
			}
		}
		// 根据column_location排序列表
		columnList.sort(Comparator.comparingInt(individual -> {
			String column_location = individual.getPropertyValue(annotationPro_columnLocation).toString();
			try {
				return Integer.parseInt(column_location);
			} catch (NumberFormatException e) {
				// 如果转换失败，默认返回一个足够小的值，以便将其放到列表的开头
				return Integer.MIN_VALUE;
			}
		}));
		for (Individual owlMatrixColumnColumnIndividual : columnList) {
			Element columncolumn = column.addElement("column");
			String columncolumn_id = owlMatrixColumnColumnIndividual.getPropertyValue(annotationPro_id).toString();
			String columncolumn_name = owlMatrixColumnColumnIndividual.getPropertyValue(annotationPro_name).toString();
			String columncolumn_type = owlMatrixColumnColumnIndividual.getPropertyValue(annotationPro_type).toString();
			String columncolumn_resource = null;
			if (owlMatrixColumnColumnIndividual.getPropertyValue(annotationPro_resource) != null) {
				columncolumn_resource = owlMatrixColumnColumnIndividual.getPropertyValue(annotationPro_resource).toString();
			} else {
				for (Iterator igp = owlMatrixColumnColumnIndividual.listProperties(); igp.hasNext();) {
					Statement igps = (Statement) igp.next();
					if (igps.getPredicate().getLocalName().equals("hasResource")) {
						Individual owlResourceIndividual = ontModel.getIndividual(igps.getResource().getURI());
						columncolumn_resource = owlResourceIndividual.getLocalName();
					}
				}
			}
			columncolumn.addAttribute("id", columncolumn_id);
			columncolumn.addAttribute("name", columncolumn_name);
			columncolumn.addAttribute("type", columncolumn_type);
			columncolumn.addAttribute("resource", columncolumn_resource);
			generateElementC(columncolumn, ontModel, owlMatrixColumnColumnIndividual);
		}

	}
}
