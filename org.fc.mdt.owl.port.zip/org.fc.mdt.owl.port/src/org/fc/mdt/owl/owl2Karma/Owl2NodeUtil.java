package org.fc.mdt.owl.owl2Karma;

import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import javax.imageio.ImageIO;

import org.apache.jena.ontology.AllValuesFromRestriction;
import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.Restriction;
import org.apache.jena.ontology.SomeValuesFromRestriction;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.util.iterator.ExtendedIterator;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.mdt.components.exceptions.MdtException;
import org.fc.mdt.core.karma.ds.node.GraphObject;
import org.fc.mdt.core.karma.ds.node.MetaGraph;
import org.fc.mdt.core.karma.ds.node.MetaObject;
import org.fc.mdt.core.karma.ds.node.MetaPoint;
import org.fc.mdt.core.karma.ds.node.MetaProperty;
import org.fc.mdt.core.karma.ds.node.MetaRelationship;
import org.fc.mdt.core.karma.ds.node.MetaRole;
import org.fc.mdt.core.karma.ds.node.Model;
import org.fc.mdt.core.karma.ds.node.Packages;
import org.fc.mdt.core.karma.ds.node.PackagesImport;
import org.fc.mdt.core.karma.ds.node.Point;
import org.fc.mdt.core.karma.ds.node.Relationship;
import org.fc.mdt.core.karma.ds.node.Role;
import org.fc.mdt.core.karma.ds.node.references.ExternalPlugin;
import org.fc.mdt.core.karma.ds.node.references.Gantt;
import org.fc.mdt.core.karma.ds.node.references.GanttTask;
import org.fc.mdt.core.karma.ds.node.references.GanttTaskElement;
import org.fc.mdt.core.karma.ds.node.references.ImportPackage;
import org.fc.mdt.core.karma.ds.node.references.InitialLocation;
import org.fc.mdt.core.karma.ds.node.references.Layout;
import org.fc.mdt.core.karma.ds.node.references.Matrix;
import org.fc.mdt.core.karma.ds.node.references.MetaPointTypeReference;
import org.fc.mdt.core.karma.ds.node.references.MetaPropertyTypeReference;
import org.fc.mdt.core.karma.ds.node.references.PropertyTypeReference;
import org.fc.mdt.core.karma.ds.node.references.SwimLane;
import org.fc.mdt.core.karma.ds.node.references.Text;
import org.fc.mdt.core.karma.ds.utils.Bold;
import org.fc.mdt.core.karma.ds.utils.Direction;
import org.fc.mdt.core.karma.ds.utils.GanttTimeList;
import org.fc.mdt.core.karma.ds.utils.GraphType;
import org.fc.mdt.core.karma.ds.utils.Italic;
import org.fc.mdt.core.karma.ds.utils.ObjectShape;
import org.fc.mdt.core.karma.ds.utils.PointShape;
import org.fc.mdt.core.karma.ds.utils.PointTypeReferenceDirection;
import org.fc.mdt.core.karma.ds.utils.RelationshipShape;
import org.fc.mdt.core.karma.ds.utils.RoleDirection;
import org.fc.mdt.core.karma.ds.utils.RoleShape;
import org.fc.mdt.core.karma.ds.utils.RoutingStyle;
import org.fc.mdt.core.karma.ds.utils.ScreenMode;
import org.fc.mdt.core.karma.ds.utils.SysMLDiagramKind;
import org.fc.mdt.core.karma.ds.utils.SysMLModelElementType;
import org.fc.mdt.core.karma.ds.utils.Unit;
import org.fc.mdt.core.karma.ds.utils.VisualizedMode;
import org.fc.mdt.core.karma.parser.compiler.KarmaCompilerManager;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.core.karma.parser.util.SaveKarInformation;
import org.fc.mdt.core.karma.visitor.exceptions.MDTKarmaVisitorException;
import org.fc.mdt.core.karma.write.segment.KarmaMetaModeWrite;
import org.fc.mdt.core.karma.write.segment.KarmaModeWrite;
import org.fc.mdt.core.karma.write.segment.KarmaPackagesWrite;

public class Owl2NodeUtil {
	Map<String, MetaProperty> propertyMap = new HashMap<>();
	Map<String, MetaPoint> pointMap = new HashMap<>();
	Map<String, MetaRole> roleMap = new HashMap<>();
	Map<String, MetaObject> objectMap = new HashMap<>();
	Map<String, MetaRelationship> relationshipMap = new HashMap<>();
	Map<String, MetaGraph> graphMap = new HashMap<>();
	Map<String, MetaPropertyTypeReference> propertyReferenceMap = new HashMap<>();
	Map<String, MetaPointTypeReference> pointReferenceMap = new HashMap<>();
	Map<String, Model> modelMap = new HashMap<>();
	
	
	/**
	 * 读取owl文件
	 * @author xiaodu
	 * @param owlFilePath
	 */
	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}
	
	/**
	 * 生成.karproject的方法重载
	 * @author xiaodu
	 * @param project
	 */
	public static void generateKarProject(String owlFilePath, IProject project) {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateKarProject(ontModel, project);
	}
	
	/**
	 * 生成语言文件夹的方法重载
	 * @author xiaodu
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 */
	public static void generateLangugage(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateLangugage(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成architectureDriven的方法重载
	 * @author xiaodu
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException 
	 */
	public void generatearchitectureDriven(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generatearchitectureDriven(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成codeGeneration的方法重载
	 * @author xiaodu
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException 
	 */
	public void generatecodeGeneration(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generatecodeGeneration(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成hybridAutomataSimulation的方法重载
	 * @author xiaodu
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException 
	 */
	public void generatehybridAutomataSimulation(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generatehybridAutomataSimulation(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成MetaProperty的方法重载
	 * @author xiaodu
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException 
	 */
	public void generateMetaProperty(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateMetaProperty(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成MetaPoint的方法重载
	 * @author xiaodu
	 */
	public void generateMetaPoint(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateMetaPoint(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成MetaRole的方法重载
	 * @author xiaodu
	 */
	public void generateMetaRole(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateMetaRole(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成MetaObject的方法重载
	 * @author xiaodu
	 */
	public void generateMetaObject(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateMetaObject(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成MetaRelationship的方法重载
	 * @author xiaodu
	 */
	public void generateMetaRelationship(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateMetaRelationship(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成MetaGraph的方法重载
	 * @author xiaodu
	 */
	public void generateMetaGraph(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MdtException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateMetaGraph(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成Model的方法重载
	 * @author xiaodu
	 */
	public void generateModel(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generateModel(ontModel, languagesFolder, monitor);
	}
	
	/**
	 * 生成Packages的方法重载
	 * @author xiaodu
	 */
	public void generatePackages(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException, MDTKarmaVisitorException {
		OntModel ontModel = readOwlFile(owlFilePath);
		generatePackages(ontModel, languagesFolder, monitor);
	}



	/**
	 * 生成.karproject
	 * 
	 * @param project
	 */
	public static void generateKarProject(OntModel ontModel, IProject project) {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */
		
		String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";
		OntClass projectClass = ontModel.getOntClass(IRI + "#" + "Project");
		if (projectClass != null) {
			for (ExtendedIterator<OntClass> it = projectClass.listSubClasses(); it.hasNext();) {
				OntClass ontProject = it.next();
				AnnotationProperty annotationPropertyId = ontModel.getAnnotationProperty(IRI + "#" + "id");
				AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
				// 项目id
				if (annotationPropertyId != null) {
					String projectId = ontProject.getPropertyValue(annotationPropertyId).toString();
					if (projectId != null && projectId.length() > 0) {
						Map<String, String> languageMap = new HashMap<>();
						OntClass language = ontModel.getOntClass(IRI + "#" + "Language");
						if (language != null) {
							for (ExtendedIterator<OntClass> it1 = language.listSubClasses(); it1.hasNext();) {
								OntClass ontLanguage = it1.next();
								String ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
								// 语言id
								String languageId = ontLanguage.getPropertyValue(annotationPropertyId).toString();
								languageMap.put(ontLanguageName, languageId);
							}
							IFile iFile = project.getFile(".karproject");
							SaveKarInformation.generateFile(iFile, projectId, languageMap);
						}
					}
				}
			}
		}
	}

	/**
	 * 生成语言文件夹
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 */
	public static void generateLangugage(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor) {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */
		
		String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

		AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");

		OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

		for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
			OntClass ontLanguage = it.next();
			String ontLanguageName = ontLanguage.getLocalName();
			if (ontLanguage.getPropertyValue(localLabel) != null) {
				ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
			}
			IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);
			try {
				ontLanguageFolder.create(true, true, monitor);
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// 加代码生成、架构驱动、仿真
	/**
	 * 生成architectureDriven对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generatearchitectureDriven(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */
		
		String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";
		OntClass language = ontModel.getOntClass(IRI + "#" + "Language");
		AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
		for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
			OntClass ontLanguage = it.next();
			String ontLanguageName = ontLanguage.getLocalName();
			if (ontLanguage.getPropertyValue(localLabel) != null) {
				ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
			}
			IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

			final String nl = Platform.getNL();
			IFolder architectureDrivenFolder = null;
			if (nl != null && nl.equals("zh_CN")) {
				architectureDrivenFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_ARCHITECTUREDRIVEN_ZH);
			} else {
				architectureDrivenFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_ARCHITECTUREDRIVEN);
			}
			try {
				architectureDrivenFolder.create(true, true, monitor);
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * 生成codeGeneration对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generatecodeGeneration(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		 */

		String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";
		OntClass language = ontModel.getOntClass(IRI + "#" + "Language");
		AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
		for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
			OntClass ontLanguage = it.next();
			String ontLanguageName = ontLanguage.getLocalName();
			if (ontLanguage.getPropertyValue(localLabel) != null) {
				ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
			}
			final String nl = Platform.getNL();
			IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);
			IFolder codeGenerationFolder;
			if (nl != null && nl.equals("zh_CN")) {
				codeGenerationFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_CODEGENERATION_ZH);
			} else {
				codeGenerationFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_CODEGENERATION);
			}
			try {
				codeGenerationFolder.create(true, true, monitor);
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * 生成hybridAutomataSimulation对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generatehybridAutomataSimulation(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		 */

		String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";
		OntClass language = ontModel.getOntClass(IRI + "#" + "Language");
		AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
		for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
			OntClass ontLanguage = it.next();
			String ontLanguageName = ontLanguage.getLocalName();
			if (ontLanguage.getPropertyValue(localLabel) != null) {
				ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
			}
			IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);
			final String nl = Platform.getNL();
			IFolder hybridAutomataSimulationFolder = ontLanguageFolder.getFolder("hybridAutomataSimulation");
			if (nl != null && nl.equals("zh_CN")) {
				hybridAutomataSimulationFolder = ontLanguageFolder
						.getFolder(PackagePath.TYPE_HYBRIDAUTOMATASIMULATION_ZH);
			} else {
				hybridAutomataSimulationFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_HYBRIDAUTOMATASIMULATION);
			}
			try {
				hybridAutomataSimulationFolder.create(true, true, monitor);
			} catch (CoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	// 加结束

	/**
	 * 生成MetaProperty对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generateMetaProperty(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {

		try {
			
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			ontModel.read(path);
			 */

			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
			AnnotationProperty annotationPropertydataType = ontModel.getAnnotationProperty(IRI + "#" + "dataType");
			AnnotationProperty annotationPropertyunit = ontModel.getAnnotationProperty(IRI + "#" + "unit");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

			ObjectProperty languageIncludingProperty = ontModel
					.getObjectProperty(IRI + "#" + "languageIncludingProperty");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);
				final String nl = Platform.getNL();
				IFolder metaPropertyFolder;
				if (nl != null && nl.equals("zh_CN")) {
					metaPropertyFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAPROPERTY_ZH);
				} else {
					metaPropertyFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAPROPERTY);
				}
				try {
					metaPropertyFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = metaPropertyFolder.getLocation().toOSString();

				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingProperty)) {
						OntClass ontMetaProperty = (OntClass) equivalentClass.asRestriction()
								.asSomeValuesFromRestriction().getSomeValuesFrom();
						String metaPropertyName = ontMetaProperty.getLocalName();

						FileWriter writer = new FileWriter(location + "/" + metaPropertyName + ".karma");

						MetaProperty metaProperty = new MetaProperty();
						metaProperty.setId(metaPropertyName);
						metaProperty.setLocalLabel(ontMetaProperty.getPropertyValue(localLabel).toString());
						if (ontMetaProperty.getPropertyValue(description) != null) {
							metaProperty.setDescription(ontMetaProperty.getPropertyValue(description).toString());
						}

						// 2021.06.22 增加Datatype 和unit
						metaProperty
								.setDataType(ontMetaProperty.getPropertyValue(annotationPropertydataType).toString());
						if (ontMetaProperty.hasProperty(annotationPropertyunit)) {
							metaProperty.setUnit(Unit
									.fromValue(ontMetaProperty.getPropertyValue(annotationPropertyunit).toString()));
						} else {
							metaProperty.setUnit(Unit.UNIT_1);
						}
						propertyMap.put(metaPropertyName, metaProperty);

						writer.write(KarmaMetaModeWrite.getSingle().visitProperty(metaProperty));
						writer.flush();
						writer.close();
						IFile metaPropertyFile = metaPropertyFolder.getFile(metaPropertyName + ".karma");
						metaPropertyFile.refreshLocal(IResource.DEPTH_ZERO, null);
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 生成MetaPoint对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generateMetaPoint(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {

		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			ontModel.read(path);
			 */
			
			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
			AnnotationProperty shape = ontModel.getAnnotationProperty(IRI + "#" + "shape");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

			ObjectProperty languageIncludingPoint = ontModel.getObjectProperty(IRI + "#" + "languageIncludingPoint");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder metaPointFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					metaPointFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAPOINT_ZH);
				} else {
					metaPointFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAPOINT);
				}
				try {
					metaPointFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = metaPointFolder.getLocation().toOSString();

				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingPoint)) {
						OntClass ontMetaPoint = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
								.getSomeValuesFrom();
						String metaPointName = ontMetaPoint.getLocalName();

						FileWriter writer = new FileWriter(location + "/" + metaPointName + ".karma");

						MetaPoint metaPoint = new MetaPoint();
						metaPoint.setId(metaPointName);
						metaPoint.setLocalLabel(ontMetaPoint.getPropertyValue(localLabel).toString());
						if (ontMetaPoint.getPropertyValue(description) != null)
							metaPoint.setDescription(ontMetaPoint.getPropertyValue(description).toString());
						metaPoint.setPointShape(ontMetaPoint.getPropertyValue(shape).toString());

						// 点元模型属性
						for (Iterator point_it = ontMetaPoint.listEquivalentClasses(); point_it.hasNext();) {
							OntClass c2 = (OntClass) point_it.next();
							Restriction r2 = c2.asRestriction();
							// some点元模型属性
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaPointProperty = (OntClass) sr2.getSomeValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaPointProperty.getLocalName(), false,
										propertyMap.get(metaPointProperty.getSuperClass().getLocalName()),
										metaPointProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaPointProperty.getLocalName(), propertyRef);
								metaPoint.addProperty(propertyRef);
							}
							// all点元模型属性
							if (r2.isAllValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
								OntClass metaPointProperty = (OntClass) sr2.getAllValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaPointProperty.getLocalName(), true,
										propertyMap.get(metaPointProperty.getSuperClass().getLocalName()),
										metaPointProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaPointProperty.getLocalName(), propertyRef);
								metaPoint.addProperty(propertyRef);
							}
						}
						pointMap.put(metaPointName, metaPoint);

						writer.write(KarmaMetaModeWrite.getSingle().visitPoint(metaPoint));
						writer.flush();
						writer.close();
						IFile metaPointFile = metaPointFolder.getFile(metaPointName + ".karma");
						metaPointFile.refreshLocal(IResource.DEPTH_ZERO, null);
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 生成MetaRole对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generateMetaRole(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {

		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			ontModel.read(path);
			 */
			
			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
			AnnotationProperty direction = ontModel.getAnnotationProperty(IRI + "#" + "direction");
			AnnotationProperty shape = ontModel.getAnnotationProperty(IRI + "#" + "shape");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

			ObjectProperty languageIncludingRole = ontModel.getObjectProperty(IRI + "#" + "languageIncludingRole");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder metaRoleFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					metaRoleFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAROLE_ZH);
				} else {
					metaRoleFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAROLE);
				}
				try {
					metaRoleFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = metaRoleFolder.getLocation().toOSString();

				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingRole)) {
						OntClass ontMetaRole = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
								.getSomeValuesFrom();
						String metaRoleName = ontMetaRole.getLocalName();

						FileWriter writer = new FileWriter(location + "/" + metaRoleName + ".karma");

						MetaRole metaRole = new MetaRole();
						metaRole.setId(metaRoleName);
						metaRole.setLocalLabel(ontMetaRole.getPropertyValue(localLabel).toString());
						if (ontMetaRole.getPropertyValue(description) != null)
							metaRole.setDescription(ontMetaRole.getPropertyValue(description).toString());
						metaRole.setDirection(ontMetaRole.getPropertyValue(direction).toString());
						metaRole.setRoleShape(ontMetaRole.getPropertyValue(shape).toString());

						// 角色元模型属性
						for (Iterator role_it = ontMetaRole.listEquivalentClasses(); role_it.hasNext();) {
							OntClass c2 = (OntClass) role_it.next();
							Restriction r2 = c2.asRestriction();
							// some角色元模型属性
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaRoleProperty = (OntClass) sr2.getSomeValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaRoleProperty.getLocalName(), false,
										propertyMap.get(metaRoleProperty.getSuperClass().getLocalName()),
										metaRoleProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaRoleProperty.getLocalName(), propertyRef);
								metaRole.addProperty(propertyRef);
							}
							// all角色元模型属性
							if (r2.isAllValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
								OntClass metaRoleProperty = (OntClass) sr2.getAllValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaRoleProperty.getLocalName(), true,
										propertyMap.get(metaRoleProperty.getSuperClass().getLocalName()),
										metaRoleProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaRoleProperty.getLocalName(), propertyRef);
								metaRole.addProperty(propertyRef);
							}
						}
						roleMap.put(metaRoleName, metaRole);
						writer.write(KarmaMetaModeWrite.getSingle().visitRole(metaRole));
						writer.flush();
						writer.close();
						IFile metaRoleFile = metaRoleFolder.getFile(metaRoleName + ".karma");
						metaRoleFile.refreshLocal(IResource.DEPTH_ZERO, null);
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 生成MetaObject对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generateMetaObject(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, MDTKarmaVisitorException, CoreException {
		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			ontModel.read(path);
			 */
			
			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");

			AnnotationProperty annotationPropertyIcon = ontModel.getAnnotationProperty(IRI + "#" + "icon");
			AnnotationProperty shape = ontModel.getAnnotationProperty(IRI + "#" + "shape");
			AnnotationProperty annotationPropertyScreenMode = ontModel
					.createAnnotationProperty(IRI + "#" + "screenMode");
			AnnotationProperty annotationPropertyImageAddress = ontModel
					.getAnnotationProperty(IRI + "#" + "imageAddress");
			// 20221129
			AnnotationProperty annotationPropertyUnfoldDirection = ontModel
					.getAnnotationProperty(IRI + "#" + "UnfoldDirection");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

			ObjectProperty languageIncludingObject = ontModel.getObjectProperty(IRI + "#" + "languageIncludingObject");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder metaObjectFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					metaObjectFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAOBJECT_ZH);
				} else {
					metaObjectFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAOBJECT);
				}
				try {
					metaObjectFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = metaObjectFolder.getLocation().toOSString();

				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingObject)) {
						OntClass ontMetaObject = (OntClass) equivalentClass.asRestriction()
								.asSomeValuesFromRestriction().getSomeValuesFrom();
						String metaObjectName = ontMetaObject.getLocalName();

						FileWriter writer = new FileWriter(location + "/" + metaObjectName + ".karma");

						MetaObject metaObject = new MetaObject();
						metaObject.setId(metaObjectName);
						metaObject.setLocalLabel(ontMetaObject.getPropertyValue(localLabel).toString());
						if (ontMetaObject.getPropertyValue(description) != null) {
							metaObject.setDescription(ontMetaObject.getPropertyValue(description).toString());
						}
						if (ontMetaObject.getPropertyValue(annotationPropertyIcon) != null) {
							metaObject.setIconPath(ontMetaObject.getPropertyValue(annotationPropertyIcon).toString());
						}
						metaObject.setObjectShape(ontMetaObject.getPropertyValue(shape).toString());
						metaObject.setMode(VisualizedMode
								.fromValue(ontMetaObject.getPropertyValue(annotationPropertyScreenMode).toString()));

						// 20220606加
						if (ontMetaObject.getPropertyValue(annotationPropertyImageAddress) != null) {
							metaObject.setImage(
									ontMetaObject.getPropertyValue(annotationPropertyImageAddress).toString());
						}

						//
						// 20221129UnfoldDirection
						if (ontMetaObject.getPropertyValue(annotationPropertyUnfoldDirection) != null && ontMetaObject
								.getPropertyValue(annotationPropertyUnfoldDirection).toString().equals("X")) {
							metaObject.setDirection(Direction.X);
						}
						if (ontMetaObject.getPropertyValue(annotationPropertyUnfoldDirection) != null && ontMetaObject
								.getPropertyValue(annotationPropertyUnfoldDirection).toString().equals("Y")) {
							metaObject.setDirection(Direction.Y);
						}

						// 对象元模型属性
						for (Iterator object_it = ontMetaObject.listEquivalentClasses(); object_it.hasNext();) {
							OntClass c2 = (OntClass) object_it.next();
							Restriction r2 = c2.asRestriction();
							// some对象元模型属性
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaObjectProperty = (OntClass) sr2.getSomeValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaObjectProperty.getLocalName(), false,
										propertyMap.get(metaObjectProperty.getSuperClass().getLocalName()),
										metaObjectProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaObjectProperty.getLocalName(), propertyRef);
								metaObject.addProperty(propertyRef);
							}
							// all对象元模型属性
							if (r2.isAllValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
								OntClass metaObjectProperty = (OntClass) sr2.getAllValuesFrom();
								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaObjectProperty.getLocalName(), true,
										propertyMap.get(metaObjectProperty.getSuperClass().getLocalName()),
										metaObjectProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaObjectProperty.getLocalName(), propertyRef);
								metaObject.addProperty(propertyRef);
							}

							// 对象元模型上点
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("linkObjectAndPoint")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaObjectClass = (OntClass) sr2.getSomeValuesFrom();
								if (metaObjectClass.isIntersectionClass()) {
									PointTypeReferenceDirection pointDir = PointTypeReferenceDirection.INPUT;
									OntClass metaObjectPoint = null;
									for (Iterator and = metaObjectClass.asIntersectionClass().listOperands(); and
											.hasNext();) {
										OntClass and_class = (OntClass) and.next();
										if (!and_class.isRestriction()) {
											metaObjectPoint = and_class;
										} else {
											String inout = and_class.asRestriction().asHasValueRestriction()
													.getHasValue().toString();
											if (inout.equals("输出") || inout.equals("Output")) {
												pointDir = PointTypeReferenceDirection.OUTPUT;
											}
											if (inout.equals("输入") || inout.equals("Input")) {
												pointDir = PointTypeReferenceDirection.INPUT;
											}
											if (inout.equals("无向") || inout.equals("Undirected")) {
												pointDir = PointTypeReferenceDirection.UNDIRECTED;
											}
										}
									}
									MetaPointTypeReference pointReference = new MetaPointTypeReference(
											metaObjectPoint.getLocalName(), pointDir,
											pointMap.get(metaObjectPoint.getSuperClass().getLocalName()),
											metaObjectPoint.getPropertyValue(localLabel).toString());
									metaObject.addPoint(pointReference);

									pointReferenceMap.put(metaObjectPoint.getLocalName(), pointReference);

								}
							}

						}
						objectMap.put(metaObjectName, metaObject);
						writer.write(KarmaMetaModeWrite.getSingle().visitObject(metaObject));
						writer.flush();
						writer.close();
						IFile metaObjectFile = metaObjectFolder.getFile(metaObjectName + ".karma");
						metaObjectFile.refreshLocal(IResource.DEPTH_ZERO, null);
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 生成MetaRelationship对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MDTKarmaVisitorException
	 */
	public void generateMetaRelationship(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, MDTKarmaVisitorException, CoreException {
		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			System.out.println(" path:" + path);
			ontModel.read(path);
			 */
			
			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
			AnnotationProperty annotationPropertyIcon = ontModel.getAnnotationProperty(IRI + "#" + "icon");
			AnnotationProperty shape = ontModel.getAnnotationProperty(IRI + "#" + "shape");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

			ObjectProperty languageIncludingRelationship = ontModel
					.getObjectProperty(IRI + "#" + "languageIncludingRelationship");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder metaRelationshipFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					metaRelationshipFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METARELATIONSHIP_ZH);
				} else {
					metaRelationshipFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METARELATIONSHIP);
				}
				try {
					metaRelationshipFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = metaRelationshipFolder.getLocation().toOSString();

				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingRelationship)) {
						OntClass ontMetaRelationship = (OntClass) equivalentClass.asRestriction()
								.asSomeValuesFromRestriction().getSomeValuesFrom();
						String metaRelationshipName = ontMetaRelationship.getLocalName();

						FileWriter writer = new FileWriter(location + "/" + metaRelationshipName + ".karma");

						MetaRelationship metaRelationship = new MetaRelationship();
						metaRelationship.setId(metaRelationshipName);
						metaRelationship.setLocalLabel(ontMetaRelationship.getPropertyValue(localLabel).toString());
						if (ontMetaRelationship.getPropertyValue(description) != null) {
							metaRelationship
									.setDescription(ontMetaRelationship.getPropertyValue(description).toString());
						}
						metaRelationship.setRelationshipShape(ontMetaRelationship.getPropertyValue(shape).toString());
						if (ontMetaRelationship.getPropertyValue(annotationPropertyIcon) != null) {
							metaRelationship.setIconPath(
									ontMetaRelationship.getPropertyValue(annotationPropertyIcon).toString());
							System.out.println(ontMetaRelationship.getPropertyValue(annotationPropertyIcon).toString());
						}

						// 关系元模型属性和角色
						for (Iterator relationship_it = ontMetaRelationship.listEquivalentClasses(); relationship_it
								.hasNext();) {
							OntClass c2 = (OntClass) relationship_it.next();
							Restriction r2 = c2.asRestriction();
							// some关系元模型属性
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaRelationshipProperty = (OntClass) sr2.getSomeValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaRelationshipProperty.getLocalName(), false,
										propertyMap.get(metaRelationshipProperty.getSuperClass().getLocalName()),
										metaRelationshipProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaRelationshipProperty.getLocalName(), propertyRef);
								metaRelationship.addProperty(propertyRef);

							}
							// all关系元模型属性
							if (r2.isAllValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
								OntClass metaRelationshipProperty = (OntClass) sr2.getAllValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaRelationshipProperty.getLocalName(), true,
										propertyMap.get(metaRelationshipProperty.getSuperClass().getLocalName()),
										metaRelationshipProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaRelationshipProperty.getLocalName(), propertyRef);
								metaRelationship.addProperty(propertyRef);
							}
							// 关系元模型角色
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("linkRelationshipAndRole")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaRelationshipRole = (OntClass) sr2.getSomeValuesFrom();
								metaRelationship.addRole(roleMap.get(metaRelationshipRole.getLocalName()));
							}
						}
						relationshipMap.put(metaRelationshipName, metaRelationship);
						writer.write(KarmaMetaModeWrite.getSingle().visitRelationship(metaRelationship));
						writer.flush();
						writer.close();
						IFile metaRelationshipFile = metaRelationshipFolder.getFile(metaRelationshipName + ".karma");
						metaRelationshipFile.refreshLocal(IResource.DEPTH_ZERO, null);
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 生成MetaGraph对象
	 * 
	 * @param owlFilePath
	 * @param languagesFolder
	 * @param monitor
	 * @throws IOException
	 * @throws CoreException
	 * @throws MdtException
	 * @throws MDTKarmaVisitorException
	 */
	public void generateMetaGraph(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MdtException, MDTKarmaVisitorException {

		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			System.out.println(" path:" + path);
			ontModel.read(path);
			 */
			

			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
			AnnotationProperty annotationPropertyType = ontModel.getAnnotationProperty(IRI + "#" + "type");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");
			ObjectProperty languageIncludingGraph = ontModel.getObjectProperty(IRI + "#" + "languageIncludingGraph");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder metaGraphFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					metaGraphFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAGRAPH_ZH);
				} else {
					metaGraphFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_METAGRAPH);
				}
				try {
					metaGraphFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = metaGraphFolder.getLocation().toOSString();

				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingGraph)) {
						OntClass ontMetaGraph = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
								.getSomeValuesFrom();
						String metaGraphName = ontMetaGraph.getLocalName();

						FileWriter writer = new FileWriter(location + "/" + metaGraphName + ".karma");

						MetaGraph metaGraph = graphMap.get(metaGraphName);//20240103对应修改
						if(graphMap.get(metaGraphName) == null) {
							metaGraph = new MetaGraph();
							metaGraph.setId(metaGraphName);
						}

						metaGraph.setLocalLabel(ontMetaGraph.getPropertyValue(localLabel).toString());
						if (ontMetaGraph.hasProperty(annotationPropertyType)) {
							metaGraph.setType(GraphType
									.fromValue(ontMetaGraph.getPropertyValue(annotationPropertyType).toString()));
						}
						if (ontMetaGraph.getPropertyValue(description) != null)
							metaGraph.setDescription(ontMetaGraph.getPropertyValue(description).toString());

						// 图元模型ORP
						OntClass metaGraphConnector = null;
						for (Iterator graph_it = ontMetaGraph.listEquivalentClasses(); graph_it.hasNext();) {
							OntClass c2 = (OntClass) graph_it.next();
							Restriction r2 = c2.asRestriction();
							// some图元模型属性
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaGraphProperty = (OntClass) sr2.getSomeValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaGraphProperty.getLocalName(), false,
										propertyMap.get(metaGraphProperty.getSuperClass().getLocalName()),
										metaGraphProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaGraphProperty.getLocalName(), propertyRef);
								metaGraph.addProperty(propertyRef);

							}
							
							//20240103 add
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("extend")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass owlExtendedMetaGraph = (OntClass) sr2.getSomeValuesFrom();
								String id_ExtendedMetaGraph = owlExtendedMetaGraph.getLocalName();
								MetaGraph extendedMetaGraph;
								extendedMetaGraph = graphMap.get(id_ExtendedMetaGraph);
								if(graphMap.get(id_ExtendedMetaGraph) == null) {
									extendedMetaGraph = new MetaGraph();
									extendedMetaGraph.setId(id_ExtendedMetaGraph);
								}
								metaGraph.addExtend(extendedMetaGraph);
							}
							
							// all图元模型属性
							if (r2.isAllValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("hasProperty")) {
								AllValuesFromRestriction sr2 = r2.asAllValuesFromRestriction();
								OntClass metaGraphProperty = (OntClass) sr2.getAllValuesFrom();

								MetaPropertyTypeReference propertyRef = new MetaPropertyTypeReference(
										metaGraphProperty.getLocalName(), true,
										propertyMap.get(metaGraphProperty.getSuperClass().getLocalName()),
										metaGraphProperty.getPropertyValue(localLabel).toString());
								propertyReferenceMap.put(metaGraphProperty.getLocalName(), propertyRef);
								metaGraph.addProperty(propertyRef);

							}
							// 图元模型对象
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("graphIncludingObject")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaGraphObject = (OntClass) sr2.getSomeValuesFrom();
								metaGraph.addObject(objectMap.get(metaGraphObject.getLocalName()));
							}
							// 图元模型关系
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("graphIncludingRelationship")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								OntClass metaGraphRelationship = (OntClass) sr2.getSomeValuesFrom();
								metaGraph.addRelationship(relationshipMap.get(metaGraphRelationship.getLocalName()));
								// res.append(" Relationship " + MetaGraph_i_ORR_j.getLocalName() + ";\n");
							}
							// 找到图元模型Constraint
							if (r2.isSomeValuesFromRestriction()
									&& r2.getOnProperty().getLocalName().equals("graphIncludingConnector")) {
								SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
								metaGraphConnector = (OntClass) sr2.getSomeValuesFrom();
							}
						}

						// 图元模型Constraint
						if (metaGraphConnector != null) {
							for (Iterator connector_i = metaGraphConnector.listEquivalentClasses(); connector_i
									.hasNext();) {
								OntClass c3 = (OntClass) connector_i.next();
								// 设置链接
								if (c3.isIntersectionClass()) {
									String connector_object = null;
									String connector_point = null;
									String connector_role = null;
									String connector_relationship = null;
									for (Iterator and_i = c3.asIntersectionClass().listOperands(); and_i.hasNext();) {
										OntClass and_one = (OntClass) and_i.next();
										if (and_one.isRestriction()) {
											OntClass c4 = (OntClass) and_one.asRestriction()
													.asSomeValuesFromRestriction().getSomeValuesFrom();
											if (c4.getSuperClass().getLocalName().equals("Role"))
												connector_role = c4.getLocalName();
											if (c4.getSuperClass().getLocalName().equals("Object"))
												connector_object = c4.getLocalName();
//											if (c4.getSuperClass().hasSuperClass()) //问题所在处 ，BFO与GOPPRRE的结构不同
//												connector_point = c4.getLocalName();
											if (c4.getSuperClass().hasSuperClass() && c4.getSuperClass().getSuperClass()
													.getLocalName().equals("Point")) {
												connector_point = c4.getLocalName();
											}
											if (c4.getSuperClass().getLocalName().equals("Relationship"))
												connector_relationship = c4.getLocalName();
										}
									}
									if (connector_point == null) {
										metaGraph.addBinding(connector_relationship + "." + connector_role,
												connector_object);
									} else {
										metaGraph.addBinding(connector_relationship + "." + connector_role,
												connector_object + "." + connector_point);
									}
								}
								// 设置分解剖视
								if (c3.isRestriction()) {
									Restriction c4 = c3.asRestriction();
									String DorE = null;// 记录是分解还是剖视(D or E)
									String DorE_object = null;// 记录分解剖视的对象
									String DorE_graph = null;// 记录分解剖视的图
									if (((OntClass) c4.asSomeValuesFromRestriction().getSomeValuesFrom())
											.isIntersectionClass()) {
										for (Iterator c4_i = ((OntClass) c4.asSomeValuesFromRestriction()
												.getSomeValuesFrom()).asIntersectionClass().listOperands(); c4_i
														.hasNext();) {
											OntClass c4_i_c = (OntClass) c4_i.next();
											if (c4_i_c.isRestriction()) {
												Restriction c4_i_r = c4_i_c.asRestriction();
												if (c4_i_r.isSomeValuesFromRestriction())// 针对对象的等价类：对象拥有点
												{
													DorE = c4_i_r.getOnProperty().getLocalName();
													DorE_graph = c4_i_r.asSomeValuesFromRestriction()
															.getSomeValuesFrom().getLocalName();
												}

											} else {
												DorE_object = c4_i_c.getLocalName();
											}
										}
									}
									if (DorE.equals("explode")) {
										metaGraph.addExplode(DorE_object, DorE_graph);
									} else if (DorE.equals("decompose")) {
										metaGraph.addDecomposite(DorE_object, DorE_graph);
									}
								}
							}

						}
						graphMap.put(metaGraphName, metaGraph);
						writer.write(KarmaMetaModeWrite.getSingle().visitGraph(metaGraph));
						writer.flush();
						writer.close();
						IFile metaGraphFile = metaGraphFolder.getFile(metaGraphName + ".karma");
						metaGraphFile.refreshLocal(IResource.DEPTH_ZERO, null);

					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void generateModel(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {

		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			System.out.println(" path:" + path);
			ontModel.read(path);
			 */
			
			String IRI = "http://www.zkhoneycomb.com/formats/metagInOwl";
			AnnotationProperty tableType = ontModel.getAnnotationProperty(IRI + "#" + "tableType");
			AnnotationProperty localLabel = ontModel.getAnnotationProperty(IRI + "#" + "localLabel");
			AnnotationProperty description = ontModel.getAnnotationProperty(IRI + "#" + "description");
			AnnotationProperty iconAddress = ontModel.getAnnotationProperty(IRI + "#" + "iconAddress");
			AnnotationProperty shape = ontModel.getAnnotationProperty(IRI + "#" + "shape");
			AnnotationProperty annotationPropertyColor = ontModel.createAnnotationProperty(IRI + "#" + "color");
			AnnotationProperty screenMode = ontModel.getAnnotationProperty(IRI + "#" + "screenMode");
			AnnotationProperty imageAddress = ontModel.getAnnotationProperty(IRI + "#" + "imageAddress");
			AnnotationProperty lableDisplay = ontModel.getAnnotationProperty(IRI + "#" + "lableDisplay");
			AnnotationProperty initialLocation = ontModel.getAnnotationProperty(IRI + "#" + "initialLocation");
			AnnotationProperty annotationPropertyLayerLocation = ontModel
					.createAnnotationProperty(IRI + "#" + "layerLocation");
			AnnotationProperty annotationPropertyPolyLineLocation = ontModel
					.createAnnotationProperty(IRI + "#" + "polyLineLocation");
			AnnotationProperty startLocation = ontModel.createAnnotationProperty(IRI + "#" + "startLocation");
			AnnotationProperty endLocation = ontModel.createAnnotationProperty(IRI + "#" + "endLocation");
			AnnotationProperty annotationPropertyCifString = ontModel.createAnnotationProperty(IRI + "#" + "cifString");
			AnnotationProperty annotationPropertyStyle = ontModel.createAnnotationProperty(IRI + "#" + "style");
			AnnotationProperty annotationPropertyInitial = ontModel.createAnnotationProperty(IRI + "#" + "initial");
			AnnotationProperty annotationPropertyType = ontModel.createAnnotationProperty(IRI + "#" + "type");
			AnnotationProperty annotationPropertyModelSize = ontModel.createAnnotationProperty(IRI + "#" + "modelSize");
			AnnotationProperty annotationPropertySmoothness = ontModel
					.createAnnotationProperty(IRI + "#" + "smoothness");
			AnnotationProperty annotationPropertyJumpLinkStatus = ontModel
					.createAnnotationProperty(IRI + "#" + "jumpLinkStatus");
			AnnotationProperty annotationPropertyJumpLinkType = ontModel
					.createAnnotationProperty(IRI + "#" + "jumpLinkType");
			AnnotationProperty annotationPropertyJumpReverse = ontModel
					.createAnnotationProperty(IRI + "#" + "reverseJumpLink");
			AnnotationProperty annotationPropertyAvoidObstructionsRouting = ontModel
					.createAnnotationProperty(IRI + "#" + "avoidObstructionsRouting");
			AnnotationProperty annotationPropertyClosestDistanceRouting = ontModel
					.createAnnotationProperty(IRI + "#" + "closestDistanceRouting");
			AnnotationProperty annotationPropertyText = ontModel.createAnnotationProperty(IRI + "#" + "text");
			AnnotationProperty annotationPropertyIconDisplay = ontModel
					.createAnnotationProperty(IRI + "#" + "iconDisplay");
			AnnotationProperty annotationPropertyFrameSize = ontModel.getAnnotationProperty(IRI + "#" + "frameSize");
			AnnotationProperty annotationPropertyLineType = ontModel.getAnnotationProperty(IRI + "#" + "linetype");
			AnnotationProperty annotationPropertySdIdentification = ontModel
					.getAnnotationProperty(IRI + "#" + "SdIdentification");
			AnnotationProperty annotationPropertyQueue = ontModel.createAnnotationProperty(IRI + "#" + "queue");
			AnnotationProperty annotationPropertyRoutingType = ontModel
					.getAnnotationProperty(IRI + "#" + "routingType");
			//
			AnnotationProperty annotationPropertyStrikethrough = ontModel
					.getAnnotationProperty(IRI + "#" + "strikeThrough");
			AnnotationProperty annotationPropertyUnderline = ontModel.getAnnotationProperty(IRI + "#" + "underline");
			AnnotationProperty annotationPropertyVisualizationList = ontModel
					.createAnnotationProperty(IRI + "#" + "VisualizationList");

			ObjectProperty decomposeProp = ontModel.createObjectProperty(IRI + "#" + "decompose");
			ObjectProperty explodeProp = ontModel.createObjectProperty(IRI + "#" + "explode");
			ObjectProperty hasPropertyProp = ontModel.createObjectProperty(IRI + "#" + "hasProperty");

			OntClass language = ontModel.getOntClass(IRI + "#" + "Language");

			ObjectProperty languageIncludingGraph = ontModel.getObjectProperty(IRI + "#" + "languageIncludingGraph");
			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder modelFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					modelFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
				} else {
					modelFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_MODEL);
				}
				try {
					modelFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = modelFolder.getLocation().toOSString();
				// 0610加
				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingGraph)) {
						OntClass ontMetaGraph = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
								.getSomeValuesFrom();
						for (Iterator il2 = ontMetaGraph.listInstances(); il2.hasNext();) {
							Individual karmaModel = (Individual) il2.next();
							String karmaModelName = karmaModel.getLocalName();

							FileWriter writer = new FileWriter(location + "/" + karmaModelName + ".karma");

							Model model = new Model(graphMap.get(ontMetaGraph.getLocalName()));
							model.setId(karmaModelName);
							model.setLocalLabel(karmaModel.getPropertyValue(localLabel).toString());
							if (karmaModel.hasProperty(annotationPropertyCifString)) {
								model.setCifString(karmaModel.getPropertyValue(annotationPropertyCifString).toString()
										.replace("\\\"", "\""));
							}
							modelMap.put(karmaModelName, model);
						}
					}
				}

				//
				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingGraph)) {
						OntClass ontMetaGraph = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
								.getSomeValuesFrom();
						for (Iterator il2 = ontMetaGraph.listInstances(); il2.hasNext();) {
							Individual karmaModel = (Individual) il2.next();
							String karmaModelName = karmaModel.getLocalName();

							FileWriter writer = new FileWriter(location + "/" + karmaModelName + ".karma");
							Model model = modelMap.get(karmaModel.getLocalName());
							model.setId(karmaModelName);
							model.setLocalLabel(karmaModel.getPropertyValue(localLabel).toString());
							if (karmaModel.hasProperty(annotationPropertyCifString)) {
								model.setCifString(karmaModel.getPropertyValue(annotationPropertyCifString).toString()
										.replace("\\\"", "\""));
							}
							System.out.println("====model:" + model.getId());
							String a = KarmaModeWrite.getSigle().visitModel(model);

							// 图属性
							for (Iterator ig = karmaModel.listProperties(); ig.hasNext();) {
								Statement igs = (Statement) ig.next();
								// 添加属性及属性值
								if (igs.getPredicate().getLocalName().equals("hasProperty")) {
									// 找到属性实例
									Individual graphProperty = ontModel.getIndividual(igs.getResource().getURI());
									// 找到属性值
									String graphPropertyValue = "";
									for (Iterator igp = graphProperty.listProperties(); igp.hasNext();) {
										Statement igps = (Statement) igp.next();
										if (igps.getPredicate().getLocalName().equals("value")) {
											graphPropertyValue = igps.getString();
										}
									}
//									
//									model.addProperty(
//											new PropertyTypeReference(graphProperty.getLocalName(), graphPropertyValue,
//													propertyReferenceMap
//															.get(graphProperty.getOntClass().getLocalName()),
//													graphProperty.getPropertyValue(localLabel).toString()));
									// 20230927补充图属性
									PropertyTypeReference p = new PropertyTypeReference(graphProperty.getLocalName(),
											graphPropertyValue,
											propertyReferenceMap.get(graphProperty.getOntClass().getLocalName()),
											graphProperty.getPropertyValue(localLabel).toString());
									// 0629
									if (graphProperty.hasProperty(annotationPropertyColor)) {
										p.setColor(graphProperty.getPropertyValue(annotationPropertyColor).toString());
									}
									if (graphProperty.hasProperty(annotationPropertyText)) {
										String[] texts = graphProperty.getPropertyValue(annotationPropertyText)
												.toString().split(",");
										Text text = new Text();
										text.setFont(texts[0]);
										text.setSize(Integer.parseInt(texts[1]));
										text.setBold(Bold.fromValue(texts[2]));
										text.setItalic(Italic.fromValue(texts[3]));
										p.setProText(text);
									}
									if (graphProperty.getPropertyValue(annotationPropertyUnderline) != null) {
										p.setUnderline(Boolean.valueOf(graphProperty
												.getPropertyValue(annotationPropertyUnderline).toString()));
									}
									if (graphProperty.getPropertyValue(annotationPropertyStrikethrough) != null) {
										p.setStrikeThrough(Boolean.valueOf(graphProperty
												.getPropertyValue(annotationPropertyStrikethrough).toString()));
									}

									//
									for (Iterator igp2 = graphProperty.listProperties(); igp2.hasNext();) {
										Statement igps2 = (Statement) igp2.next();
										if (igps2.getPredicate().getLocalName().equals("cloneProperty")) {
											Individual graph_property_clone_Individual = ontModel
													.getIndividual(igps2.getResource().getURI());
											String graph_property_clone = graph_property_clone_Individual
													.getLocalName();
											p.setSystemNameClone(graph_property_clone);
										}
									}
									model.addProperty(p);
									System.out.println("====modelProperty:" + graphProperty.getLocalName());
								}

							}
							// 图对象
							for (Iterator ig = karmaModel.listProperties(); ig.hasNext();) {
								Statement igs = (Statement) ig.next();
								// 添加对象实例
								if (igs.getPredicate().getLocalName().equals("graphIncludingObject")) {
									// 找到对象实例
									Individual graph_object_Individual = ontModel
											.getIndividual(igs.getResource().getURI());
									GraphObject graphObject = new GraphObject(
											objectMap.get(graph_object_Individual.getOntClass().getLocalName()));
									graphObject.setId(graph_object_Individual.getLocalName());
									// initialLocation
									String[] locations = graph_object_Individual.getPropertyValue(initialLocation)
											.toString().split(",");
									InitialLocation loca = new InitialLocation(Integer.parseInt(locations[0]),
											Integer.parseInt(locations[1]), Integer.parseInt(locations[2]),
											Integer.parseInt(locations[3]));
									graphObject.setLocation(loca);
									// localLabel
									graphObject.setLocalLabel(
											graph_object_Individual.getPropertyValue(localLabel).toString());
									// shape
									graphObject.setObjectShape(ObjectShape
											.fromValue(graph_object_Individual.getPropertyValue(shape).toString()));
									// color
									if (graph_object_Individual.hasProperty(annotationPropertyColor)) {
										graphObject.setColor(graph_object_Individual
												.getPropertyValue(annotationPropertyColor).toString());
									}

									// screenMode
									graphObject.setObjectMode(ScreenMode.fromValue(
											graph_object_Individual.getPropertyValue(screenMode).toString()));
									// imageAddress
									if (graph_object_Individual.hasProperty(imageAddress)) {
										graphObject.setImage(
												graph_object_Individual.getPropertyValue(imageAddress).toString());
									}
									// SDIdentification
									if (graph_object_Individual.hasProperty(annotationPropertySdIdentification)) {
										graphObject.setSdIdentification(graph_object_Individual
												.getPropertyValue(annotationPropertySdIdentification).toString());
									}
									// text
									if (graph_object_Individual.hasProperty(annotationPropertyText)) {
										String[] texts = graph_object_Individual
												.getPropertyValue(annotationPropertyText).toString().split(",");
										Text text = new Text();
										text.setFont(texts[0]);
										System.out.println(texts[0]);
										System.out.println(Integer.parseInt(texts[1]));
										text.setSize(Integer.parseInt(texts[1]));
										text.setBold(Bold.fromValue(texts[2]));
										text.setItalic(Italic.fromValue(texts[3]));
										graphObject.setText(text);
									}
									// iconDisplay
									if (graph_object_Individual.hasProperty(annotationPropertyIconDisplay)) {
										graphObject.setIconDisplay("true".equals(graph_object_Individual
												.getPropertyValue(annotationPropertyIconDisplay).toString()));
									}
									// frame
									if (graph_object_Individual.hasProperty(annotationPropertyLineType)) {
										graphObject.setLinetype(graph_object_Individual
												.getPropertyValue(annotationPropertyLineType).toString());
									}
									if (graph_object_Individual.hasProperty(annotationPropertyFrameSize)) {
										graphObject.setFrameSize(Integer.parseInt(graph_object_Individual
												.getPropertyValue(annotationPropertyFrameSize).toString()));
									}
									// visualizationList
									if (graph_object_Individual.hasProperty(annotationPropertyVisualizationList)) {
										graphObject.setVisualizationList(graph_object_Individual
												.getPropertyValue(annotationPropertyVisualizationList).toString());
									}

									graphObject.setLayerLocation(Integer.parseInt(graph_object_Individual
											.getPropertyValue(annotationPropertyLayerLocation).toString()));
									if (graph_object_Individual.hasProperty(annotationPropertyCifString)) {
										graphObject.setCifString(
												graph_object_Individual.getPropertyValue(annotationPropertyCifString)
														.toString().replace("\\\"", "\""));
									}
									if (graph_object_Individual.hasProperty(annotationPropertyStyle)) {
										graphObject.setStyle(graph_object_Individual
												.getPropertyValue(annotationPropertyStyle).toString());
									}
									if (graph_object_Individual.hasProperty(annotationPropertyInitial)) {
										graphObject.setInitial(graph_object_Individual
												.getPropertyValue(annotationPropertyInitial).toString());
									}
									if (graph_object_Individual.hasProperty(annotationPropertyType)) {
										graphObject.setType(graph_object_Individual
												.getPropertyValue(annotationPropertyType).toString());
									}

									// 对象实例属性
									for (Iterator igp = graph_object_Individual.listProperties(); igp.hasNext();) {
										Statement igps = (Statement) igp.next();
										if (igps.getPredicate().getLocalName().equals("hasProperty")) {
											// 找到对象实例属性
											Individual object_property_Individual = ontModel
													.getIndividual(igps.getResource().getURI());
											// 找到属性值
											String object_property_Individual_value = "";
											for (Iterator igp2 = object_property_Individual.listProperties(); igp2
													.hasNext();) {
												Statement igps2 = (Statement) igp2.next();
												if (igps2.getPredicate().getLocalName().equals("value")) {
													object_property_Individual_value = igps2.getString();
												}
											}
											PropertyTypeReference p = new PropertyTypeReference(
													object_property_Individual.getLocalName(),
													object_property_Individual_value,
													propertyReferenceMap.get(
															object_property_Individual.getOntClass().getLocalName()),
													object_property_Individual.getPropertyValue(localLabel).toString());
											// 0629
											if (object_property_Individual.hasProperty(annotationPropertyColor)) {
												p.setColor(object_property_Individual
														.getPropertyValue(annotationPropertyColor).toString());
											}
											if (object_property_Individual.hasProperty(annotationPropertyText)) {
												String[] texts = object_property_Individual
														.getPropertyValue(annotationPropertyText).toString().split(",");
												Text text = new Text();
												text.setFont(texts[0]);
												text.setSize(Integer.parseInt(texts[1]));
												text.setBold(Bold.fromValue(texts[2]));
												text.setItalic(Italic.fromValue(texts[3]));
												p.setProText(text);
											}
											if (object_property_Individual
													.getPropertyValue(annotationPropertyUnderline) != null) {
												p.setUnderline(Boolean.valueOf(object_property_Individual
														.getPropertyValue(annotationPropertyUnderline).toString()));
											}
											if (object_property_Individual
													.getPropertyValue(annotationPropertyStrikethrough) != null) {
												p.setStrikeThrough(Boolean.valueOf(object_property_Individual
														.getPropertyValue(annotationPropertyStrikethrough).toString()));
											}

											//
											for (Iterator igp2 = object_property_Individual.listProperties(); igp2
													.hasNext();) {
												Statement igps2 = (Statement) igp2.next();
												if (igps2.getPredicate().getLocalName().equals("cloneProperty")) {
													Individual object_property_clone_Individual = ontModel
															.getIndividual(igps2.getResource().getURI());
													String object_property_clone = object_property_clone_Individual
															.getLocalName();
													p.setSystemNameClone(object_property_clone);
												}
											}
											graphObject.addProperty(p);

										}
									}

									// 加0608 对象分解剖视克隆
									for (Iterator It1 = graph_object_Individual.listProperties(); It1.hasNext();) {
										Statement graph_object_IndividualPro = (Statement) It1.next();
										if (graph_object_IndividualPro.getPredicate().getLocalName()
												.equals("explode")) {
											Individual explodeIndi = ontModel
													.getIndividual(graph_object_IndividualPro.getResource().getURI());
											Model explodeModel = modelMap.get(explodeIndi.getLocalName());
											graphObject.addExplosionModel(explodeModel);
										}
										if (graph_object_IndividualPro.getPredicate().getLocalName()
												.equals("decompose")) {
											Individual decomposeIndi = ontModel
													.getIndividual(graph_object_IndividualPro.getResource().getURI());
											Model decomposeModel = modelMap.get(decomposeIndi.getLocalName());
											graphObject.addDecompositionModel(decomposeModel);
										}
										if (graph_object_IndividualPro.getPredicate().getLocalName()
												.equals("cloneModel")) {
											Individual cloneModelIndi = ontModel
													.getIndividual(graph_object_IndividualPro.getResource().getURI());
											graphObject.setCloneModel(cloneModelIndi.getLocalName());
										}
										if (graph_object_IndividualPro.getPredicate().getLocalName()
												.equals("cloneObject")) {
											Individual clonObjectIndi = ontModel
													.getIndividual(graph_object_IndividualPro.getResource().getURI());
											graphObject.setCloneObject(clonObjectIndi.getLocalName());
										}
									}

									System.out.println("====test03:" + graphObject.getId());
									// 对象实例点
									for (Iterator igp = graph_object_Individual.listProperties(); igp.hasNext();) {
										Statement igps = (Statement) igp.next();
										if (igps.getPredicate().getLocalName().equals("linkObjectAndPoint")) {
											// 点实例
											Individual point_Individual = ontModel
													.getIndividual(igps.getResource().getURI());
											Point point = new Point(pointReferenceMap
													.get(point_Individual.getOntClass().getLocalName()));
											point.setId(point_Individual.getLocalName());
											System.out.println("====test04:" + point.getId());
											point.setLocalLabel(
													point_Individual.getPropertyValue(localLabel).toString());
											String[] locations2 = point_Individual.getPropertyValue(initialLocation)
													.toString().split(",");
											point.setPointX(Integer.parseInt(locations2[0]));
											point.setPointY(Integer.parseInt(locations2[1]));
											point.setSizeX(Integer.parseInt(locations2[2]));
											point.setSizeY(Integer.parseInt(locations2[3]));
											System.out.println(Integer.parseInt(locations2[0]));
											// point.setObject(graphObject);
											// point.setPointModel(aPointModel);
											point.setPointShape(PointShape
													.fromValue(point_Individual.getPropertyValue(shape).toString()));
											point.setColor(point_Individual.getPropertyValue(annotationPropertyColor)
													.toString());
											if (point_Individual.hasProperty(annotationPropertyText)) {
												String[] texts = point_Individual
														.getPropertyValue(annotationPropertyText).toString().split(",");
												Text text = new Text();
												text.setFont(texts[0]);
												text.setSize(Integer.parseInt(texts[1]));
												text.setBold(Bold.fromValue(texts[2]));
												text.setItalic(Italic.fromValue(texts[3]));
												point.setText(text);
											}
											point.setIconDisplay("true".equals(
													point_Individual.getPropertyValue(lableDisplay).toString()));

											point.setLabelDisplay("true".equals(
													point_Individual.getPropertyValue(lableDisplay).toString()));
											// 20230927加
											point.setImage(point_Individual.getPropertyValue(imageAddress).toString());// imageAddress
											// 点实例属性
											for (Iterator igp2 = point_Individual.listProperties(); igp2.hasNext();) {
												Statement igps2 = (Statement) igp2.next();
												if (igps2.getPredicate().getLocalName().equals("hasProperty")) {
													// 找到点实例属性
													Individual point_property_Individual = ontModel
															.getIndividual(igps2.getResource().getURI());
													// 找到属性值
													String point_property_Individual_value = "";
													for (Iterator igp3 = point_property_Individual
															.listProperties(); igp3.hasNext();) {
														Statement igps3 = (Statement) igp3.next();
														if (igps3.getPredicate().getLocalName().equals("value")) {
															point_property_Individual_value = igps3.getString();
														}
													}
//													point.addProperty(new PropertyTypeReference(
//															point_property_Individual.getLocalName(),
//															point_property_Individual_value,
//															propertyReferenceMap.get(point_property_Individual
//																	.getOntClass().getLocalName()),
//															point_property_Individual.getPropertyValue(localLabel)
//																	.toString()));
													//20230927补充点属性
													PropertyTypeReference p = new PropertyTypeReference(point_property_Individual.getLocalName(),
															point_property_Individual_value,
															propertyReferenceMap.get(point_property_Individual.getOntClass().getLocalName()),
															point_property_Individual.getPropertyValue(localLabel).toString());
													// 0629
													if (point_property_Individual.hasProperty(annotationPropertyColor)) {
														p.setColor(point_property_Individual.getPropertyValue(annotationPropertyColor).toString());
													}
													if (point_property_Individual.hasProperty(annotationPropertyText)) {
														String[] texts = point_property_Individual.getPropertyValue(annotationPropertyText)
																.toString().split(",");
														Text text = new Text();
														text.setFont(texts[0]);
														text.setSize(Integer.parseInt(texts[1]));
														text.setBold(Bold.fromValue(texts[2]));
														text.setItalic(Italic.fromValue(texts[3]));
														p.setProText(text);
													}
													if (point_property_Individual.getPropertyValue(annotationPropertyUnderline) != null) {
														p.setUnderline(Boolean.valueOf(point_property_Individual
																.getPropertyValue(annotationPropertyUnderline).toString()));
													}
													if (point_property_Individual.getPropertyValue(annotationPropertyStrikethrough) != null) {
														p.setStrikeThrough(Boolean.valueOf(point_property_Individual
																.getPropertyValue(annotationPropertyStrikethrough).toString()));
													}

													//
													for (Iterator igp4 = point_property_Individual.listProperties(); igp4.hasNext();) {
														Statement igps4 = (Statement) igp4.next();
														if (igps4.getPredicate().getLocalName().equals("cloneProperty")) {
															Individual point_property_clone_Individual = ontModel
																	.getIndividual(igps4.getResource().getURI());
															String point_property_clone = point_property_clone_Individual
																	.getLocalName();
															p.setSystemNameClone(point_property_clone);
														}
													}
													point.addProperty(p);

												}
												if (igps2.getPredicate().getLocalName().equals("clonePoint")) {
													Individual clonePointIndi = ontModel
															.getIndividual(igps2.getResource().getURI());
													point.setClonePoint(clonePointIndi.getLocalName());
												}

											}

											graphObject.addPoint(point);

										}
									}

									// 对象实例annotation
									model.addObjects(graphObject);
									System.out.println("====modelObject:" + graphObject.getId());
								}
							}

							// 图关系
							Map<Integer, Relationship> relaMap = new HashMap<>();
							for (Iterator ig = karmaModel.listProperties(); ig.hasNext();) {
								Statement igs = (Statement) ig.next();
								// 添加关系实例
								if (igs.getPredicate().getLocalName().equals("graphIncludingRelationship")) {
									// 找到关系实例
									Individual graph_rela_Individual = ontModel
											.getIndividual(igs.getResource().getURI());
									Role fromRole = null;
									Role toRole = null;
									// 关系实例角色
									for (Iterator igp = graph_rela_Individual.listProperties(); igp.hasNext();) {
										Statement igps = (Statement) igp.next();
										if (igps.getPredicate().getLocalName().equals("linkRelationshipAndRole")) {
											// 角色实例
											Individual role_Individual = ontModel
													.getIndividual(igps.getResource().getURI());

											MetaRole metaRole = roleMap
													.get(role_Individual.getOntClass().getLocalName());
											Role role = null;
											if (RoleDirection.FROM.equals(metaRole.getDirection())) {
												fromRole = new Role(
														roleMap.get(role_Individual.getOntClass().getLocalName()));
												role = fromRole;
											} else if (RoleDirection.TO.equals(metaRole.getDirection())) {
												toRole = new Role(
														roleMap.get(role_Individual.getOntClass().getLocalName()));
												role = toRole;
											}
											role.setId(role_Individual.getLocalName());
											role.setLocalLabel(role_Individual.getPropertyValue(localLabel).toString());
											role.setRoleShape(RoleShape
													.fromValue(role_Individual.getPropertyValue(shape).toString()));
											System.out.println("====modelRole:" + role.getId());

											// 角色实例属性
											for (Iterator igp2 = role_Individual.listProperties(); igp2.hasNext();) {
												Statement igps2 = (Statement) igp2.next();
												if (igps2.getPredicate().getLocalName().equals("hasProperty")) {
													// 找到角色实例属性
													Individual role_property_Individual = ontModel
															.getIndividual(igps2.getResource().getURI());
													// 找到属性值
													String role_property_Individual_value = "";
													for (Iterator igp3 = role_property_Individual.listProperties(); igp3
															.hasNext();) {
														Statement igps3 = (Statement) igp3.next();
														if (igps3.getPredicate().getLocalName().equals("value")) {
															role_property_Individual_value = igps3.getString();
														}
													}
//													role.addProperty(new PropertyTypeReference(
//															role_property_Individual.getLocalName(),
//															role_property_Individual_value,
//															propertyReferenceMap.get(role_property_Individual
//																	.getOntClass().getLocalName()),
//															role_property_Individual.getPropertyValue(localLabel)
//																	.toString()));
													//20230927补充角色属性
													PropertyTypeReference p = new PropertyTypeReference(role_property_Individual.getLocalName(),
															role_property_Individual_value,
															propertyReferenceMap.get(role_property_Individual.getOntClass().getLocalName()),
															role_property_Individual.getPropertyValue(localLabel).toString());
													// 0629
													if (role_property_Individual.hasProperty(annotationPropertyColor)) {
														p.setColor(role_property_Individual.getPropertyValue(annotationPropertyColor).toString());
													}
													if (role_property_Individual.hasProperty(annotationPropertyText)) {
														String[] texts = role_property_Individual.getPropertyValue(annotationPropertyText)
																.toString().split(",");
														Text text = new Text();
														text.setFont(texts[0]);
														text.setSize(Integer.parseInt(texts[1]));
														text.setBold(Bold.fromValue(texts[2]));
														text.setItalic(Italic.fromValue(texts[3]));
														p.setProText(text);
													}
													if (role_property_Individual.getPropertyValue(annotationPropertyUnderline) != null) {
														p.setUnderline(Boolean.valueOf(role_property_Individual
																.getPropertyValue(annotationPropertyUnderline).toString()));
													}
													if (role_property_Individual.getPropertyValue(annotationPropertyStrikethrough) != null) {
														p.setStrikeThrough(Boolean.valueOf(role_property_Individual
																.getPropertyValue(annotationPropertyStrikethrough).toString()));
													}

													//
													for (Iterator igp4 = role_property_Individual.listProperties(); igp4.hasNext();) {
														Statement igps4 = (Statement) igp4.next();
														if (igps4.getPredicate().getLocalName().equals("cloneProperty")) {
															Individual role_property_clone_Individual = ontModel
																	.getIndividual(igps4.getResource().getURI());
															String role_property_clone = role_property_clone_Individual
																	.getLocalName();
															p.setSystemNameClone(role_property_clone);
														}
													}
													role.addProperty(p);
												}
											}
										}
									}
									Relationship relationship = new Relationship(
											relationshipMap.get(graph_rela_Individual.getOntClass().getLocalName()),
											fromRole, toRole);

									relationship.setId(graph_rela_Individual.getLocalName());
									relationship.setLocalLabel(
											graph_rela_Individual.getPropertyValue(localLabel).toString());
									relationship.setRelationshipShape(RelationshipShape
											.fromValue(graph_rela_Individual.getPropertyValue(shape).toString()));
									String[] starts = graph_rela_Individual.getPropertyValue(startLocation).toString()
											.split(",");
									relationship.setStartX(Integer.parseInt(starts[0]));
									relationship.setStartY(Integer.parseInt(starts[1]));

									String[] ends = graph_rela_Individual.getPropertyValue(endLocation).toString()
											.split(",");
									relationship.setEndX(Integer.parseInt(ends[0]));
									relationship.setEndY(Integer.parseInt(ends[1]));
									if (graph_rela_Individual.hasProperty(annotationPropertyPolyLineLocation)) {
										relationship.setPolyline(graph_rela_Individual
												.getPropertyValue(annotationPropertyPolyLineLocation).toString());
									}
									if (graph_rela_Individual.hasProperty(annotationPropertyColor)) {
										relationship.setColor(graph_rela_Individual
												.getPropertyValue(annotationPropertyColor).toString());
									}
									relationship.setLabelDisplay("true"
											.equals(graph_rela_Individual.getPropertyValue(lableDisplay).toString()));
									if (graph_rela_Individual.hasProperty(annotationPropertyText)) {
										String[] texts = graph_rela_Individual.getPropertyValue(annotationPropertyText)
												.toString().split(",");
										Text text = new Text();
										text.setFont(texts[0]);
										text.setSize(Integer.parseInt(texts[1]));
										text.setBold(Bold.fromValue(texts[2]));
										text.setItalic(Italic.fromValue(texts[3]));
										relationship.setText(text);
									}
									if (graph_rela_Individual.hasProperty(annotationPropertySdIdentification)) {
										relationship.setSdIdentification(graph_rela_Individual
												.getPropertyValue(annotationPropertySdIdentification).toString());
									}
									if (graph_rela_Individual.hasProperty(annotationPropertySmoothness)) {
										relationship.setSmooth(graph_rela_Individual
												.getPropertyValue(annotationPropertySmoothness).toString());
									}
									// 20220218
									if (graph_rela_Individual
											.getPropertyValue(annotationPropertyAvoidObstructionsRouting).toString()
											.equals("true")) {
										relationship.setAvoidObstructions(true);
									} else {
										relationship.setAvoidObstructions(false);
									}
									if (graph_rela_Individual.getPropertyValue(annotationPropertyClosestDistanceRouting)
											.toString().equals("true")) {
										relationship.setClosestDistance(true);
									} else {
										relationship.setClosestDistance(false);
									}
									if (graph_rela_Individual.hasProperty(annotationPropertyJumpLinkStatus)) {
										relationship.setJumpStatus(graph_rela_Individual
												.getPropertyValue(annotationPropertyJumpLinkStatus).toString());
									}
									if (graph_rela_Individual.hasProperty(annotationPropertyJumpLinkType)) {
										relationship.setJumpType(graph_rela_Individual
												.getPropertyValue(annotationPropertyJumpLinkType).toString());
									}
									if (graph_rela_Individual.getPropertyValue(annotationPropertyJumpReverse).toString()
											.equals("true")) {
										relationship.setReverse(true);
									} else {
										relationship.setReverse(false);
									}
									if (graph_rela_Individual.hasProperty(annotationPropertyRoutingType)) {
										relationship.setRoutingTpye(graph_rela_Individual
												.getPropertyValue(annotationPropertyRoutingType).toString());
									}
									
									if (graph_rela_Individual.hasProperty(annotationPropertyCifString)) {
										relationship.setCifString(
												graph_rela_Individual.getPropertyValue(annotationPropertyCifString)
														.toString().replace("\\\"", "\""));
									}
									
									relationship.setSize(Integer.parseInt(graph_rela_Individual
											.getPropertyValue(annotationPropertyModelSize).toString()));
//									System.out.println("====modelRelationship:" + relationship.getId());

									// 关系实例属性
									for (Iterator igp = graph_rela_Individual.listProperties(); igp.hasNext();) {
										Statement igps = (Statement) igp.next();
										if (igps.getPredicate().getLocalName().equals("hasProperty")) {
											// 找到对象实例属性
											Individual rela_property_Individual = ontModel
													.getIndividual(igps.getResource().getURI());
											// 找到属性值
											String rela_property_Individual_value = "";
											for (Iterator igp2 = rela_property_Individual.listProperties(); igp2
													.hasNext();) {
												Statement igps2 = (Statement) igp2.next();
												if (igps2.getPredicate().getLocalName().equals("value")) {
													rela_property_Individual_value = igps2.getString();
												}
											}
											relationship.addProperty(new PropertyTypeReference(
													rela_property_Individual.getLocalName(),
													rela_property_Individual_value,
													propertyReferenceMap
															.get(rela_property_Individual.getOntClass().getLocalName()),
													rela_property_Individual.getPropertyValue(localLabel).toString()));
											
											//20230927补充关系属性
											PropertyTypeReference p = new PropertyTypeReference(rela_property_Individual.getLocalName(),
													rela_property_Individual_value,
													propertyReferenceMap.get(rela_property_Individual.getOntClass().getLocalName()),
													rela_property_Individual.getPropertyValue(localLabel).toString());
											// 0629
											if (rela_property_Individual.hasProperty(annotationPropertyColor)) {
												p.setColor(rela_property_Individual.getPropertyValue(annotationPropertyColor).toString());
											}
											if (rela_property_Individual.hasProperty(annotationPropertyText)) {
												String[] texts = rela_property_Individual.getPropertyValue(annotationPropertyText)
														.toString().split(",");
												Text text = new Text();
												text.setFont(texts[0]);
												text.setSize(Integer.parseInt(texts[1]));
												text.setBold(Bold.fromValue(texts[2]));
												text.setItalic(Italic.fromValue(texts[3]));
												p.setProText(text);
											}
											if (rela_property_Individual.getPropertyValue(annotationPropertyUnderline) != null) {
												p.setUnderline(Boolean.valueOf(rela_property_Individual
														.getPropertyValue(annotationPropertyUnderline).toString()));
											}
											if (rela_property_Individual.getPropertyValue(annotationPropertyStrikethrough) != null) {
												p.setStrikeThrough(Boolean.valueOf(rela_property_Individual
														.getPropertyValue(annotationPropertyStrikethrough).toString()));
											}

											//
											for (Iterator igp3 = rela_property_Individual.listProperties(); igp3.hasNext();) {
												Statement igps3 = (Statement) igp3.next();
												if (igps3.getPredicate().getLocalName().equals("cloneProperty")) {
													Individual rela_property_clone_Individual = ontModel
															.getIndividual(igps3.getResource().getURI());
													String rela_property_clone = rela_property_clone_Individual
															.getLocalName();
													p.setSystemNameClone(rela_property_clone);
												}
											}
											relationship.addProperty(p);
										}
									}
//									System.out.println("====modelRelationship:" + relationship.getId());
									if (ontMetaGraph.hasProperty(annotationPropertyType)
											&& GraphType.SEQUENCEDIAGRAM.toString().equals(
													ontMetaGraph.getPropertyValue(annotationPropertyType).toString())) {
										relaMap.put(
												Integer.parseInt(graph_rela_Individual
														.getPropertyValue(annotationPropertyQueue).toString()),
												relationship);
									} else {
										model.addRelationship(relationship);
									}

								}
							}
							if (!relaMap.isEmpty()) {
								int n = relaMap.size();
								for (int i = 0; i < n; i++) {
									model.addRelationship(relaMap.get(i));
								}
							}
							// E扩展
							for (Iterator ig = karmaModel.listProperties(); ig.hasNext();) {
								Statement igs = (Statement) ig.next();
								// 添加connector实例
								if (igs.getPredicate().getLocalName().equals("graphIncludingConnector")) {
									// 找到connector实例
									Individual connetor_Individual = ontModel.getIndividual(igs.getResource().getURI());
									String connectPoint = null;
									String connectObject = null;
									String connectRelationship = null;
									String connectRole = null;
									for (Iterator igp = connetor_Individual.listProperties(); igp.hasNext();) {
										Statement igps = (Statement) igp.next();
										if (igps.getPredicate().getLocalName().equals("linkFromRelationship")) {
											connectRelationship = igps.getResource().getLocalName();
											System.out.println(connectRelationship);
										} else if (igps.getPredicate().getLocalName()
												.equals("linkRelationshipAndRole")) {
											connectRole = igps.getResource().getLocalName();
											System.out.println(connectRole);
										} else if (igps.getPredicate().getLocalName().equals("linkToObject")) {
											connectObject = igps.getResource().getLocalName();
											System.out.println(connectObject);
										} else if (igps.getPredicate().getLocalName().equals("linkObjectAndPoint")) {
											connectPoint = igps.getResource().getLocalName();
											System.out.println(connectPoint);
										}
									}
									if (connectPoint == null) {
										try {
											model.addBinding(connectRelationship + "." + connectRole, connectObject);
											System.out.println(
													connectObject + "," + connectRelationship + "." + connectRole);
											System.out.println(model);
										} catch (MdtException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									} else {
										try {
											model.addBinding(connectRelationship + "." + connectRole,
													connectObject + "." + connectPoint);
										} catch (MdtException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}

								}
							}
							// 0713加
							// 图 插件
							for (Iterator ig = karmaModel.listProperties(); ig.hasNext();) {
								Statement igs = (Statement) ig.next();
								// 添加插件实例
								if (igs.getPredicate().getLocalName().equals("graphIncludingPlugin")) {
									OntClass owlSwimLaneClass = ontModel.getOntClass(IRI + "#" + "SwimLane");
									OntClass owlMatrixClass = ontModel.getOntClass(IRI + "#" + "Matrix");
									OntClass owlSysMLClass = ontModel.getOntClass(IRI + "#" + "SysMLDrawingComponent");
									OntClass owlGanttClass = ontModel.getOntClass(IRI + "#" + "Gantt");
									OntClass owlGanttElementClass = ontModel.getOntClass(IRI + "#" + "GanttElement");
									OntClass owlGanttTaskClass = ontModel.getOntClass(IRI + "#" + "GanttTask");

									AnnotationProperty annotationPropertyMatrix = ontModel
											.getAnnotationProperty(IRI + "#" + "matrix");

									AnnotationProperty annotationPropertyModelElementName = ontModel
											.getAnnotationProperty(IRI + "#" + "modelElementName");
									AnnotationProperty annotationPropertyModelElementType = ontModel
											.getAnnotationProperty(IRI + "#" + "modelElementType");
									AnnotationProperty annotationPropertyDiagramKind = ontModel
											.getAnnotationProperty(IRI + "#" + "diagramKind");
									AnnotationProperty annotationPropertyTime = ontModel
											.getAnnotationProperty(IRI + "#" + "time");
									AnnotationProperty annotationPropertylStartLocation = ontModel
											.getAnnotationProperty(IRI + "#" + "startLocation");
									// 找到插件实例
									Individual graph_PluginIndividual = ontModel
											.getIndividual(igs.getResource().getURI());
									// 判断插件实例属于哪个类
									// SwimLane
									if (graph_PluginIndividual.getOntClass().equals(owlSwimLaneClass)) {
										SwimLane swimLane = new SwimLane();
										swimLane.setId(graph_PluginIndividual.getLocalName());
										swimLane.setLocalLabel(
												graph_PluginIndividual.getPropertyValue(localLabel).toString());
										swimLane.setColor(graph_PluginIndividual
												.getPropertyValue(annotationPropertyColor).toString());
										String[] starts = graph_PluginIndividual.getPropertyValue(startLocation)
												.toString().split(",");
										String[] modelSize = graph_PluginIndividual
												.getPropertyValue(annotationPropertyModelSize).toString().split(",");
										InitialLocation matrixLocation = new InitialLocation(
												Integer.parseInt(starts[0]), Integer.parseInt(starts[1]),
												Integer.parseInt(modelSize[0]), Integer.parseInt(modelSize[1]));
										swimLane.setLocation(matrixLocation);
										model.addSwimLane(swimLane);
									}
									System.out.println("===图模型swimlane成功===");
									// Matrix
									if (graph_PluginIndividual.getOntClass().equals(owlMatrixClass)) {
										Matrix matrix = new Matrix();
										matrix.setId(graph_PluginIndividual.getLocalName());
										if (graph_PluginIndividual.getPropertyValue(tableType) != null) {
											matrix.setType(
													graph_PluginIndividual.getPropertyValue(tableType).toString());// 加tableType
										} else {
											matrix.setType("");
										}
										matrix.setLocalLabel(
												graph_PluginIndividual.getPropertyValue(localLabel).toString());

										String[] starts = graph_PluginIndividual.getPropertyValue(startLocation)
												.toString().split(",");
										String[] modelSize = graph_PluginIndividual
												.getPropertyValue(annotationPropertyModelSize).toString().split(",");
										InitialLocation matrixLocation = new InitialLocation(
												Integer.parseInt(starts[0]), Integer.parseInt(starts[1]),
												Integer.parseInt(modelSize[0]), Integer.parseInt(modelSize[1]));
										matrix.setLocation(matrixLocation);
										matrix.setValue(graph_PluginIndividual
												.getPropertyValue(annotationPropertyMatrix).toString());
										
										if (graph_PluginIndividual.hasProperty(imageAddress)) {
											matrix.setImage(
													graph_PluginIndividual.getPropertyValue(imageAddress).toString());
										}
										if (graph_PluginIndividual.hasProperty(hasPropertyProp)) {
											Individual owlMatrixProperty = ontModel
													.getIndividual(IRI + "#" + graph_PluginIndividual
															.getPropertyValue(hasPropertyProp).toString());
											PropertyTypeReference p = new PropertyTypeReference(
													owlMatrixProperty.getLocalName(), "",
													propertyReferenceMap
															.get(owlMatrixProperty.getOntClass().getLocalName()),
													owlMatrixProperty.getPropertyValue(localLabel).toString());
											matrix.setProperty(p);

										}

//										matrix.setImage(a);
//										if(graph_PluginIndividual.hasProperty(annotationPropertyCifString)) {
//											relationship.setCifString(graph_rela_Individual.getPropertyValue(annotationPropertyCifString).toString());
//										}

										model.addMatrix(matrix);
									}
									System.out.println("===图模型matrix成功===");
									// SysML
									if (graph_PluginIndividual.getOntClass().equals(owlSysMLClass)) {
										Layout sysml = new Layout();
										sysml.setId(graph_PluginIndividual.getLocalName());
										sysml.setLocalLabel(
												graph_PluginIndividual.getPropertyValue(localLabel).toString());

										sysml.setDiagramKind(SysMLDiagramKind.fromValue(graph_PluginIndividual
												.getPropertyValue(annotationPropertyDiagramKind).toString()));

										sysml.setElementType(SysMLModelElementType.fromValue(graph_PluginIndividual
												.getPropertyValue(annotationPropertyModelElementType).toString()));

										sysml.setModelElementName(graph_PluginIndividual
												.getPropertyValue(annotationPropertyModelElementName).toString());
										String[] starts = graph_PluginIndividual.getPropertyValue(startLocation)
												.toString().split(",");
										String[] modelSize = graph_PluginIndividual
												.getPropertyValue(annotationPropertyModelSize).toString().split(",");
										InitialLocation sysmlLocation = new InitialLocation(Integer.parseInt(starts[0]),
												Integer.parseInt(starts[1]), Integer.parseInt(modelSize[0]),
												Integer.parseInt(modelSize[1]));
										sysml.setLocation(sysmlLocation);
										if (graph_PluginIndividual.hasProperty(imageAddress)) {
											sysml.setImage(
													graph_PluginIndividual.getPropertyValue(imageAddress).toString());
										}
										if (graph_PluginIndividual.hasProperty(annotationPropertyColor)) {
											sysml.setColor(graph_PluginIndividual
													.getPropertyValue(annotationPropertyColor).toString());
										}

										if (graph_PluginIndividual.hasProperty(annotationPropertyText)) {
											String[] texts = graph_PluginIndividual
													.getPropertyValue(annotationPropertyText).toString().split(",");
											Text text = new Text();
											text.setFont(texts[0]);
											text.setSize(Integer.parseInt(texts[1]));
											text.setBold(Bold.fromValue(texts[2]));
											text.setItalic(Italic.fromValue(texts[3]));
											sysml.setProText(text);
										}
										
										model.addSysMLOutsideFrame(sysml);
									}
									System.out.println("===图模型sysml成功===");
									// Gatt
									if (graph_PluginIndividual.getOntClass().equals(owlGanttClass)) {
										Gantt gantt = new Gantt();
										gantt.setId(graph_PluginIndividual.getLocalName());

										gantt.setLocalLabel(
												graph_PluginIndividual.getPropertyValue(localLabel).toString());
										String[] starts = graph_PluginIndividual.getPropertyValue(startLocation)
												.toString().split(",");
										String[] modelSize = graph_PluginIndividual
												.getPropertyValue(annotationPropertyModelSize).toString().split(",");
										InitialLocation matrixLocation = new InitialLocation(
												Integer.parseInt(starts[0]), Integer.parseInt(starts[1]),
												Integer.parseInt(modelSize[0]), Integer.parseInt(modelSize[1]));
										gantt.setLocation(matrixLocation);// Location
										String[] time = graph_PluginIndividual.getPropertyValue(annotationPropertyTime)
												.toString().split(";");
										gantt.setTime(GanttTimeList.fromValue(time[0]));// Time
										gantt.setTimeUnit(Integer.parseInt(time[1]));// TimeUnit
										gantt.setStartTime(Integer.parseInt(time[2]));// StartTime
										gantt.setEndTime(Integer.parseInt(time[3]));// EndTime
										
										if (graph_PluginIndividual.hasProperty(annotationPropertyColor)) {
											gantt.setColor(graph_PluginIndividual
													.getPropertyValue(annotationPropertyColor).toString());// Color
										}

										// gantt Task
										for (Iterator igt = graph_PluginIndividual.listProperties(); igt.hasNext();) {
											Statement igts = (Statement) igt.next();
											// 添加插件实例
											if (igts.getPredicate().getLocalName().equals("pluginIncludingTask")) {
												// 找到插件实例
												Individual ganttTaskIndividual = ontModel
														.getIndividual(igts.getResource().getURI());
												// 判断插件实例属于哪个类
												if (ganttTaskIndividual.getOntClass().equals(owlGanttTaskClass)) {
													ArrayList<GanttTaskElement> elements = new ArrayList();

													for (Iterator ige = ganttTaskIndividual.listProperties(); ige
															.hasNext();) {
														Statement iges = (Statement) ige.next();
														// 添加ganttElement实例
														if (iges.getPredicate().getLocalName()
																.equals("taskIncludingElement")) {
															// 找到ganttElement实例
															Individual ganttElementIndividual = ontModel
																	.getIndividual(iges.getResource().getURI());
															// 判断ganttElement实例属于哪个类

															if (ganttElementIndividual.getOntClass()
																	.equals(owlGanttElementClass)) {
																GanttTaskElement ganttElement = new GanttTaskElement(
																		ganttElementIndividual.getLocalName(),
																		ganttElementIndividual
																				.getPropertyValue(localLabel)
																				.toString(),
																		Integer.parseInt(ganttElementIndividual
																				.getPropertyValue(
																						annotationPropertylStartLocation)
																				.toString()),
																		Integer.parseInt(ganttElementIndividual
																				.getPropertyValue(
																						annotationPropertyModelSize)
																				.toString()),
																		ganttElementIndividual
																				.getPropertyValue(
																						annotationPropertyColor)
																				.toString());
																System.out.println(ganttElementIndividual);

																ganttElement
																		.setId(ganttElementIndividual.getLocalName());
																ganttElement.setLocalName(ganttElementIndividual
																		.getPropertyValue(localLabel).toString());
																ganttElement.setElementColor(ganttElementIndividual
																		.getPropertyValue(annotationPropertyColor)
																		.toString());
																ganttElement.setElementLength(
																		Integer.parseInt(ganttElementIndividual
																				.getPropertyValue(
																						annotationPropertyModelSize)
																				.toString()));
																ganttElement.setElementOffset(Integer.parseInt(
																		ganttElementIndividual.getPropertyValue(
																				annotationPropertylStartLocation)
																				.toString()));
																elements.add(ganttElement);
//																System.out.println(ganttTask.getLocalName());
//																ganttTask.addElement(ganttElement);
															}
														}
													}

													GanttTask ganttTask = new GanttTask(
															ganttTaskIndividual.getLocalName().substring(
																	ganttTaskIndividual.getLocalName().indexOf(".")
																			+ 1),
															elements);
													System.out.println(ganttTaskIndividual);
													ganttTask.setLocalName(ganttTaskIndividual.getLocalName().substring(
															ganttTaskIndividual.getLocalName().indexOf(".") + 1));

													gantt.addtask(ganttTask);

												}
											}
										}

										model.addGantt(gantt);
									}
									System.out.println("===图模型gantt成功===");
								}
							}

							//

//							modelMap.put(karmaModelName, model);
							String content = KarmaModeWrite.getSigle().visitModel(model);
							System.out.println(karmaModelName + " end1");
							writer.write(content);
							writer.close();

							IFile modelFile = modelFolder.getFile(karmaModelName + ".karma");
							modelFile.refreshLocal(IResource.DEPTH_ZERO, null);
						}

					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void generatePackages(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException, MDTKarmaVisitorException {

		try {
			/* 输入为OntModel,所以注释掉此处 edited by xiaodu
			OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
			String path = owlFilePath;
			System.out.println(" path:" + path);
			ontModel.read(path);
			 */
			
			String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";

			AnnotationProperty localLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
			OntClass language = ontModel.getOntClass(METAG + "Language");

			ObjectProperty languageIncludingPackages = ontModel.getObjectProperty(METAG + "languageIncludingPackages");
			ObjectProperty hasModelProp = ontModel.createObjectProperty(METAG + "hasModel");
			ObjectProperty hasPackageProp = ontModel.createObjectProperty(METAG + "hasPackage");

			for (ExtendedIterator<OntClass> it = language.listSubClasses(); it.hasNext();) {
				OntClass ontLanguage = it.next();
				String ontLanguageName = ontLanguage.getLocalName();
				if (ontLanguage.getPropertyValue(localLabel) != null) {
					ontLanguageName = ontLanguage.getPropertyValue(localLabel).toString();
				}
				IFolder ontLanguageFolder = languagesFolder.getFolder(ontLanguageName);

				IFolder packagesFolder;
				final String nl = Platform.getNL();
				if (nl != null && nl.equals("zh_CN")) {
					packagesFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_PACKAGES_ZH);
				} else {
					packagesFolder = ontLanguageFolder.getFolder(PackagePath.TYPE_PACKAGES);
				}
				try {
					packagesFolder.create(true, true, monitor);
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String location = packagesFolder.getLocation().toOSString();
				for (ExtendedIterator<OntClass> it2 = ontLanguage.listEquivalentClasses(); it2.hasNext();) {
					OntClass equivalentClass = it2.next();
					if (equivalentClass.asRestriction().getOnProperty().equals(languageIncludingPackages)) {
						OntClass ontPackages = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
								.getSomeValuesFrom();
						String packagesClassName = ontPackages.getLocalName();// 这里名字是类的名字，在生成的时候我在类的名字后面加了后缀“Class”
						String packagesName = packagesClassName.substring(0, packagesClassName.length() - 5);

						Individual owlPackage = ontModel.getIndividual(METAG + packagesName);
						PackagesImport packages = traversePackages(owlPackage, ontModel);
						BufferedWriter writer = new BufferedWriter(
								new FileWriter(location + "/" + packagesName + ".karma"));
						System.out.println(location + "/" + packagesName + ".karma");
						try {
							String content = KarmaPackagesWrite.getSigle().visitPackages(packages, 1);
							System.out.println(content);
							writer.write(content);
							writer.close();

							IFile packagesFile = packagesFolder.getFile(packagesName + ".karma");
							packagesFile.refreshLocal(IResource.DEPTH_ZERO, null);
						} catch (MDTKarmaVisitorException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private PackagesImport traversePackages(Individual indi, OntModel ontModel) {
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";

		AnnotationProperty annotationPropertyExternal_plugin = ontModel
				.getAnnotationProperty(METAG + "External_plugin");
		AnnotationProperty localLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationPropertyType = ontModel.getAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPropertyExternal_plugin_resource = ontModel
				.getAnnotationProperty(METAG + "External_plugin_resource");

		PackagesImport pImport = new PackagesImport();
		// Import
		for (Iterator it = indi.listProperties(); it.hasNext();) {
			Statement its = (Statement) it.next();
			if (its.getPredicate().getLocalName().equals("hasImport")) {
				Individual hasImportIndi = ontModel.getIndividual(its.getResource().getURI());
				ImportPackage importp = new ImportPackage();
				importp.setId(hasImportIndi.getPropertyValue(annotationPropertyExternal_plugin).toString());
				importp.setLocalLabel(hasImportIndi.getPropertyValue(localLabel).toString());
				importp.setType(hasImportIndi.getPropertyValue(annotationPropertyType).toString());
				importp.setResource(
						hasImportIndi.getPropertyValue(annotationPropertyExternal_plugin_resource).toString());
				pImport.addImports(importp);
			}
		}

		Packages p = new Packages();
		p.setId(indi.getLocalName());
		p.setLocalLabel(indi.getPropertyValue(localLabel).toString());

		for (Iterator it = indi.listProperties(); it.hasNext();) {
			Statement its = (Statement) it.next();
			if (its.getPredicate().getLocalName().equals("hasModel")) {
				Individual modelIndi = ontModel.getIndividual(its.getResource().getURI());
				Model model = modelMap.get(modelIndi.getLocalName());
				p.addModels(model);
			}
			if (its.getPredicate().getLocalName().equals("hasPackage")) {
				Individual packageIndi = ontModel.getIndividual(its.getResource().getURI());
				Packages p2 = traverseImportPackages(packageIndi, ontModel);
				p.addPackages(p2);
			}
		}
		pImport.setPackages(p);
		return pImport;
	}

	private Packages traverseImportPackages(Individual indi, OntModel ontModel) {
		String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";

		AnnotationProperty annotationPropertyExternal_plugin = ontModel
				.getAnnotationProperty(METAG + "External_plugin");
		AnnotationProperty localLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationPropertyType = ontModel.getAnnotationProperty(METAG + "type");
		AnnotationProperty annotationPropertyExternal_plugin_resource = ontModel
				.getAnnotationProperty(METAG + "External_plugin_resource");

		Packages p = new Packages();
		p.setId(indi.getLocalName());
		p.setLocalLabel(indi.getPropertyValue(localLabel).toString());

		for (Iterator it = indi.listProperties(); it.hasNext();) {
			Statement its = (Statement) it.next();
			if (its.getPredicate().getLocalName().equals("import")) {
				Individual importIndi = ontModel.getIndividual(its.getResource().getURI());
				ExternalPlugin externalPlugin = new ExternalPlugin();
				externalPlugin.setId(importIndi.getLocalName());
				externalPlugin.setLocalLabel(importIndi.getPropertyValue(localLabel).toString());
				p.addExternalPlugin(externalPlugin);
			}
		}
		for (Iterator it = indi.listProperties(); it.hasNext();) {
			Statement its = (Statement) it.next();
			if (its.getPredicate().getLocalName().equals("hasModel")) {
				Individual modelIndi = ontModel.getIndividual(its.getResource().getURI());
				Model model = modelMap.get(modelIndi.getLocalName());
				p.addModels(model);
			}
			if (its.getPredicate().getLocalName().equals("hasPackage")) {
				Individual packageIndi = ontModel.getIndividual(its.getResource().getURI());
				Packages p2 = traverseImportPackages(packageIndi, ontModel);
				p.addPackages(p2);
			}
		}
		return p;
	}
}
