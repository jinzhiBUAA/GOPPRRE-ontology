package org.fc.mdt.owl.owl2Karma;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Statement;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;
import org.fc.mdt.owl.port.messages.Messages;

public class Owl2DSM {
	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
	
	/**
	 * 读取owl文件
	 * @author xiaodu
	 * @param owlFilePath
	 */
	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}
	
	/**
	 * 生成DSM的方法重载
	 * @author xiaodu
	 * */
	public static void GenerateDSM(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException {
		OntModel ontModel = readOwlFile(owlFilePath);
		GenerateDSM(ontModel, languagesFolder, monitor);
	}

	public static void GenerateDSM(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */

		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);
		
		// 获取类
		OntClass owlDSMClass = ontModel.getOntClass(METAG + "DSM");
		OntClass owlReqIFModelElementClass = ontModel.getOntClass(METAG + "ReqIF_Model_Element");
		OntClass owlKarmaModelElementClass = ontModel.getOntClass(METAG + "KARMA_Model_Element");

		// 获取AnnotationProperty
		AnnotationProperty annotationProIdentifier = ontModel.getAnnotationProperty(METAG + "identifier");
		AnnotationProperty annotationProName = ontModel.getAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationPropertyModelLocation = ontModel.getAnnotationProperty(METAG + "modelLocation");
		AnnotationProperty annotationProlocalLabel = ontModel.getAnnotationProperty(METAG + "localLabel");
		
		AnnotationProperty annotationProDSM_Element_Id = ontModel.getAnnotationProperty(METAG + "DSM_Element_id");
		AnnotationProperty annotationProModel_Id = ontModel.getAnnotationProperty(METAG + "model_id");
		AnnotationProperty annotationProMeta_Model = ontModel.getAnnotationProperty(METAG + "meta_model");
		AnnotationProperty annotationProText = ontModel.getAnnotationProperty(METAG + "text");
		AnnotationProperty annotationProMeta_Property_Instance_Id = ontModel
						.getAnnotationProperty(METAG + "meta_property_instance_id");
		AnnotationProperty annotationProMeta_Property_Instance_Type = ontModel
						.getAnnotationProperty(METAG + "meta_property_instance_type");
		AnnotationProperty annotationProMeta_Property_Instance_Text = ontModel
						.getAnnotationProperty(METAG + "meta_property_instance_text");

		// 获取ObjectProperty
		
		ObjectProperty objectProCopy = ontModel.getObjectProperty(METAG + Messages.getValue("copy"));
		ObjectProperty objectProTrace = ontModel.getObjectProperty(METAG + Messages.getValue("trace"));
		ObjectProperty objectProSatisfy = ontModel.getObjectProperty(METAG + Messages.getValue("satisfy"));
		ObjectProperty objectProVerify = ontModel.getObjectProperty(METAG + Messages.getValue("verify"));
		ObjectProperty objectProRefine = ontModel.getObjectProperty(METAG + Messages.getValue("refine"));
		ObjectProperty objectProDerive = ontModel.getObjectProperty(METAG + Messages.getValue("derive"));
		ObjectProperty objectProCompose = ontModel.getObjectProperty(METAG + Messages.getValue("compose"));
		ObjectProperty objectProContain = ontModel.getObjectProperty(METAG + Messages.getValue("contain"));
		ObjectProperty objectProDSM_Ref_ReqIF = ontModel.getObjectProperty(METAG + "DSM_Ref_ReqIF");
		ObjectProperty objectProDSM_Ref_KARMA = ontModel.getObjectProperty(METAG + "DSM_Ref_KARMA");
		ObjectProperty objectProEqual = ontModel.getObjectProperty(METAG + "equal_to");

		// 一个dsm individual是一个dsm文件
		for (Iterator itd = owlDSMClass.listInstances(); itd.hasNext();) {
			Individual owlDSMIndividual = (Individual) itd.next();
			// 生成DSM前期
			Document document = DocumentHelper.createDocument();
			Element KARMA_external_plugin = document.addElement("KARMA_external_plugin");
			Element Table = KARMA_external_plugin.addElement("Table");
			String tableName = owlDSMIndividual.getPropertyValue(annotationProName).toString();
			Table.addAttribute("Name", tableName);
			String localLabel = owlDSMIndividual.getPropertyValue(annotationProlocalLabel).toString();
			Table.addAttribute("localLabel", localLabel);
			Element theHeader = Table.addElement("THE-HEADER");

			List<Individual> relationshipIndividual = new ArrayList<Individual>();
			for (Iterator it = owlDSMIndividual.listProperties(); it.hasNext();) {
				Statement owlDSMIndividualPro = (Statement) it.next();
				if (owlDSMIndividualPro.getPredicate().getLocalName().equals("DSM_Ref_ReqIF")) {
					Individual owlReqIFModelElement = ontModel
							.getIndividual(owlDSMIndividualPro.getResource().getURI());
					relationshipIndividual.add(owlReqIFModelElement);
					String name = owlReqIFModelElement.getPropertyValue(annotationProName).toString();
					String dsm_Element_id = owlReqIFModelElement.getPropertyValue(annotationProDSM_Element_Id).toString();
					String text = owlReqIFModelElement.getPropertyValue(annotationProText).toString();
					
					Element rowHeader = theHeader.addElement("ROW-HEADER");
					rowHeader.addAttribute("Name", name);
					rowHeader.addAttribute("DSM_Element_id", dsm_Element_id);
					rowHeader.setText(text);
					Element columnHeader = theHeader.addElement("COLUMN-HEADER");
					columnHeader.addAttribute("Name", name);
					columnHeader.addAttribute("DSM_Element_id", dsm_Element_id);
					columnHeader.setText(text);
				}
				else if (owlDSMIndividualPro.getPredicate().getLocalName().equals("DSM_Ref_KARMA")) {
					Individual owlKARMAModelElement = ontModel
							.getIndividual(owlDSMIndividualPro.getResource().getURI());
					relationshipIndividual.add(owlKARMAModelElement);
					String name = owlKARMAModelElement.getPropertyValue(annotationProName).toString();
					String dsm_Element_id = owlKARMAModelElement.getPropertyValue(annotationProDSM_Element_Id).toString();
					String text = owlKARMAModelElement.getPropertyValue(annotationProText).toString();
					
					Element rowHeader = theHeader.addElement("ROW-HEADER");
					rowHeader.addAttribute("Name", name);
					rowHeader.addAttribute("DSM_Element_id", dsm_Element_id);
					rowHeader.setText(text);
					Element columnHeader = theHeader.addElement("COLUMN-HEADER");
					columnHeader.addAttribute("Name", name);
					columnHeader.addAttribute("DSM_Element_id", dsm_Element_id);
					columnHeader.setText(text);
					if (owlKARMAModelElement.getPropertyValue(annotationProModel_Id) != null) {
						String model_Id = owlKARMAModelElement.getPropertyValue(annotationProModel_Id).toString();
						rowHeader.addAttribute("model_id", model_Id);
						columnHeader.addAttribute("model_id", model_Id);
					}
					if (owlKARMAModelElement.getPropertyValue(annotationProMeta_Model) != null) {
						String meta_Model = owlKARMAModelElement.getPropertyValue(annotationProMeta_Model)
								.toString();
						rowHeader.addAttribute("meta_model", meta_Model);
						columnHeader.addAttribute("meta_model", meta_Model);
					}

					if (owlKARMAModelElement.getPropertyValue(annotationProMeta_Property_Instance_Id) != null) {
						String meta_Property_Instance_Id = owlKARMAModelElement
								.getPropertyValue(annotationProMeta_Property_Instance_Id).toString();
						Element role_Meta_Property_Instance = rowHeader.addElement("meta_property_instance");
						Element column_Meta_Property_Instance = columnHeader.addElement("meta_property_instance");
						role_Meta_Property_Instance.addAttribute("meta_property_instance_id",
								meta_Property_Instance_Id);
						column_Meta_Property_Instance.addAttribute("meta_property_instance_id",
								meta_Property_Instance_Id);
						if (owlKARMAModelElement
								.getPropertyValue(annotationProMeta_Property_Instance_Type) != null) {
							String meta_Property_Instance_Type = owlKARMAModelElement
									.getPropertyValue(annotationProMeta_Property_Instance_Type).toString();
							role_Meta_Property_Instance.addAttribute("meta_property_instance_type",
									meta_Property_Instance_Type);
							column_Meta_Property_Instance.addAttribute("meta_property_instance_type",
									meta_Property_Instance_Type);
							if (owlKARMAModelElement
									.getPropertyValue(annotationProMeta_Property_Instance_Text) != null) {
								String meta_Property_Instance_Text = owlKARMAModelElement
										.getPropertyValue(annotationProMeta_Property_Instance_Text).toString();
								role_Meta_Property_Instance.setText(meta_Property_Instance_Text);
								column_Meta_Property_Instance.setText(meta_Property_Instance_Text);
							}
						}
					}
				}
			}
			//关系
			int size = relationshipIndividual.size();
			for (int i = 0; i < size; i++) {
			    Individual dsmRowIndividual = relationshipIndividual.get(i);
			    String dsm_Row_Element_id = dsmRowIndividual.getPropertyValue(annotationProDSM_Element_Id).toString();
			    Element rowElement = Table.addElement("Row");
			    rowElement.addAttribute("row", dsm_Row_Element_id);
			    for (int j = 0; j < size; j++) {
				    Individual dsmCellIndividual = relationshipIndividual.get(j);
				    String dsm_Cell_Element_id = dsmCellIndividual.getPropertyValue(annotationProDSM_Element_Id).toString();
				    Element cellElement = rowElement.addElement("Cell");
				    cellElement.addAttribute("line", dsm_Cell_Element_id);
				    for (Iterator it = dsmRowIndividual.listProperties(); it.hasNext();) {
						Statement owlDSMRowIndividualPro = (Statement) it.next();
						 RDFNode object = owlDSMRowIndividualPro.getObject();
						 if (object.isResource()) {
							 Individual owlCellElement = ontModel
										.getIndividual(owlDSMRowIndividualPro.getResource().getURI());
							 if(owlCellElement!=null) {
								 if(owlCellElement.getPropertyValue(annotationProDSM_Element_Id)!=null) {
									 String line = owlCellElement.getPropertyValue(annotationProDSM_Element_Id).toString();
									 if (dsm_Cell_Element_id.equals(line)){
										 cellElement.setText(owlDSMRowIndividualPro.getPredicate().getLocalName());
									 }
								 }		
						 
							 } 
						
						 }

				    }
				    
				}
			}

			// end

			System.out.println("success");
//			String dsmpath = path.toString().replace(".owl", "\\languages\\model\\" + name + ".dsm");
//			String fileName = dsmpath;
			IFolder languageFolder = languagesFolder.getFolder(owlDSMIndividual.getPropertyValue(annotationPropertyModelLocation).toString());
			IFolder modelFolder = null;
			IFolder modelFolder1 = languageFolder.getFolder(PackagePath.TYPE_MODEL);
			IFolder modelFolder2 = languageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
			if (modelFolder1.exists()) {
				modelFolder = modelFolder1;
			} else if (modelFolder2.exists()) {
				modelFolder = modelFolder2;
			}
			String fileName = modelFolder.getLocation().toOSString() + "/" + tableName + ".dsm";
//			String fileName = "D:\\runtime-MetaGraph\\测试GOPPRRE_BFO\\语言\\GOPPRE\\模型\\oABCNGZh.dsm";
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("UTF-8");
			format.setNewLineAfterDeclaration(false);
			XMLWriter writer = new XMLWriter(new FileOutputStream(new File(fileName)), format);
			writer.write(document);
			writer.close();
			IFile modelFile = modelFolder.getFile(tableName + ".dsm");
			modelFile.refreshLocal(IResource.DEPTH_ZERO,null);
		}
//		}
	}
}
