package org.fc.mdt.owl.owl2Karma;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.Restriction;
import org.apache.jena.ontology.SomeValuesFromRestriction;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.util.iterator.ExtendedIterator;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.QName;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;

public class Owl2Reqif {

	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
	
	/**
	 * 读取owl文件
	 * @author xiaodu
	 * @param owlFilePath
	 */
	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}
	
	/**
	 * 生成Reqif的方法重载
	 * @author xiaodu
	 */
	public static void GenerateReqif(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException {
		OntModel ontModel = readOwlFile(owlFilePath);
		GenerateReqif(ontModel, languagesFolder, monitor);
	}

	public static void GenerateReqif(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */
		
		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);

		// 1.获取class
		OntClass owlReqIFClass = ontModel.getOntClass(METAG + "ReqIF");

		// 获取annotationProperty
		AnnotationProperty annotationProIdentifier = ontModel.getAnnotationProperty(METAG + "identifier");
		AnnotationProperty annotationProTitle = ontModel.getAnnotationProperty(METAG + "TITLE");
		AnnotationProperty annotationProLast_Change = ontModel.getAnnotationProperty(METAG + "Last_Change");
		AnnotationProperty annotationProLong_Name = ontModel.getAnnotationProperty(METAG + "Long_Name");
		AnnotationProperty annotationProKey = ontModel.getAnnotationProperty(METAG + "Key");
		AnnotationProperty annotationProOtherContent = ontModel.getAnnotationProperty(METAG + "OtherContent");
		AnnotationProperty annotationProDesc = ontModel.getAnnotationProperty(METAG + "Desc");
		AnnotationProperty annotationProTheValue = ontModel.getAnnotationProperty(METAG + "TheValue");
		AnnotationProperty annotationProDefalutValue = ontModel.getAnnotationProperty(METAG + "DefalutValue");
		AnnotationProperty annotationProXHTMLDiv = ontModel.getAnnotationProperty(METAG + "xhtml:div");
		AnnotationProperty annotationProDefalutLabel = ontModel.getAnnotationProperty(METAG + "DefalutLabel");
		AnnotationProperty annotationProMax_Length = ontModel.getAnnotationProperty(METAG + "Max_Length");
		AnnotationProperty annotationProMax = ontModel.getAnnotationProperty(METAG + "Max");
		AnnotationProperty annotationProMin = ontModel.getAnnotationProperty(METAG + "Min");
		AnnotationProperty annotationProPrefix = ontModel.getAnnotationProperty(METAG + "prefix");
		AnnotationProperty annotationProCount = ontModel.getAnnotationProperty(METAG + "count");
		AnnotationProperty annotationProSize = ontModel.getAnnotationProperty(METAG + "size");
		AnnotationProperty annotationProVerticalAlign = ontModel.getAnnotationProperty(METAG + "verticalAlign");
		AnnotationProperty annotationProWidth = ontModel.getAnnotationProperty(METAG + "Width");
		AnnotationProperty annotationProLabel = ontModel.getAnnotationProperty(METAG + "Label");
		AnnotationProperty annotationProSequence = ontModel.getAnnotationProperty(METAG + "sequence");
		AnnotationProperty annotationProReqIFComment = ontModel.getAnnotationProperty(METAG + "COMMENT");
		AnnotationProperty annotationProReqIFCreationtime = ontModel.getAnnotationProperty(METAG + "CREATION-TIME");
		AnnotationProperty annotationProReqIFToolId = ontModel.getAnnotationProperty(METAG + "REQ-IF-TOOL-ID");
		AnnotationProperty annotationProReqIFVesion = ontModel.getAnnotationProperty(METAG + "REQ-IF-VERSION");
		AnnotationProperty annotationProSourceId = ontModel.getAnnotationProperty(METAG + "SOURCE-TOOL-ID");
		AnnotationProperty annotationPropertyModelLocation = ontModel.getAnnotationProperty(METAG + "modelLocation");
		AnnotationProperty annotationProIsSimplified = ontModel.getAnnotationProperty(METAG + "isSimplified");
		AnnotationProperty annotationProSpecObjectType = ontModel.getAnnotationProperty(METAG + "SpecObjectType");
		AnnotationProperty annotationProSpecificationType = ontModel.getAnnotationProperty(METAG + "SpecificationType");
		AnnotationProperty annotationProSpecRelationType = ontModel.getAnnotationProperty(METAG + "SpecRelationType");
		AnnotationProperty annotationProRelationGroupType = ontModel.getAnnotationProperty(METAG + "RelationGroupType");
		AnnotationProperty annotationProMark = ontModel.getAnnotationProperty(METAG + "mark");
		AnnotationProperty annotationProAttributeDefinitionType = ontModel
				.getAnnotationProperty(METAG + "AttributeDefinitionType");
		
		AnnotationProperty annotationProDataTypesStructure = ontModel.createAnnotationProperty(METAG + "dataTypesStructure");
		AnnotationProperty annotationProSpecTypesStructure = ontModel.createAnnotationProperty(METAG + "specTypesStructure");
		AnnotationProperty annotationProSpecAttributesStructure = ontModel.createAnnotationProperty(METAG + "specAttributesStructure");
		AnnotationProperty annotationProSpecObjectsStructure = ontModel.createAnnotationProperty(METAG + "specObjectsStructure");
		AnnotationProperty annotationProSpecRelationsStructure = ontModel.createAnnotationProperty(METAG + "specRelationsStructure");
		AnnotationProperty annotationProValuesStructure = ontModel.createAnnotationProperty(METAG + "valuesStructure");
		AnnotationProperty annotationProSpecificationsStructure = ontModel.createAnnotationProperty(METAG + "specificationsStructure");
		AnnotationProperty annotationProSpecRelationGroupStructure = ontModel.createAnnotationProperty(METAG + "specificationsStructure");
		AnnotationProperty annotationProChildrenStructure = ontModel.createAnnotationProperty(METAG + "childrenStructure");


		// 一个reqif individual是一个reqif文件
		if (owlReqIFClass.listInstances() != null) {
			for (Iterator itr = owlReqIFClass.listInstances(); itr.hasNext();) {
				Individual owlReqIFIndividual = (Individual) itr.next();
				// 生成ReqIF的前期
				// Reqif表头
				Document document = DocumentHelper.createDocument();
				Element root = document.addElement("REQ-IF", "http://www.omg.org/spec/ReqIF/20110401/reqif.xsd");
				root.addNamespace("configuration", "http://eclipse.org/rmf/pror/toolextensions/1.0");

				// 下面的需判断
//				Boolean flagLinewrapConfiguration = false;
//				Boolean flagIdConfiguration = false;
//				Boolean flagHeadlineConfiguration = false;
				root.addNamespace("headline", "http://pror.org/presentation/headline");
				root.addNamespace("id", "http://pror.org/presentation/id");
				root.addNamespace("linewrap", "http://pror.org/presentation/linewrap");
				root.addNamespace("xhtml", "http://www.w3.org/1999/xhtml");

				Element theHeader = root.addElement("THE-HEADER");
				Element reqIFHeader = theHeader.addElement("REQ-IF-HEADER");
				String reqIFIdentifier = owlReqIFIndividual.getPropertyValue(annotationProIdentifier).toString();
				reqIFHeader.addAttribute("IDENTIFIER", reqIFIdentifier);

				Element comment = reqIFHeader.addElement("COMMENT");
				String reqIFComment = owlReqIFIndividual.getPropertyValue(annotationProReqIFComment).toString();
				comment.setText(reqIFComment);

				Element creationTime = reqIFHeader.addElement("CREATION-TIME");
				String reqIFCreationtime = owlReqIFIndividual.getPropertyValue(annotationProReqIFCreationtime)
						.toString();
				creationTime.setText(reqIFCreationtime);

				Element reqIFToolID = reqIFHeader.addElement("REQ-IF-TOOL-ID");
				String reqIFToolId = owlReqIFIndividual.getPropertyValue(annotationProReqIFToolId).toString();
				reqIFToolID.setText(reqIFToolId);

				Element reqIFVersion = reqIFHeader.addElement("REQ-IF-VERSION");
				String reqifversion = owlReqIFIndividual.getPropertyValue(annotationProReqIFVesion).toString();
				reqIFVersion.setText(reqifversion);

				Element sourceToolID = reqIFHeader.addElement("SOURCE-TOOL-ID");
				String sourceToolId = owlReqIFIndividual.getPropertyValue(annotationProSourceId).toString();
				sourceToolID.setText(sourceToolId);

				if (owlReqIFIndividual.getPropertyValue(annotationProTitle) != null) {
					Element reqqIFTitle = reqIFHeader.addElement("TITLE");
					String title = owlReqIFIndividual.getPropertyValue(annotationProTitle).toString();
					reqqIFTitle.setText(title);
				}

				Element coreContent = root.addElement("CORE-CONTENT");
				Element reqIFContent = coreContent.addElement("REQ-IF-CONTENT");

				// 开始生成每个ReqIF文件的主体内容
				// 生成DATATYPES，绑定在owlReqIFIndividual下的
				if(owlReqIFIndividual.getPropertyValue(annotationProDataTypesStructure) != null) {
					Element dataTypes = reqIFContent.addElement("DATATYPES");
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_DataType")) {
							//begin 20231112随Reqif2Owl更新
//							OntClass owlDataTypesubClass = ontModel
//									.getOntClass(owlReqIFIndividualPro.getResource().getURI());
							Individual owldataTypeIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());
							String classId = owldataTypeIndividual.getLocalName().substring(0);
							OntClass owlDataTypesubClass = ontModel.getOntClass(METAG + classId);
							//end 20231112随Reqif2Owl更新
							OntClass owlDataTypeClass = owlDataTypesubClass.getSuperClass();
							if (owlDataTypeClass.getLocalName().equals("DataType_String")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-STRING");
								String identifier = owlDataTypesubClass.getPropertyValue(annotationProIdentifier)
										.toString();
								String lastChange = owlDataTypesubClass.getPropertyValue(annotationProLast_Change)
										.toString();
								dataTypeDefinition.addAttribute("IDENTIFIER", identifier);
								dataTypeDefinition.addAttribute("LAST-CHANGE", lastChange);
								if (owlDataTypesubClass.getPropertyValue(annotationProDesc) != null) {
									String desc = owlDataTypesubClass.getPropertyValue(annotationProDesc).toString();
									dataTypeDefinition.addAttribute("DESC", desc);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProLong_Name) != null) {
									String longName = owlDataTypesubClass.getPropertyValue(annotationProLong_Name)
											.toString();
									dataTypeDefinition.addAttribute("LONG-NAME", longName);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProMax_Length) != null) {
									String maxLength = owlDataTypesubClass.getPropertyValue(annotationProMax_Length)
											.toString();
									dataTypeDefinition.addAttribute("MAX-LENGTH", maxLength);
								}

							} else if (owlDataTypeClass.getLocalName().equals("DataType_Real")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-REAL");
								String identifier = owlDataTypesubClass.getPropertyValue(annotationProIdentifier)
										.toString();
								String lastChange = owlDataTypesubClass.getPropertyValue(annotationProLast_Change)
										.toString();
								dataTypeDefinition.addAttribute("IDENTIFIER", identifier);
								dataTypeDefinition.addAttribute("LAST-CHANGE", lastChange);
								if (owlDataTypesubClass.getPropertyValue(annotationProDesc) != null) {
									String desc = owlDataTypesubClass.getPropertyValue(annotationProDesc).toString();
									dataTypeDefinition.addAttribute("DESC", desc);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProLong_Name) != null) {
									String longName = owlDataTypesubClass.getPropertyValue(annotationProLong_Name)
											.toString();
									dataTypeDefinition.addAttribute("LONG-NAME", longName);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProMax) != null) {
									String max = owlDataTypesubClass.getPropertyValue(annotationProMax).toString();
									dataTypeDefinition.addAttribute("MAX", max);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProMin) != null) {
									String min = owlDataTypesubClass.getPropertyValue(annotationProMin).toString();
									dataTypeDefinition.addAttribute("MIN", min);
								}
							} else if (owlDataTypeClass.getLocalName().equals("DataType_Integer")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-INTEGER");
								String identifier = owlDataTypesubClass.getPropertyValue(annotationProIdentifier)
										.toString();
								String lastChange = owlDataTypesubClass.getPropertyValue(annotationProLast_Change)
										.toString();
								dataTypeDefinition.addAttribute("IDENTIFIER", identifier);
								dataTypeDefinition.addAttribute("LAST-CHANGE", lastChange);
								if (owlDataTypesubClass.getPropertyValue(annotationProDesc) != null) {
									String desc = owlDataTypesubClass.getPropertyValue(annotationProDesc).toString();
									dataTypeDefinition.addAttribute("DESC", desc);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProLong_Name) != null) {
									String longName = owlDataTypesubClass.getPropertyValue(annotationProLong_Name)
											.toString();
									dataTypeDefinition.addAttribute("LONG-NAME", longName);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProMax) != null) {
									String max = owlDataTypesubClass.getPropertyValue(annotationProMax).toString();
									dataTypeDefinition.addAttribute("MAX", max);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProMin) != null) {
									String min = owlDataTypesubClass.getPropertyValue(annotationProMin).toString();
									dataTypeDefinition.addAttribute("MIN", min);
								}
							} else if (owlDataTypeClass.getLocalName().equals("DataType_Enumeration")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-ENUMERATION");
								if (owlDataTypesubClass.listSubClasses() != null) {
									Element specifiedValues = dataTypeDefinition.addElement("SPECIFIED-VALUES");
									for (ExtendedIterator<OntClass> it1 = owlDataTypesubClass.listSubClasses(); it1
											.hasNext();) {
										OntClass owlEnumValueClass = it1.next();

										Element enumValue = specifiedValues.addElement("ENUM-VALUE");
										String identifier = owlEnumValueClass.getPropertyValue(annotationProIdentifier)
												.toString();
										String lastChange = owlEnumValueClass.getPropertyValue(annotationProLast_Change)
												.toString();
										enumValue.addAttribute("IDENTIFIER", identifier);
										enumValue.addAttribute("LAST-CHANGE", lastChange);
										if (owlEnumValueClass.getPropertyValue(annotationProLong_Name) != null) {
											String longName = owlEnumValueClass.getPropertyValue(annotationProLong_Name)
													.toString();
											enumValue.addAttribute("LONG-NAME", longName);
										}
										Element propeties = enumValue.addElement("PROPERTIES");
										Element embeddedValue = propeties.addElement("EMBEDDED-VALUE");
										if (owlEnumValueClass.getPropertyValue(annotationProKey) != null) {
											String key = owlEnumValueClass.getPropertyValue(annotationProKey).toString();
											embeddedValue.addAttribute("KEY", key);
										}
										if (owlEnumValueClass.getPropertyValue(annotationProOtherContent) != null) {
											String otherContent = owlEnumValueClass
													.getPropertyValue(annotationProOtherContent).toString();
											embeddedValue.addAttribute("OTHER-CONTENT", otherContent);
										}
									}

								}
							} else if (owlDataTypeClass.getLocalName().equals("DataType_Date")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-DATE");
								String identifier = owlDataTypesubClass.getPropertyValue(annotationProIdentifier)
										.toString();
								String lastChange = owlDataTypesubClass.getPropertyValue(annotationProLast_Change)
										.toString();
								dataTypeDefinition.addAttribute("IDENTIFIER", identifier);
								dataTypeDefinition.addAttribute("LAST-CHANGE", lastChange);
								if (owlDataTypesubClass.getPropertyValue(annotationProDesc) != null) {
									String desc = owlDataTypesubClass.getPropertyValue(annotationProDesc).toString();
									dataTypeDefinition.addAttribute("DESC", desc);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProLong_Name) != null) {
									String longName = owlDataTypesubClass.getPropertyValue(annotationProLong_Name)
											.toString();
									dataTypeDefinition.addAttribute("LONG-NAME", longName);
								}
							} else if (owlDataTypeClass.getLocalName().equals("DataType_Boolean")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-BOOLEAN");
								String identifier = owlDataTypesubClass.getPropertyValue(annotationProIdentifier)
										.toString();
								String lastChange = owlDataTypesubClass.getPropertyValue(annotationProLast_Change)
										.toString();
								dataTypeDefinition.addAttribute("IDENTIFIER", identifier);
								dataTypeDefinition.addAttribute("LAST-CHANGE", lastChange);
								if (owlDataTypesubClass.getPropertyValue(annotationProDesc) != null) {
									String desc = owlDataTypesubClass.getPropertyValue(annotationProDesc).toString();
									dataTypeDefinition.addAttribute("DESC", desc);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProLong_Name) != null) {
									String longName = owlDataTypesubClass.getPropertyValue(annotationProLong_Name)
											.toString();
									dataTypeDefinition.addAttribute("LONG-NAME", longName);
								}
							} else if (owlDataTypeClass.getLocalName().equals("DataType_XHTML")) {
								Element dataTypeDefinition = dataTypes.addElement("DATATYPE-DEFINITION-XHTML");
								String identifier = owlDataTypesubClass.getPropertyValue(annotationProIdentifier)
										.toString();
								String lastChange = owlDataTypesubClass.getPropertyValue(annotationProLast_Change)
										.toString();
								dataTypeDefinition.addAttribute("IDENTIFIER", identifier);
								dataTypeDefinition.addAttribute("LAST-CHANGE", lastChange);
								if (owlDataTypesubClass.getPropertyValue(annotationProDesc) != null) {
									String desc = owlDataTypesubClass.getPropertyValue(annotationProDesc).toString();
									dataTypeDefinition.addAttribute("DESC", desc);
								}
								if (owlDataTypesubClass.getPropertyValue(annotationProLong_Name) != null) {
									String longName = owlDataTypesubClass.getPropertyValue(annotationProLong_Name)
											.toString();
									dataTypeDefinition.addAttribute("LONG-NAME", longName);
								}
							}
						}
					}
				}
				
				// 生成SPEC-TYPES
				if(owlReqIFIndividual.getPropertyValue(annotationProSpecTypesStructure) != null) {
					Element specTypes = reqIFContent.addElement("SPEC-TYPES");
					// 生成SPEC-OBJECT-TYPE
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_SpecObjectType")) {
							//begin 20231112随Reqif2Owl更新
//							OntClass owlSpecObjectTypeClass = ontModel
//									.getOntClass(owlReqIFIndividualPro.getResource().getURI());
							Individual owlSpecObjectTypeIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());
							String classId = owlSpecObjectTypeIndividual.getLocalName().substring(0);
							OntClass owlSpecObjectTypeClass = ontModel.getOntClass(METAG + classId);
							//end 20231112随Reqif2Owl更新
							Element specObjectType = specTypes.addElement("SPEC-OBJECT-TYPE");
							String identifier = owlSpecObjectTypeClass.getPropertyValue(annotationProIdentifier).toString();
							String lastChange = owlSpecObjectTypeClass.getPropertyValue(annotationProLast_Change)
									.toString();
							specObjectType.addAttribute("IDENTIFIER", identifier);
							specObjectType.addAttribute("LAST-CHANGE", lastChange);
							if (owlSpecObjectTypeClass.getPropertyValue(annotationProLong_Name) != null) {
								String longName = owlSpecObjectTypeClass.getPropertyValue(annotationProLong_Name)
										.toString();
								specObjectType.addAttribute("LONG-NAME", longName);
							}
							// 生成SPEC-ATTRIBUTES
							if(owlSpecObjectTypeClass.getPropertyValue(annotationProSpecAttributesStructure) != null) {
								Element SpecAttributes = specObjectType.addElement("SPEC-ATTRIBUTES");
								for (Iterator it2 = owlSpecObjectTypeClass.listEquivalentClasses(); it2.hasNext();) {

									// 生成ATTRIBUTE-DEFINITION-
									OntClass c2 = (OntClass) it2.next();
									Restriction r2 = c2.asRestriction();
									SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
									if (sr2.getOnProperty().getLocalName().equals("SpecObjectType_has_AttributeDefinition")) {
										OntClass owlSpecAttributeClass = (OntClass) sr2.getSomeValuesFrom();
										OntClass owlAttribute_DefinitionTypeClass = owlSpecAttributeClass.getSuperClass();

										if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_String")) {
											Element attributrDefinitionString = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-STRING");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionString.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionString.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionString.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionString.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionString.addElement("TYPE");
													Element dataTypeDefinitionStringRef = type
															.addElement("DATATYPE-DEFINITION-STRING-REF");
													dataTypeDefinitionStringRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionString
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueString = defaultValue
															.addElement("ATTRIBUTE-VALUE-STRING");
													attributeValueString.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueString.addElement("DEFINITION");
													Element attributeDefinitionStringRef = definition
															.addElement("ATTRIBUTE-DEFINITION-STRING-REF");
													attributeDefinitionStringRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Real")) {
											Element attributrDefinitionReal = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-REAL");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionReal.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionReal.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionReal.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionReal.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionReal.addElement("TYPE");
													Element dataTypeDefinitionRealRef = type
															.addElement("DATATYPE-DEFINITION-REAL-REF");
													dataTypeDefinitionRealRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionReal.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueReal = defaultValue
															.addElement("ATTRIBUTE-VALUE-REAL");
													attributeValueReal.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueReal.addElement("DEFINITION");
													Element attributeDefinitionRealRef = definition
															.addElement("ATTRIBUTE-DEFINITION-REAL-REF");
													attributeDefinitionRealRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Integer")) {
											Element attributrDefinitionInteger = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-INTEGER");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionInteger.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionInteger.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionInteger.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionInteger.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionInteger.addElement("TYPE");
													Element dataTypeDefinitionIntegerRef = type
															.addElement("DATATYPE-DEFINITION-INTEGER-REF");
													dataTypeDefinitionIntegerRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionInteger
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueInteger = defaultValue
															.addElement("ATTRIBUTE-VALUE-INTEGER");
													attributeValueInteger.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueInteger.addElement("DEFINITION");
													Element attributeDefinitionIntegerRef = definition
															.addElement("ATTRIBUTE-DEFINITION-INTEGER-REF");
													attributeDefinitionIntegerRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Enumeration")) {
											Element attributrDefinitionEnum = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-ENUMERATION");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionEnum.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionEnum.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionEnum.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionEnum.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionEnum.addElement("TYPE");
													Element dataTypeDefinitionEnumRef = type
															.addElement("DATATYPE-DEFINITION-ENUMERATION-REF");
													dataTypeDefinitionEnumRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionEnum.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueEnum = defaultValue
															.addElement("ATTRIBUTE-VALUE-ENUMERATION");
													Element definition = attributeValueEnum.addElement("DEFINITION");
													Element attributeDefinitionEnumRef = definition
															.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
													attributeDefinitionEnumRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Date")) {
											Element attributrDefinitionDate = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-DATE");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionDate.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionDate.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionDate.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionDate.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionDate.addElement("TYPE");
													Element dataTypeDefinitionDateRef = type
															.addElement("DATATYPE-DEFINITION-DATE-REF");
													dataTypeDefinitionDateRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionDate.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueDate = defaultValue
															.addElement("ATTRIBUTE-VALUE-DATE");
													attributeValueDate.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueDate.addElement("DEFINITION");
													Element attributeDefinitionDateRef = definition
															.addElement("ATTRIBUTE-DEFINITION-DATE-REF");
													attributeDefinitionDateRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Boolean")) {
											Element attributrDefinitionBoolean = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-BOOLEAN");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionBoolean.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionBoolean.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionBoolean.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionBoolean.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionBoolean.addElement("TYPE");
													Element dataTypeDefinitionBooleanRef = type
															.addElement("DATATYPE-DEFINITION-BOOLEAN-REF");
													dataTypeDefinitionBooleanRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionBoolean
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueBoolean = defaultValue
															.addElement("ATTRIBUTE-VALUE-BOOLEAN");
													attributeValueBoolean.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueBoolean.addElement("DEFINITION");
													Element attributeDefinitionBooleanRef = definition
															.addElement("ATTRIBUTE-DEFINITION-BOOLEAN-REF");
													attributeDefinitionBooleanRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_XHTML")) {
											Element attributrDefinitionXHTML = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-XHTML");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionXHTML.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionXHTML.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionXHTML.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionXHTML.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionXHTML.addElement("TYPE");
													Element dataTypeDefinitionXHTMLRef = type
															.addElement("DATATYPE-DEFINITION-XHTML-REF");
													dataTypeDefinitionXHTMLRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProIsSimplified) != null) {
													Element defaultValue = attributrDefinitionXHTML.addElement("DEFAULT-VALUE");
													Element attributeValueXHTML = defaultValue
															.addElement("ATTRIBUTE-VALUE-XHTML");
													String isSimplified = owlSpecAttributeClass
															.getPropertyValue(annotationProIsSimplified).toString();
													attributeValueXHTML.addAttribute("IS-SIMPLIFIED", isSimplified);
													Element theOriginalValue = attributeValueXHTML
															.addElement("THE-ORIGINAL-VALUE");
													Element attributeDefinitionStringRef = attributeValueXHTML
															.addElement("THE-VALUE");
												}

											}
										}
									}
								}
							}
						}
					}
					// 生成SPECIFICATION-TYPE
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_SpecificationType")) {
							//begin 20231112随Reqif2Owl更新
//							OntClass owlSpecificationTypeClass = ontModel
//									.getOntClass(owlReqIFIndividualPro.getResource().getURI());
							Individual owlSpecificationTypeIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());
							String classId = owlSpecificationTypeIndividual.getLocalName().substring(0);
							OntClass owlSpecificationTypeClass = ontModel.getOntClass(METAG + classId);
							//end 20231112随Reqif2Owl更新
							Element specificationType = specTypes.addElement("SPECIFICATION-TYPE");
							String identifier = owlSpecificationTypeClass.getPropertyValue(annotationProIdentifier)
									.toString();
							String lastChange = owlSpecificationTypeClass.getPropertyValue(annotationProLast_Change)
									.toString();
							specificationType.addAttribute("IDENTIFIER", identifier);
							specificationType.addAttribute("LAST-CHANGE", lastChange);
							if (owlSpecificationTypeClass.getPropertyValue(annotationProLong_Name) != null) {
								String longName = owlSpecificationTypeClass.getPropertyValue(annotationProLong_Name)
										.toString();
								specificationType.addAttribute("LONG-NAME", longName);
							}
							// 生成SPEC-ATTRIBUTES
							if(owlSpecificationTypeClass.getPropertyValue(annotationProSpecAttributesStructure) != null) {
								Element SpecAttributes = specificationType.addElement("SPEC-ATTRIBUTES");
								for (Iterator it2 = owlSpecificationTypeClass.listEquivalentClasses(); it2.hasNext();) {

									// 生成ATTRIBUTE-DEFINITION-
									OntClass c2 = (OntClass) it2.next();
									Restriction r2 = c2.asRestriction();
									SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
									if (sr2.getOnProperty().getLocalName()
											.equals("SpecificationType_has_AttributeDefinition")) {
										OntClass owlSpecAttributeClass = (OntClass) sr2.getSomeValuesFrom();
										OntClass owlAttribute_DefinitionTypeClass = owlSpecAttributeClass.getSuperClass();
										if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_String")) {
											Element attributrDefinitionString = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-STRING");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionString.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionString.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionString.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionString.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionString.addElement("TYPE");
													Element dataTypeDefinitionStringRef = type
															.addElement("DATATYPE-DEFINITION-STRING-REF");
													dataTypeDefinitionStringRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionString
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueString = defaultValue
															.addElement("ATTRIBUTE-VALUE-STRING");
													attributeValueString.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueString.addElement("DEFINITION");
													Element attributeDefinitionStringRef = definition
															.addElement("ATTRIBUTE-DEFINITION-STRING-REF");
													attributeDefinitionStringRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Real")) {
											Element attributrDefinitionReal = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-REAL");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionReal.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionReal.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionReal.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionReal.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionReal.addElement("TYPE");
													Element dataTypeDefinitionRealRef = type
															.addElement("DATATYPE-DEFINITION-REAL-REF");
													dataTypeDefinitionRealRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionReal.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueReal = defaultValue
															.addElement("ATTRIBUTE-VALUE-REAL");
													attributeValueReal.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueReal.addElement("DEFINITION");
													Element attributeDefinitionRealRef = definition
															.addElement("ATTRIBUTE-DEFINITION-REAL-REF");
													attributeDefinitionRealRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Integer")) {
											Element attributrDefinitionInteger = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-INTEGER");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionInteger.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionInteger.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionInteger.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionInteger.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionInteger.addElement("TYPE");
													Element dataTypeDefinitionIntegerRef = type
															.addElement("DATATYPE-DEFINITION-INTEGER-REF");
													dataTypeDefinitionIntegerRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionInteger
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueInteger = defaultValue
															.addElement("ATTRIBUTE-VALUE-INTEGER");
													attributeValueInteger.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueInteger.addElement("DEFINITION");
													Element attributeDefinitionIntegerRef = definition
															.addElement("ATTRIBUTE-DEFINITION-INTEGER-REF");
													attributeDefinitionIntegerRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Enumeration")) {
											Element attributrDefinitionEnum = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-ENUMERATION");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionEnum.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionEnum.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionEnum.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionEnum.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionEnum.addElement("TYPE");
													Element dataTypeDefinitionEnumRef = type
															.addElement("DATATYPE-DEFINITION-ENUMERATION-REF");
													dataTypeDefinitionEnumRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionEnum.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueEnum = defaultValue
															.addElement("ATTRIBUTE-VALUE-ENUMERATION");
													Element definition = attributeValueEnum.addElement("DEFINITION");
													Element attributeDefinitionEnumRef = definition
															.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
													attributeDefinitionEnumRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Date")) {
											Element attributrDefinitionDate = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-DATE");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionDate.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionDate.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionDate.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionDate.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionDate.addElement("TYPE");
													Element dataTypeDefinitionDateRef = type
															.addElement("DATATYPE-DEFINITION-DATE-REF");
													dataTypeDefinitionDateRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionDate.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueDate = defaultValue
															.addElement("ATTRIBUTE-VALUE-DATE");
													attributeValueDate.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueDate.addElement("DEFINITION");
													Element attributeDefinitionDateRef = definition
															.addElement("ATTRIBUTE-DEFINITION-DATE-REF");
													attributeDefinitionDateRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Boolean")) {
											Element attributrDefinitionBoolean = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-BOOLEAN");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionBoolean.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionBoolean.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionBoolean.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionBoolean.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionBoolean.addElement("TYPE");
													Element dataTypeDefinitionBooleanRef = type
															.addElement("DATATYPE-DEFINITION-BOOLEAN-REF");
													dataTypeDefinitionBooleanRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionBoolean
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueBoolean = defaultValue
															.addElement("ATTRIBUTE-VALUE-BOOLEAN");
													attributeValueBoolean.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueBoolean.addElement("DEFINITION");
													Element attributeDefinitionBooleanRef = definition
															.addElement("ATTRIBUTE-DEFINITION-BOOLEAN-REF");
													attributeDefinitionBooleanRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_XHTML")) {
											Element attributrDefinitionXHTML = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-XHTML");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionXHTML.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionXHTML.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionXHTML.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionXHTML.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionXHTML.addElement("TYPE");
													Element dataTypeDefinitionXHTMLRef = type
															.addElement("DATATYPE-DEFINITION-XHTML-REF");
													dataTypeDefinitionXHTMLRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProIsSimplified) != null) {
													Element defaultValue = attributrDefinitionXHTML.addElement("DEFAULT-VALUE");
													Element attributeValueXHTML = defaultValue
															.addElement("ATTRIBUTE-VALUE-XHTML");
													String isSimplified = owlSpecAttributeClass
															.getPropertyValue(annotationProIsSimplified).toString();
													attributeValueXHTML.addAttribute("IS-SIMPLIFIED", isSimplified);
													Element theOriginalValue = attributeValueXHTML
															.addElement("THE-ORIGINAL-VALUE");
													Element attributeDefinitionStringRef = attributeValueXHTML
															.addElement("THE-VALUE");
												}

											}
										}
									}
								}
							}
							
							
						}
					}

					// 生成SPEC-RELATION-TYPE
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_SpecRelationType")) {
							//begin 20231112随Reqif2Owl更新
//							OntClass owlSpecRelationTypeClass = ontModel
//									.getOntClass(owlReqIFIndividualPro.getResource().getURI());
							Individual owlSpecRelationTypeIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());
							String classId = owlSpecRelationTypeIndividual.getLocalName().substring(0);
							OntClass owlSpecRelationTypeClass = ontModel.getOntClass(METAG + classId);
							//end 20231112随Reqif2Owl更新
							Element specRelationType = specTypes.addElement("SPEC-RELATION-TYPE");
							String identifier = owlSpecRelationTypeClass.getPropertyValue(annotationProIdentifier)
									.toString();
							String lastChange = owlSpecRelationTypeClass.getPropertyValue(annotationProLast_Change)
									.toString();
							specRelationType.addAttribute("IDENTIFIER", identifier);
							specRelationType.addAttribute("LAST-CHANGE", lastChange);
							if (owlSpecRelationTypeClass.getPropertyValue(annotationProLong_Name) != null) {
								String longName = owlSpecRelationTypeClass.getPropertyValue(annotationProLong_Name)
										.toString();
								specRelationType.addAttribute("LONG-NAME", longName);
							}
							// 生成SPEC-ATTRIBUTES
							if(owlSpecRelationTypeClass.getPropertyValue(annotationProSpecAttributesStructure) != null) {
								Element SpecAttributes = specRelationType.addElement("SPEC-ATTRIBUTES");
								for (Iterator it2 = owlSpecRelationTypeClass.listEquivalentClasses(); it2.hasNext();) {

									// 生成ATTRIBUTE-DEFINITION-
									OntClass c2 = (OntClass) it2.next();
									Restriction r2 = c2.asRestriction();
									SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
									if (sr2.getOnProperty().getLocalName().equals("SpecRelationType_has_AttributeDefinition")) {
										OntClass owlSpecAttributeClass = (OntClass) sr2.getSomeValuesFrom();
										OntClass owlAttribute_DefinitionTypeClass = owlSpecAttributeClass.getSuperClass();
										if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_String")) {
											Element attributrDefinitionString = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-STRING");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionString.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionString.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionString.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionString.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionString.addElement("TYPE");
													Element dataTypeDefinitionStringRef = type
															.addElement("DATATYPE-DEFINITION-STRING-REF");
													dataTypeDefinitionStringRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionString
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueString = defaultValue
															.addElement("ATTRIBUTE-VALUE-STRING");
													attributeValueString.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueString.addElement("DEFINITION");
													Element attributeDefinitionStringRef = definition
															.addElement("ATTRIBUTE-DEFINITION-STRING-REF");
													attributeDefinitionStringRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Real")) {
											Element attributrDefinitionReal = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-REAL");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionReal.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionReal.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionReal.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionReal.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionReal.addElement("TYPE");
													Element dataTypeDefinitionRealRef = type
															.addElement("DATATYPE-DEFINITION-REAL-REF");
													dataTypeDefinitionRealRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionReal.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueReal = defaultValue
															.addElement("ATTRIBUTE-VALUE-REAL");
													attributeValueReal.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueReal.addElement("DEFINITION");
													Element attributeDefinitionRealRef = definition
															.addElement("ATTRIBUTE-DEFINITION-REAL-REF");
													attributeDefinitionRealRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Integer")) {
											Element attributrDefinitionInteger = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-INTEGER");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionInteger.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionInteger.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionInteger.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionInteger.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionInteger.addElement("TYPE");
													Element dataTypeDefinitionIntegerRef = type
															.addElement("DATATYPE-DEFINITION-INTEGER-REF");
													dataTypeDefinitionIntegerRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionInteger
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueInteger = defaultValue
															.addElement("ATTRIBUTE-VALUE-INTEGER");
													attributeValueInteger.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueInteger.addElement("DEFINITION");
													Element attributeDefinitionIntegerRef = definition
															.addElement("ATTRIBUTE-DEFINITION-INTEGER-REF");
													attributeDefinitionIntegerRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Enumeration")) {
											Element attributrDefinitionEnum = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-ENUMERATION");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionEnum.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionEnum.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionEnum.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionEnum.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionEnum.addElement("TYPE");
													Element dataTypeDefinitionEnumRef = type
															.addElement("DATATYPE-DEFINITION-ENUMERATION-REF");
													dataTypeDefinitionEnumRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionEnum.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueEnum = defaultValue
															.addElement("ATTRIBUTE-VALUE-ENUMERATION");
													Element definition = attributeValueEnum.addElement("DEFINITION");
													Element attributeDefinitionEnumRef = definition
															.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
													attributeDefinitionEnumRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Date")) {
											Element attributrDefinitionDate = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-DATE");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionDate.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionDate.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionDate.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionDate.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionDate.addElement("TYPE");
													Element dataTypeDefinitionDateRef = type
															.addElement("DATATYPE-DEFINITION-DATE-REF");
													dataTypeDefinitionDateRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionDate.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueDate = defaultValue
															.addElement("ATTRIBUTE-VALUE-DATE");
													attributeValueDate.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueDate.addElement("DEFINITION");
													Element attributeDefinitionDateRef = definition
															.addElement("ATTRIBUTE-DEFINITION-DATE-REF");
													attributeDefinitionDateRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Boolean")) {
											Element attributrDefinitionBoolean = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-BOOLEAN");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionBoolean.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionBoolean.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionBoolean.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionBoolean.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionBoolean.addElement("TYPE");
													Element dataTypeDefinitionBooleanRef = type
															.addElement("DATATYPE-DEFINITION-BOOLEAN-REF");
													dataTypeDefinitionBooleanRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionBoolean
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueBoolean = defaultValue
															.addElement("ATTRIBUTE-VALUE-BOOLEAN");
													attributeValueBoolean.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueBoolean.addElement("DEFINITION");
													Element attributeDefinitionBooleanRef = definition
															.addElement("ATTRIBUTE-DEFINITION-BOOLEAN-REF");
													attributeDefinitionBooleanRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_XHTML")) {
											Element attributrDefinitionXHTML = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-XHTML");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionXHTML.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionXHTML.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionXHTML.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionXHTML.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionXHTML.addElement("TYPE");
													Element dataTypeDefinitionXHTMLRef = type
															.addElement("DATATYPE-DEFINITION-XHTML-REF");
													dataTypeDefinitionXHTMLRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProIsSimplified) != null) {
													Element defaultValue = attributrDefinitionXHTML.addElement("DEFAULT-VALUE");
													Element attributeValueXHTML = defaultValue
															.addElement("ATTRIBUTE-VALUE-XHTML");
													String isSimplified = owlSpecAttributeClass
															.getPropertyValue(annotationProIsSimplified).toString();
													attributeValueXHTML.addAttribute("IS-SIMPLIFIED", isSimplified);
													Element theOriginalValue = attributeValueXHTML
															.addElement("THE-ORIGINAL-VALUE");
													Element attributeDefinitionStringRef = attributeValueXHTML
															.addElement("THE-VALUE");
												}

											}
										}
									}
								}
							}
						}
					}

					// 生成RELATION-GROUP-TYPE
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_RelationGroupType")) {
							//begin 20231112随Reqif2Owl更新
//							OntClass owlRelationGroupTypeClass = ontModel
//									.getOntClass(owlReqIFIndividualPro.getResource().getURI());
							Individual owlRelationGroupTypeIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());
							String classId = owlRelationGroupTypeIndividual.getLocalName().substring(0);
							OntClass owlRelationGroupTypeClass = ontModel.getOntClass(METAG + classId);
							//end 20231112随Reqif2Owl更新
							Element relationGroupType = specTypes.addElement("RELATION-GROUP-TYPE");
							String identifier = owlRelationGroupTypeClass.getPropertyValue(annotationProIdentifier)
									.toString();
							String lastChange = owlRelationGroupTypeClass.getPropertyValue(annotationProLast_Change)
									.toString();
							relationGroupType.addAttribute("IDENTIFIER", identifier);
							relationGroupType.addAttribute("LAST-CHANGE", lastChange);
							if (owlRelationGroupTypeClass.getPropertyValue(annotationProLong_Name) != null) {
								String longName = owlRelationGroupTypeClass.getPropertyValue(annotationProLong_Name)
										.toString();
								relationGroupType.addAttribute("LONG-NAME", longName);
							}
							// 生成SPEC-ATTRIBUTES
							if(owlRelationGroupTypeClass.getPropertyValue(annotationProSpecAttributesStructure) != null) {
								Element SpecAttributes = relationGroupType.addElement("SPEC-ATTRIBUTES");
								for (Iterator it2 = owlRelationGroupTypeClass.listEquivalentClasses(); it2.hasNext();) {

									// 生成ATTRIBUTE-DEFINITION-
									OntClass c2 = (OntClass) it2.next();
									Restriction r2 = c2.asRestriction();
									SomeValuesFromRestriction sr2 = r2.asSomeValuesFromRestriction();
									if (sr2.getOnProperty().getLocalName()
											.equals("RelationGroupType_has_AttributeDefinition")) {
										OntClass owlSpecAttributeClass = (OntClass) sr2.getSomeValuesFrom();
										OntClass owlAttribute_DefinitionTypeClass = owlSpecAttributeClass.getSuperClass();
										if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_String")) {
											Element attributrDefinitionString = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-STRING");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionString.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionString.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionString.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionString.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionString.addElement("TYPE");
													Element dataTypeDefinitionStringRef = type
															.addElement("DATATYPE-DEFINITION-STRING-REF");
													dataTypeDefinitionStringRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionString
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueString = defaultValue
															.addElement("ATTRIBUTE-VALUE-STRING");
													attributeValueString.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueString.addElement("DEFINITION");
													Element attributeDefinitionStringRef = definition
															.addElement("ATTRIBUTE-DEFINITION-STRING-REF");
													attributeDefinitionStringRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Real")) {
											Element attributrDefinitionReal = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-REAL");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionReal.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionReal.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionReal.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionReal.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionReal.addElement("TYPE");
													Element dataTypeDefinitionRealRef = type
															.addElement("DATATYPE-DEFINITION-REAL-REF");
													dataTypeDefinitionRealRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionReal.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueReal = defaultValue
															.addElement("ATTRIBUTE-VALUE-REAL");
													attributeValueReal.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueReal.addElement("DEFINITION");
													Element attributeDefinitionRealRef = definition
															.addElement("ATTRIBUTE-DEFINITION-REAL-REF");
													attributeDefinitionRealRef.setText(identifier1);
												}

											}

										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Integer")) {
											Element attributrDefinitionInteger = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-INTEGER");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionInteger.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionInteger.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionInteger.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionInteger.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionInteger.addElement("TYPE");
													Element dataTypeDefinitionIntegerRef = type
															.addElement("DATATYPE-DEFINITION-INTEGER-REF");
													dataTypeDefinitionIntegerRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionInteger
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueInteger = defaultValue
															.addElement("ATTRIBUTE-VALUE-INTEGER");
													attributeValueInteger.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueInteger.addElement("DEFINITION");
													Element attributeDefinitionIntegerRef = definition
															.addElement("ATTRIBUTE-DEFINITION-INTEGER-REF");
													attributeDefinitionIntegerRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Enumeration")) {
											Element attributrDefinitionEnum = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-ENUMERATION");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionEnum.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionEnum.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionEnum.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionEnum.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionEnum.addElement("TYPE");
													Element dataTypeDefinitionEnumRef = type
															.addElement("DATATYPE-DEFINITION-ENUMERATION-REF");
													dataTypeDefinitionEnumRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionEnum.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueEnum = defaultValue
															.addElement("ATTRIBUTE-VALUE-ENUMERATION");
													Element definition = attributeValueEnum.addElement("DEFINITION");
													Element attributeDefinitionEnumRef = definition
															.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
													attributeDefinitionEnumRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Date")) {
											Element attributrDefinitionDate = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-DATE");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionDate.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionDate.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionDate.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionDate.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionDate.addElement("TYPE");
													Element dataTypeDefinitionDateRef = type
															.addElement("DATATYPE-DEFINITION-DATE-REF");
													dataTypeDefinitionDateRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionDate.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueDate = defaultValue
															.addElement("ATTRIBUTE-VALUE-DATE");
													attributeValueDate.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueDate.addElement("DEFINITION");
													Element attributeDefinitionDateRef = definition
															.addElement("ATTRIBUTE-DEFINITION-DATE-REF");
													attributeDefinitionDateRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_Boolean")) {
											Element attributrDefinitionBoolean = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-BOOLEAN");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionBoolean.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionBoolean.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionBoolean.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionBoolean.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionBoolean.addElement("TYPE");
													Element dataTypeDefinitionBooleanRef = type
															.addElement("DATATYPE-DEFINITION-BOOLEAN-REF");
													dataTypeDefinitionBooleanRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProDefalutValue) != null) {
													Element defaultValue = attributrDefinitionBoolean
															.addElement("DEFAULT-VALUE");
													String theValue = owlSpecAttributeClass
															.getPropertyValue(annotationProDefalutValue).toString();
													Element attributeValueBoolean = defaultValue
															.addElement("ATTRIBUTE-VALUE-BOOLEAN");
													attributeValueBoolean.addAttribute("THE-VALUE", theValue);
													Element definition = attributeValueBoolean.addElement("DEFINITION");
													Element attributeDefinitionBooleanRef = definition
															.addElement("ATTRIBUTE-DEFINITION-BOOLEAN-REF");
													attributeDefinitionBooleanRef.setText(identifier1);
												}

											}
										} else if (owlAttribute_DefinitionTypeClass.getLocalName()
												.equals("Attribute_Definition_XHTML")) {
											Element attributrDefinitionXHTML = SpecAttributes
													.addElement("ATTRIBUTE-DEFINITION-XHTML");
											String identifier1 = owlSpecAttributeClass.getPropertyValue(annotationProIdentifier)
													.toString();
											String lastChange1 = owlSpecAttributeClass
													.getPropertyValue(annotationProLast_Change).toString();
											attributrDefinitionXHTML.addAttribute("IDENTIFIER", identifier1);
											attributrDefinitionXHTML.addAttribute("LAST-CHANGE", lastChange1);
											if (owlSpecAttributeClass.getPropertyValue(annotationProDesc) != null) {
												String desc = owlSpecAttributeClass.getPropertyValue(annotationProDesc)
														.toString();
												attributrDefinitionXHTML.addAttribute("DESC", desc);
											}
											if (owlSpecAttributeClass.getPropertyValue(annotationProLong_Name) != null) {
												String longName = owlSpecAttributeClass.getPropertyValue(annotationProLong_Name)
														.toString();
												attributrDefinitionXHTML.addAttribute("LONG-NAME", longName);
											}
											for (Iterator it3 = owlSpecAttributeClass.listEquivalentClasses(); it3.hasNext();) {
												OntClass c3 = (OntClass) it3.next();
												Restriction r3 = c3.asRestriction();
												SomeValuesFromRestriction sr3 = r3.asSomeValuesFromRestriction();
												if (sr3.getOnProperty().getLocalName()
														.equals("AttributeDefinition_Ref_DataType")) {
													OntClass owlDataTypeClass = (OntClass) sr3.getSomeValuesFrom();
													String dataTypeDefinitionTypeID = owlDataTypeClass.getLocalName();
													Element type = attributrDefinitionXHTML.addElement("TYPE");
													Element dataTypeDefinitionXHTMLRef = type
															.addElement("DATATYPE-DEFINITION-XHTML-REF");
													dataTypeDefinitionXHTMLRef.setText(dataTypeDefinitionTypeID);
												}
												if (owlSpecAttributeClass.getPropertyValue(annotationProIsSimplified) != null) {
													Element defaultValue = attributrDefinitionXHTML.addElement("DEFAULT-VALUE");
													Element attributeValueXHTML = defaultValue
															.addElement("ATTRIBUTE-VALUE-XHTML");
													String isSimplified = owlSpecAttributeClass
															.getPropertyValue(annotationProIsSimplified).toString();
													attributeValueXHTML.addAttribute("IS-SIMPLIFIED", isSimplified);
													Element theOriginalValue = attributeValueXHTML
															.addElement("THE-ORIGINAL-VALUE");
													Element attributeDefinitionStringRef = attributeValueXHTML
															.addElement("THE-VALUE");
												}

											}
										}
									}
								}
							}	
						}
					}
				}

				// 生成SPEC-OBJECTS
				if(owlReqIFIndividual.getPropertyValue(annotationProSpecObjectsStructure) != null) {
					Element specObjects = reqIFContent.addElement("SPEC-OBJECTS");
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_SpecObject")) {
							Individual specObjectIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());

							Element specObject = specObjects.addElement("SPEC-OBJECT");
							String Identifier = specObjectIndividual.getPropertyValue(annotationProIdentifier).toString();
							String LastChange = specObjectIndividual.getPropertyValue(annotationProLast_Change).toString();
							specObject.addAttribute("IDENTIFIER", Identifier);
							specObject.addAttribute("LAST-CHANGE", LastChange);
							if (specObjectIndividual.getPropertyValue(annotationProDesc) != null) {
								String desc = specObjectIndividual.getPropertyValue(annotationProDesc).toString();
								specObject.addAttribute("DESC", desc);
							}
							if (specObjectIndividual.getPropertyValue(annotationProLong_Name) != null) {
								String longName = specObjectIndividual.getPropertyValue(annotationProLong_Name).toString();
								specObject.addAttribute("LONG-NAME", longName);
							}

							if(specObjectIndividual.getPropertyValue(annotationProValuesStructure) != null) {
								Element values = specObject.addElement("VALUES");
								for (Iterator it2 = specObjectIndividual.listProperties(); it2.hasNext();) {
									Statement owlSpecObjectIndividualPro = (Statement) it2.next();

									if (owlSpecObjectIndividualPro.getPredicate().getLocalName()
											.equals("SpecObject_has_AttributeDefinition")) {
										Individual attributeDefinitionIndividual = ontModel
												.getIndividual(owlSpecObjectIndividualPro.getResource().getURI());
										if (attributeDefinitionIndividual.getPropertyValue(annotationProMark) != null) {
											String type = attributeDefinitionIndividual.getPropertyValue(annotationProMark)
													.toString();
											if (type.equals("XHTML")) {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-XHTML");
												Element definition = attributeValueType.addElement("DEFINITION");
												Element attributeDefinitionTypeRef = definition
														.addElement("ATTRIBUTE-DEFINITION-XHTML-REF");
												String attributeDefinitionTypeRefText = attributeDefinitionIndividual
														.getPropertyValue(annotationProAttributeDefinitionType).toString();
												attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												if (attributeDefinitionIndividual
														.getPropertyValue(annotationProXHTMLDiv) != null) {
													String div = attributeDefinitionIndividual
															.getPropertyValue(annotationProXHTMLDiv).toString();
													Element theValue = attributeValueType.addElement("THE-VALUE");
													Element xhtmlDiv = theValue.addElement("xhtml:div");
													xhtmlDiv.setText(div);
												}
											} else {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-" + type);
												if (attributeDefinitionIndividual
														.getPropertyValue(annotationProTheValue) != null) {
													String theValue = attributeDefinitionIndividual
															.getPropertyValue(annotationProTheValue).toString();
													attributeValueType.addAttribute("THE-VALUE", theValue);
													String attributeDefinitionTypeRefText = attributeDefinitionIndividual
															.getPropertyValue(annotationProAttributeDefinitionType).toString();
													Element definition = attributeValueType.addElement("DEFINITION");
													Element attributeDefinitionTypeRef = definition
															.addElement("ATTRIBUTE-DEFINITION-" + type + "-REF");
													attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												}

											}
										}										
									}
									if (owlSpecObjectIndividualPro.getPredicate().getLocalName()
											.equals("SpecObject_Ref_EnumAttributeDefinition")) {
										Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-ENUMERATION");
										//begin 20231112随Reqif2Owl更新
//										OntClass attributeDefinitionClass = ontModel
//												.getOntClass(owlSpecObjectIndividualPro.getResource().getURI());
										Individual attributeDefinitionIndividual = ontModel
												.getIndividual(owlSpecObjectIndividualPro.getResource().getURI());
										String classId = attributeDefinitionIndividual.getLocalName().substring(0);
										OntClass attributeDefinitionClass = ontModel.getOntClass(METAG + classId);
										
//										for (Iterator it3 = attributeDefinitionClass.listProperties(); it3.hasNext();) {
//											Statement owlAttributeDefinitionClassPro = (Statement) it3.next();
//											if (owlAttributeDefinitionClassPro.getPredicate().getLocalName()
//													.equals("SpecObject_Ref_EnumValue")) {
//												OntClass enumValueRefClass = ontModel
//														.getOntClass(owlAttributeDefinitionClassPro.getResource().getURI());
//												Element valuesEnum = attributeValueType.addElement("VALUES");
//												Element enumValueRef = valuesEnum.addElement("ENUM-VALUE-REF");
//												String enumValueRefText = enumValueRefClass.getLocalName();
//												enumValueRef.setText(enumValueRefText);
//											}
//										}
										for (ExtendedIterator<OntClass> it3 = attributeDefinitionClass.listEquivalentClasses(); it3.hasNext();) {
											OntClass equivalentClass = it3.next();
											ObjectProperty objProSpecObject_Ref_EnumValue = ontModel.getObjectProperty(METAG+ "SpecObject_Ref_EnumValue");
											if (equivalentClass.asRestriction().getOnProperty().equals(objProSpecObject_Ref_EnumValue)) {
												OntClass enumValueRefClass = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
														.getSomeValuesFrom();
												Element valuesEnum = attributeValueType.addElement("VALUES");
												Element enumValueRef = valuesEnum.addElement("ENUM-VALUE-REF");
												String enumValueRefText = enumValueRefClass.getLocalName();
												enumValueRef.setText(enumValueRefText);
											}
										}
										//end 20231112随Reqif2Owl更新
										Element definition = attributeValueType.addElement("DEFINITION");
										Element attributeDefinitionTypeRef = definition
												.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
										String attributeDefinitionTypeRefText = attributeDefinitionClass
												.getLocalName();
										attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
									}
								}
							}
							if (specObjectIndividual.getPropertyValue(annotationProSpecObjectType) != null) {
								String specObjectTypeRefText = specObjectIndividual
										.getPropertyValue(annotationProSpecObjectType).toString();
								Element type = specObject.addElement("TYPE");
								Element specObjectTypeRef = type.addElement("SPEC-OBJECT-TYPE-REF");
								specObjectTypeRef.setText(specObjectTypeRefText);
							}

						}
					}
				}
				
				
				// ...

				// 生成SPEC-RELATIONS
				if(owlReqIFIndividual.getPropertyValue(annotationProSpecRelationsStructure) != null) {
					Element specRelations = reqIFContent.addElement("SPEC-RELATIONS");
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_SpecRelation")) {
							Individual specRelationIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());

							Element specRelation = specRelations.addElement("SPEC-RELATION");
							String Identifier = specRelationIndividual.getPropertyValue(annotationProIdentifier).toString();
							String LastChange = specRelationIndividual.getPropertyValue(annotationProLast_Change)
									.toString();
							specRelation.addAttribute("IDENTIFIER", Identifier);
							specRelation.addAttribute("LAST-CHANGE", LastChange);
							if (specRelationIndividual.getPropertyValue(annotationProDesc) != null) {
								String desc = specRelationIndividual.getPropertyValue(annotationProDesc).toString();
								specRelation.addAttribute("DESC", desc);
							}
							if (specRelationIndividual.getPropertyValue(annotationProLong_Name) != null) {
								String longName = specRelationIndividual.getPropertyValue(annotationProLong_Name)
										.toString();
								specRelation.addAttribute("LONG-NAME", longName);
							}
							// Values
							if(specRelationIndividual.getPropertyValue(annotationProValuesStructure) != null) {
								Element values = specRelation.addElement("VALUES");
								for (Iterator it2 = specRelationIndividual.listProperties(); it2.hasNext();) {
									Statement owlSpecRelationIndividualPro = (Statement) it2.next();
									// 枚举
									OntClass attributeDefinitionClass = null;
									OntClass enumValueRefClass = null;
									if (owlSpecRelationIndividualPro.getPredicate().getLocalName()
											.equals("SpecRelation_Ref_EnumAttributeDefinition")) {
										//begin 20231112随Reqif2Owl更新
//										attributeDefinitionClass = ontModel
//												.getOntClass(owlSpecRelationIndividualPro.getResource().getURI());
										Individual attributeDefinitionIndividual = ontModel
												.getIndividual(owlSpecRelationIndividualPro.getResource().getURI());
										String classId = attributeDefinitionIndividual.getLocalName().substring(0);
										attributeDefinitionClass = ontModel.getOntClass(METAG + classId);
										
//										for (Iterator it3 = attributeDefinitionClass.listProperties(); it3.hasNext();) {
//											Statement owlAttributeDefinitionClassPro = (Statement) it3.next();
//											if (owlAttributeDefinitionClassPro.getPredicate().getLocalName()
//													.equals("SpecRelation_Ref_EnumValue")) {
//												enumValueRefClass = ontModel
//														.getOntClass(owlAttributeDefinitionClassPro.getResource().getURI());
//											}
//										}
										for (ExtendedIterator<OntClass> it3 = attributeDefinitionClass.listEquivalentClasses(); it3.hasNext();) {
											OntClass equivalentClass = it3.next();
											ObjectProperty objProSpecRelation_Ref_EnumValue = ontModel.getObjectProperty(METAG+ "SpecRelation_Ref_EnumValue");
											if (equivalentClass.asRestriction().getOnProperty().equals(objProSpecRelation_Ref_EnumValue)) {
												enumValueRefClass = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
														.getSomeValuesFrom();
											}
										}
										//end 20231112随Reqif2Owl更新
									}
									//
									if (owlSpecRelationIndividualPro.getPredicate().getLocalName()
											.equals("SpecRelation_has_AttributeDefinition")) {
										Individual attributeDefinitionIndividual = ontModel
												.getIndividual(owlSpecRelationIndividualPro.getResource().getURI());
										if (attributeDefinitionIndividual.getPropertyValue(annotationProMark) != null) {
											String type = attributeDefinitionIndividual.getPropertyValue(annotationProMark)
													.toString();
											
											if (type.equals("XHTML")) {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-XHTML");
												Element definition = attributeValueType.addElement("DEFINITION");
												Element attributeDefinitionTypeRef = definition
														.addElement("ATTRIBUTE-DEFINITION-XHTML-REF");
												String attributeDefinitionTypeRefText = attributeDefinitionIndividual
														.getPropertyValue(annotationProAttributeDefinitionType).toString();
												attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												if (attributeDefinitionIndividual
														.getPropertyValue(annotationProXHTMLDiv) != null) {
													String div = attributeDefinitionIndividual
															.getPropertyValue(annotationProXHTMLDiv).toString();
													Element theValue = attributeValueType.addElement("THE-VALUE");
													Element xhtmlDiv = theValue.addElement("xhtml:div");
													xhtmlDiv.setText(div);
												}
											} else if (type.equals("ENUMERATION")) {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-ENUMERATION");
												if (enumValueRefClass != null) {
													Element valuesEnum = attributeValueType.addElement("VALUES");
													Element enumValueRef = attributeValueType.addElement("ENUM-VALUE-REF");
													String enumValueRefText = enumValueRefClass.getLocalName();
													enumValueRef.setText(enumValueRefText);
												}
												if (attributeDefinitionClass != null) {
													Element definition = attributeValueType.addElement("DEFINITION");
													Element attributeDefinitionTypeRef = definition
															.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
													String attributeDefinitionTypeRefText = attributeDefinitionClass
															.getLocalName();
													attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												}
											} else {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-" + type);
												if (attributeDefinitionIndividual
														.getPropertyValue(annotationProTheValue) != null) {
													String theValue = attributeDefinitionIndividual
															.getPropertyValue(annotationProTheValue).toString();
													attributeValueType.addAttribute("THE-VALUE", theValue);
													String attributeDefinitionTypeRefText = attributeDefinitionIndividual
															.getPropertyValue(annotationProAttributeDefinitionType).toString();
													Element definition = attributeValueType.addElement("DEFINITION");
													Element attributeDefinitionTypeRef = definition
															.addElement("ATTRIBUTE-DEFINITION-" + type + "-REF");
													attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												}

											}
										}

									}
								}
							}

							// Target
							for (Iterator it2 = specRelationIndividual.listProperties(); it2.hasNext();) {
								Statement owlSpecRelationIndividualPro = (Statement) it2.next();
								if (owlSpecRelationIndividualPro.getPredicate().getLocalName()
										.equals("SpecRelation_targetRef_SpecObject")) {
									Individual targetIndividual = ontModel
											.getIndividual(owlSpecRelationIndividualPro.getResource().getURI());
									String specObjectRefText = targetIndividual.getLocalName();
									Element target = specRelation.addElement("TARGET");
									Element specObjectRef = target.addElement("SPEC-OBJECT-REF");
									specObjectRef.setText(specObjectRefText);
								}
							}
							// Source
							for (Iterator it2 = specRelationIndividual.listProperties(); it2.hasNext();) {
								Statement owlSpecRelationIndividualPro = (Statement) it2.next();
								if (owlSpecRelationIndividualPro.getPredicate().getLocalName()
										.equals("SpecRelation_sourceRef_SpecObject")) {
									Individual sourceIndividual = ontModel
											.getIndividual(owlSpecRelationIndividualPro.getResource().getURI());
									String specObjectRefText = sourceIndividual.getLocalName();
									Element source = specRelation.addElement("SOURCE");
									Element specObjectRef = source.addElement("SPEC-OBJECT-REF");
									specObjectRef.setText(specObjectRefText);
								}
							}
							// Type
							if (specRelationIndividual.getPropertyValue(annotationProSpecRelationType) != null) {
								String specRelationTypeRefText = specRelationIndividual
										.getPropertyValue(annotationProSpecRelationType).toString();
								Element type = specRelation.addElement("TYPE");
								Element specRelationTypeRef = type.addElement("SPEC-RELATION-TYPE-REF");
								specRelationTypeRef.setText(specRelationTypeRefText);
							}

						}
					}
				}
				
				

				// ...

				// 生成SPECIFICATIONS
				if(owlReqIFIndividual.getPropertyValue(annotationProSpecificationsStructure) != null) {
					Element specifications = reqIFContent.addElement("SPECIFICATIONS");
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_Specification")) {
							Individual specificationIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());

							Element specification = specifications.addElement("SPECIFICATION");
							String Identifier = specificationIndividual.getPropertyValue(annotationProIdentifier)
									.toString();
							String LastChange = specificationIndividual.getPropertyValue(annotationProLast_Change)
									.toString();
							specification.addAttribute("IDENTIFIER", Identifier);
							specification.addAttribute("LAST-CHANGE", LastChange);
							if (specificationIndividual.getPropertyValue(annotationProDesc) != null) {
								String desc = specificationIndividual.getPropertyValue(annotationProDesc).toString();
								specification.addAttribute("DESC", desc);
							}
							if (specificationIndividual.getPropertyValue(annotationProLong_Name) != null) {
								String longName = specificationIndividual.getPropertyValue(annotationProLong_Name)
										.toString();
								specification.addAttribute("LONG-NAME", longName);
							}
							if(specificationIndividual.getPropertyValue(annotationProValuesStructure) != null) {
								Element values = specification.addElement("VALUES");
								for (Iterator it2 = specificationIndividual.listProperties(); it2.hasNext();) {
									Statement owlSpecificationIndividualPro = (Statement) it2.next();
									// 枚举
									OntClass attributeDefinitionClass = null;
									OntClass enumValueRefClass = null;
									if (owlSpecificationIndividualPro.getPredicate().getLocalName()
											.equals("Specification_Ref_EnumAttributeDefinition")) {
										//begin 20231112随Reqif2Owl更新
//										attributeDefinitionClass = ontModel
//												.getOntClass(owlSpecificationIndividualPro.getResource().getURI());
										Individual attributeDefinitionIndividual = ontModel
												.getIndividual(owlSpecificationIndividualPro.getResource().getURI());
										String classId = attributeDefinitionIndividual.getLocalName().substring(0);
										attributeDefinitionClass = ontModel.getOntClass(METAG + classId);
										//end 20231112随Reqif2Owl更新
//										for (Iterator it3 = attributeDefinitionClass.listProperties(); it3.hasNext();) {
//											Statement owlAttributeDefinitionClassPro = (Statement) it3.next();
//											if (owlAttributeDefinitionClassPro.getPredicate().getLocalName()
//													.equals("Specification_Ref_EnumValue")) {
//												enumValueRefClass = ontModel
//														.getOntClass(owlAttributeDefinitionClassPro.getResource().getURI());
//											}
//										}
										for (ExtendedIterator<OntClass> it3 = attributeDefinitionClass.listEquivalentClasses(); it3.hasNext();) {
											OntClass equivalentClass = it3.next();
											ObjectProperty objProSpecification_Ref_EnumValue = ontModel.getObjectProperty(METAG+ "Specification_Ref_EnumValue");
											if (equivalentClass.asRestriction().getOnProperty().equals(objProSpecification_Ref_EnumValue)) {
												enumValueRefClass = (OntClass) equivalentClass.asRestriction().asSomeValuesFromRestriction()
														.getSomeValuesFrom();
											}
										}
									}
									//
									if (owlSpecificationIndividualPro.getPredicate().getLocalName()
											.equals("Specification_has_AttributeDefinition")) {
										Individual attributeDefinitionIndividual = ontModel
												.getIndividual(owlSpecificationIndividualPro.getResource().getURI());
										if (attributeDefinitionIndividual.getPropertyValue(annotationProMark) != null) {
											String type = attributeDefinitionIndividual.getPropertyValue(annotationProMark)
													.toString();
											
											if (type.equals("XHTML")) {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-XHTML");
												Element definition = attributeValueType.addElement("DEFINITION");
												Element attributeDefinitionTypeRef = definition
														.addElement("ATTRIBUTE-DEFINITION-XHTML-REF");
												String attributeDefinitionTypeRefText = attributeDefinitionIndividual
														.getPropertyValue(annotationProAttributeDefinitionType).toString();
												attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												if (attributeDefinitionIndividual
														.getPropertyValue(annotationProXHTMLDiv) != null) {
													String div = attributeDefinitionIndividual
															.getPropertyValue(annotationProXHTMLDiv).toString();
													Element theValue = attributeValueType.addElement("THE-VALUE");
													Element xhtmlDiv = theValue.addElement("xhtml:div");
													xhtmlDiv.setText(div);
												}
											} else if (type.equals("ENUMERATION")) {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-ENUMERATION");
												if (enumValueRefClass != null) {
													Element valuesEnum = attributeValueType.addElement("VALUES");
													Element enumValueRef = attributeValueType.addElement("ENUM-VALUE-REF");
													String enumValueRefText = enumValueRefClass.getLocalName();
													enumValueRef.setText(enumValueRefText);
												}
												if (attributeDefinitionClass != null) {
													Element definition = attributeValueType.addElement("DEFINITION");
													Element attributeDefinitionTypeRef = definition
															.addElement("ATTRIBUTE-DEFINITION-ENUMERATION-REF");
													String attributeDefinitionTypeRefText = attributeDefinitionClass
															.getLocalName();
													attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												}
											} else {
												Element attributeValueType = values.addElement("ATTRIBUTE-VALUE-" + type);
												if (attributeDefinitionIndividual
														.getPropertyValue(annotationProTheValue) != null) {
													String theValue = attributeDefinitionIndividual
															.getPropertyValue(annotationProTheValue).toString();
													attributeValueType.addAttribute("THE-VALUE", theValue);
													String attributeDefinitionTypeRefText = attributeDefinitionIndividual
															.getPropertyValue(annotationProAttributeDefinitionType).toString();
													Element definition = attributeValueType.addElement("DEFINITION");
													Element attributeDefinitionTypeRef = definition
															.addElement("ATTRIBUTE-DEFINITION-" + type + "-REF");
													attributeDefinitionTypeRef.setText(attributeDefinitionTypeRefText);
												}

											}
										}

									}
								}
							}
							

							if (specificationIndividual.getPropertyValue(annotationProSpecificationType) != null) {
								String specificationTypeRefText = specificationIndividual
										.getPropertyValue(annotationProSpecificationType).toString();
								Element type = specification.addElement("TYPE");
								Element specificationTypeRef = type.addElement("SPECIFICATION-TYPE-REF");
								specificationTypeRef.setText(specificationTypeRefText);
							}
							// SpecHierarchy
							if(specificationIndividual.getPropertyValue(annotationProChildrenStructure) != null) {
								Element children = specification.addElement("CHILDREN");
								for (Iterator it3 = specificationIndividual.listProperties(); it3.hasNext();) {
									Statement specificationIndividualPro = (Statement) it3.next();
									if (specificationIndividualPro.getPredicate().getLocalName()
											.equals("Specification_has_SpecHierarchy")) {
										Individual specHierarchyIndividual = ontModel
												.getIndividual(specificationIndividualPro.getResource().getURI());
										Element specHierarchy = children.addElement("SPEC-HIERARCHY");
										String identifier = specHierarchyIndividual.getPropertyValue(annotationProIdentifier)
												.toString();
										String lastChange = specHierarchyIndividual.getPropertyValue(annotationProLast_Change)
												.toString();
										specHierarchy.addAttribute("IDENTIFIER", identifier);
										specHierarchy.addAttribute("LAST-CHANGE", lastChange);

										generateChildren(specHierarchyIndividual, specHierarchy, ontModel);
									}

								}
							}							
						}
					}
				}
				
				// ...

				// SPEC-RELATION-GROUPS
				if(owlReqIFIndividual.getPropertyValue(annotationProSpecRelationGroupStructure) != null) {
					Element specRelationGroup = reqIFContent.addElement("SPEC-RELATION-GROUPS");
					for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
						Statement owlReqIFIndividualPro = (Statement) it.next();
						if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_RelationGroup")) {
							Individual relationGroupIndividual = ontModel
									.getIndividual(owlReqIFIndividualPro.getResource().getURI());

							Element relationGroup = specRelationGroup.addElement("RELATION-GROUP");
							String Identifier = relationGroupIndividual.getPropertyValue(annotationProIdentifier)
									.toString();
							String LastChange = relationGroupIndividual.getPropertyValue(annotationProLast_Change)
									.toString();
							relationGroup.addAttribute("IDENTIFIER", Identifier);
							relationGroup.addAttribute("LAST-CHANGE", LastChange);
							if (relationGroupIndividual.getPropertyValue(annotationProDesc) != null) {
								String desc = relationGroupIndividual.getPropertyValue(annotationProDesc).toString();
								relationGroup.addAttribute("DESC", desc);
							}
							if (relationGroupIndividual.getPropertyValue(annotationProLong_Name) != null) {
								String longName = relationGroupIndividual.getPropertyValue(annotationProLong_Name)
										.toString();
								relationGroup.addAttribute("LONG-NAME", longName);
							}

							Boolean flag = false;
							for (Iterator it2 = relationGroupIndividual.listProperties(); it2.hasNext();) {
								Statement owlrelationGroupIndividualPro = (Statement) it2.next();
								if (owlrelationGroupIndividualPro.getPredicate().getLocalName()
										.equals("RelationGoup_Ref_SpecRelation")) {
									flag = true;
								}
							}
							Element specRelations_RelationGroup = null;
							if (flag) {
								specRelations_RelationGroup = relationGroup.addElement("SPEC-RELATIONS");
							}
							for (Iterator it2 = relationGroupIndividual.listProperties(); it2.hasNext();) {
								Statement owlrelationGroupIndividualPro = (Statement) it2.next();
								if (owlrelationGroupIndividualPro.getPredicate().getLocalName()
										.equals("RelationGoup_Ref_SpecRelation")) {
									Individual specRelationIndividual = ontModel
											.getIndividual(owlrelationGroupIndividualPro.getResource().getURI());
									Element specRelationRef = specRelations_RelationGroup.addElement("SPEC-RELATION-REF");
									specRelationRef.setText(specRelationIndividual.getLocalName());

								}
								if (owlrelationGroupIndividualPro.getPredicate().getLocalName()
										.equals("RelationGoup_sourceRef_Specification")) {
									Individual specificationIndividual = ontModel
											.getIndividual(owlrelationGroupIndividualPro.getResource().getURI());
									Element sourceSpecification = relationGroup.addElement("SOURCE-SPECIFICATION");
									Element specificationRef = sourceSpecification.addElement("SPECIFICATION-REF");
									specificationRef.setText(specificationIndividual.getLocalName());
								}
								if (owlrelationGroupIndividualPro.getPredicate().getLocalName()
										.equals("RelationGoup_targetRef_Specification")) {
									Individual specificationIndividual = ontModel
											.getIndividual(owlrelationGroupIndividualPro.getResource().getURI());
									Element targetSpecification = relationGroup.addElement("TARGET-SPECIFICATION");
									Element specificationRef = targetSpecification.addElement("SPECIFICATION-REF");
									specificationRef.setText(specificationIndividual.getLocalName());
								}
							}

							// Type
							if (relationGroupIndividual.getPropertyValue(annotationProSpecObjectType) != null) {
								String relationGroupTypeRefText = relationGroupIndividual
										.getPropertyValue(annotationProRelationGroupType).toString();
								Element type = relationGroup.addElement("TYPE");
								Element relationGroupTypeRef = type.addElement("RELATION-GROUP-TYPE-REF");
								relationGroupTypeRef.setText(relationGroupTypeRefText);
							}

						}
					}
				}
				
				
				// ...

				// 生成TOOL-EXTENSIONS, Configuration
				Element toolExtensions = root.addElement("TOOL-EXTENSIONS");
				Element reqIFToolExtension = toolExtensions.addElement("REQ-IF-TOOL-EXTENSION");
				Element configurationProrToolExtension = reqIFToolExtension
						.addElement("configuration:ProrToolExtension");
				// 生成specViewConfigurations
				Element configurationSpecViewConfigurations = configurationProrToolExtension
						.addElement("configuration:specViewConfigurations");

				for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
					Statement owlReqIFIndividualPro = (Statement) it.next();

					if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_Specification")) {
						Element configurationProrSpecViewConfiguration = configurationSpecViewConfigurations
								.addElement("configuration:ProrSpecViewConfiguration");
						Individual specificationIndividual = ontModel
								.getIndividual(owlReqIFIndividualPro.getResource().getURI());
						String specification = specificationIndividual.getLocalName();
						configurationProrSpecViewConfiguration.addAttribute("specification", specification);

						Element configurationColumns = configurationProrSpecViewConfiguration
								.addElement("configuration:columns");
						int size = 0;
						for (Iterator it2 = specificationIndividual.listProperties(); it2.hasNext();) {
							Statement owlspecificationIndividualPro = (Statement) it2.next();
							if (owlspecificationIndividualPro.getPredicate().getLocalName()
									.equals("Specification_has_Column")) {
								Individual columnIndividual = ontModel
										.getIndividual(owlspecificationIndividualPro.getResource().getURI());
								// 列顺序
								if (columnIndividual.getPropertyValue(annotationProSequence) != null) {
									size++;
								}
							}
						}
						Individual[] individualList = new Individual[size];
						for (Iterator it2 = specificationIndividual.listProperties(); it2.hasNext();) {
							Statement owlspecificationIndividualPro = (Statement) it2.next();
							if (owlspecificationIndividualPro.getPredicate().getLocalName()
									.equals("Specification_has_Column")) {
								Individual columnIndividual = ontModel
										.getIndividual(owlspecificationIndividualPro.getResource().getURI());
								// 列顺序
								if (columnIndividual.getPropertyValue(annotationProSequence) != null) {
									String sequence = columnIndividual.getPropertyValue(annotationProSequence)
											.toString();
									Integer integerObject = Integer.valueOf(sequence);
									int number = integerObject.intValue() - 1;
									individualList[number] = columnIndividual;
								}

								if (columnIndividual.getPropertyValue(annotationProMark) != null && columnIndividual
										.getPropertyValue(annotationProMark).toString().equals("leftHeaderColumn")) {
									Element configurationLeftHeaderColumn = configurationProrSpecViewConfiguration
											.addElement("configuration:leftHeaderColumn");
									Element configurationColumn = configurationLeftHeaderColumn
											.addElement("configuration:Column");
									if (columnIndividual.getPropertyValue(annotationProLabel) != null) {
										String label = columnIndividual.getPropertyValue(annotationProLabel).toString();
										configurationColumn.addAttribute("label", label);
									}
									if (columnIndividual.getPropertyValue(annotationProWidth) != null) {
										String width = columnIndividual.getPropertyValue(annotationProWidth).toString();
										configurationColumn.addAttribute("width", width);
									}
								}
							}
						}
						for (int i = 0; i < individualList.length; i++) {
							Individual columnIndividualSequence = individualList[i];
							if (columnIndividualSequence.getPropertyValue(annotationProMark) != null
									&& columnIndividualSequence.getPropertyValue(annotationProMark).toString()
											.equals("UnifiedColumn")) {
								Element configurationUnifiedColumn = configurationColumns
										.addElement("configuration:UnifiedColumn");
								if (columnIndividualSequence.getPropertyValue(annotationProLabel) != null) {
									String label = columnIndividualSequence.getPropertyValue(annotationProLabel)
											.toString();
									configurationUnifiedColumn.addAttribute("label", label);
								}
								if (columnIndividualSequence.getPropertyValue(annotationProWidth) != null) {
									String width = columnIndividualSequence.getPropertyValue(annotationProWidth)
											.toString();
									configurationUnifiedColumn.addAttribute("width", width);
								}
							}

							if (columnIndividualSequence.getPropertyValue(annotationProMark) == null) {
								Element configurationColumn = configurationColumns.addElement("configuration:Column");
								if (columnIndividualSequence.getPropertyValue(annotationProLabel) != null) {
									String label = columnIndividualSequence.getPropertyValue(annotationProLabel)
											.toString();
									configurationColumn.addAttribute("label", label);
								}
								if (columnIndividualSequence.getPropertyValue(annotationProWidth) != null) {
									String width = columnIndividualSequence.getPropertyValue(annotationProWidth)
											.toString();
									configurationColumn.addAttribute("width", width);
								}
							}
						}

					}
				}

				// 生成generalConfiguration
				Element configurationGeneralConfiguration = configurationProrToolExtension
						.addElement("configuration:generalConfiguration");
				Element configurationProrGeneralConfiguration = configurationGeneralConfiguration
						.addElement("configuration:ProrGeneralConfiguration");
				Element configurationlabelConfiguration = configurationProrGeneralConfiguration
						.addElement("configuration:labelConfiguration");
				Element configurationLabelConfiguration = configurationlabelConfiguration
						.addElement("configuration:LabelConfiguration");
				int defaultLabelNumber = 0;
				for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
					Statement owlReqIFIndividualPro = (Statement) it.next();
					if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_defaultLabel")) {
						defaultLabelNumber++;
					}
				}
				String[] defaultLabelArray = new String[defaultLabelNumber];
				for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
					Statement owlReqIFIndividualPro = (Statement) it.next();
					if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_defaultLabel")) {
						Individual defaultLabelIndividual = ontModel
								.getIndividual(owlReqIFIndividualPro.getResource().getURI());
						String se = defaultLabelIndividual.getPropertyValue(annotationProSequence).toString();
						Integer integerObject = Integer.valueOf(se);
						int number = integerObject.intValue();
						String defaultLabelValue = defaultLabelIndividual.getPropertyValue(annotationProDefalutLabel)
								.toString();
						defaultLabelArray[number - 1] = defaultLabelValue;
					}
				}
				for (int i = 0; i < defaultLabelNumber; i++) {
					Element defaultLabel = configurationLabelConfiguration.addElement("defaultLabel");
					defaultLabel.setText(defaultLabelArray[i]);
				}

				// 生成presentationConfigurations
				Element configurationPresentationConfigurations = configurationProrToolExtension
						.addElement("configuration:presentationConfigurations");
				Element configurationProrPresentationConfigurations = configurationPresentationConfigurations
						.addElement("configuration:ProrPresentationConfigurations");

				Element configurationPresentationConfigurationsIn = configurationProrPresentationConfigurations
						.addElement("configuration:presentationConfigurations");

				for (Iterator it = owlReqIFIndividual.listProperties(); it.hasNext();) {
					Statement owlReqIFIndividualPro = (Statement) it.next();
					// linewrap:LinewrapConfiguration
					if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_LinewrapConfiguration")) {
						Individual linewrapConfigurationIndividual = ontModel
								.getIndividual(owlReqIFIndividualPro.getResource().getURI());

						Namespace linewrapNamespace = Namespace.get("linewrap",
								"http://pror.org/presentation/linewrap");
						// 创建 linewrap:LinewrapConfiguration 元素
						QName linewrapConfigQName = new QName("LinewrapConfiguration", linewrapNamespace);
						Element linewrapLinewrapConfiguration = configurationPresentationConfigurationsIn
								.addElement(linewrapConfigQName);

						for (Iterator it2 = linewrapConfigurationIndividual.listProperties(); it2.hasNext();) {
							Statement owllinewrapConfigurationIndividualPro = (Statement) it2.next();

							if (owllinewrapConfigurationIndividualPro.getPredicate().getLocalName()
									.equals("LinewrapConfiguration_Apply_DataType")) {
								//begin 20231112随Reqif2Owl更新
//								OntClass datatypeClass = ontModel
//										.getOntClass(owllinewrapConfigurationIndividualPro.getResource().getURI());
//								String datatype = datatypeClass.getLocalName();
								Individual owldataTypeIndividual = ontModel
										.getIndividual(owllinewrapConfigurationIndividualPro.getResource().getURI());
								String datatype = owldataTypeIndividual.getLocalName().substring(0);
								//end 20231112随Reqif2Owl更新
								linewrapLinewrapConfiguration.addAttribute("datatype", datatype);
							}
						}
					}
					// id:IdConfiguration
					if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_IdConfiguration")) {
						Individual idConfigurationIndividual = ontModel
								.getIndividual(owlReqIFIndividualPro.getResource().getURI());

						Namespace idNamespace = Namespace.get("id", "http://pror.org/presentation/id");
						// 创建 id:IdConfiguration 元素
						QName idConfigQName = new QName("IdConfiguration", idNamespace);
						Element idIdConfiguration = configurationPresentationConfigurationsIn.addElement(idConfigQName);

						for (Iterator it2 = idConfigurationIndividual.listProperties(); it2.hasNext();) {
							Statement owlidConfigurationIndividualPro = (Statement) it2.next();

							if (owlidConfigurationIndividualPro.getPredicate().getLocalName()
									.equals("IdConfiguration_Apply_DataType")) {
								//begin 20231112随Reqif2Owl更新
//								OntClass datatypeClass = ontModel
//										.getOntClass(owlidConfigurationIndividualPro.getResource().getURI());
//								String datatype = datatypeClass.getLocalName();
								Individual owldataTypeIndividual = ontModel
										.getIndividual(owlidConfigurationIndividualPro.getResource().getURI());
								String datatype = owldataTypeIndividual.getLocalName().substring(0);
								//end 20231112随Reqif2Owl更新
								idIdConfiguration.addAttribute("datatype", datatype);
							}
							if (idConfigurationIndividual.getPropertyValue(annotationProPrefix) != null) {
								String prefix = idConfigurationIndividual.getPropertyValue(annotationProPrefix)
										.toString();
								idIdConfiguration.addAttribute("prefix", prefix);
							}
							if (idConfigurationIndividual.getPropertyValue(annotationProCount) != null) {
								String count = idConfigurationIndividual.getPropertyValue(annotationProCount)
										.toString();
								idIdConfiguration.addAttribute("count", count);
							}
							if (idConfigurationIndividual.getPropertyValue(annotationProVerticalAlign) != null) {
								String verticalAlign = idConfigurationIndividual
										.getPropertyValue(annotationProVerticalAlign).toString();
								idIdConfiguration.addAttribute("verticalAlign", verticalAlign);
							}
						}
					}
					// headline:HeadlineConfiguration
					if (owlReqIFIndividualPro.getPredicate().getLocalName().equals("ReqIF_own_HeadlineConfiguration")) {
						Individual headlineConfigurationIndividual = ontModel
								.getIndividual(owlReqIFIndividualPro.getResource().getURI());

						Namespace headlineNamespace = Namespace.get("headline",
								"http://pror.org/presentation/headline");
						// 创建 headline:HeadlineConfiguration 元素
						QName headlineConfigQName = new QName("HeadlineConfiguration", headlineNamespace);
						Element headlineHeadlineConfiguration = configurationPresentationConfigurationsIn
								.addElement(headlineConfigQName);

						for (Iterator it2 = headlineConfigurationIndividual.listProperties(); it2.hasNext();) {
							Statement owlheadlineConfigurationIndividualPro = (Statement) it2.next();

							if (owlheadlineConfigurationIndividualPro.getPredicate().getLocalName()
									.equals("HeadlineConfiguration_Apply_DataType")) {
								//begin 20231112随Reqif2Owl更新
//								OntClass datatypeClass = ontModel
//										.getOntClass(owlheadlineConfigurationIndividualPro.getResource().getURI());
//								String datatype = datatypeClass.getLocalName();
								Individual owldataTypeIndividual = ontModel
										.getIndividual(owlheadlineConfigurationIndividualPro.getResource().getURI());
								String datatype = owldataTypeIndividual.getLocalName().substring(0);
								//end 20231112随Reqif2Owl更新
								headlineHeadlineConfiguration.addAttribute("datatype", datatype);
							}
						}
						if (headlineConfigurationIndividual.getPropertyValue(annotationProSize) != null) {
							String size = headlineConfigurationIndividual.getPropertyValue(annotationProSize)
									.toString();
							headlineHeadlineConfiguration.addAttribute("size", size);
						}
					}

				}
				// ...

				// end
//		
//				String name = owlReqIFIndividual.getLocalName();
				String name = owlReqIFIndividual.getPropertyValue(annotationProTitle).toString();
				IFolder languageFolder = languagesFolder
						.getFolder(owlReqIFIndividual.getPropertyValue(annotationPropertyModelLocation).toString());
				IFolder modelFolder = null;
//				F/需求项目测试_BFO/语言/KwoYRXB0O/model
				IFolder modelFolder1 = languageFolder.getFolder(PackagePath.TYPE_MODEL);
//				F/需求项目测试_BFO/语言/KwoYRXB0O/模型
				IFolder modelFolder2 = languageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
				if (modelFolder1.exists()) {
					modelFolder = modelFolder1;
				} else if (modelFolder2.exists()) {
					modelFolder = modelFolder2;
				}

				String fileName = modelFolder.getLocation().toOSString() + "/" + name + ".reqif";
//				String fileName = "D:\\runtime-MetaGraph\\测试GOPPRRE_BFO\\语言\\GOPPRE\\模型\\My.reqif";
				
				OutputFormat format = OutputFormat.createPrettyPrint();
				format.setEncoding("UTF-8");
				format.setNewLineAfterDeclaration(false);
				XMLWriter writer = new XMLWriter(new FileOutputStream(new File(fileName)), format);
				writer.write(document);
				writer.close();

				IFile modelFile = modelFolder.getFile(name + ".reqif");
				modelFile.refreshLocal(IResource.DEPTH_ZERO, null);
			}
		}
	}

	private static void generateChildren(Individual specHierarchyIndividual, Element specHierarchy, OntModel ontModel) {
		AnnotationProperty annotationProIdentifier = ontModel.getAnnotationProperty(METAG + "identifier");
		AnnotationProperty annotationProLast_Change = ontModel.getAnnotationProperty(METAG + "Last_Change");

		for (Iterator it = specHierarchyIndividual.listProperties(); it.hasNext();) {
			Statement specHierarchyIndividualPro = (Statement) it.next();
			if (specHierarchyIndividualPro.getPredicate().getLocalName().equals("SpecHierarchy_Ref_SpecObject")) {
				Individual objectIndividual = ontModel.getIndividual(specHierarchyIndividualPro.getResource().getURI());
				Element object = specHierarchy.addElement("OBJECT");
				Element specObjectRef = object.addElement("SPEC-OBJECT-REF");
				specObjectRef.setText(objectIndividual.getLocalName());
			}
			if (specHierarchyIndividualPro.getPredicate().getLocalName().equals("SpecHierarchy_has_SpecHierarchy")) {
				Individual specHierarchyIndividualIn = ontModel
						.getIndividual(specHierarchyIndividualPro.getResource().getURI());
				Element children = specHierarchy.addElement("CHILDREN");
				Element specHierarchyIn = children.addElement("SPEC-HIERARCHY");
				String identifier = specHierarchyIndividualIn.getPropertyValue(annotationProIdentifier).toString();
				String lastChange = specHierarchyIndividualIn.getPropertyValue(annotationProLast_Change).toString();
				specHierarchyIn.addAttribute("IDENTIFIER", identifier);
				specHierarchyIn.addAttribute("LAST-CHANGE", lastChange);
				generateChildren(specHierarchyIndividualIn, specHierarchyIn, ontModel);
			}
		}
	}
}
