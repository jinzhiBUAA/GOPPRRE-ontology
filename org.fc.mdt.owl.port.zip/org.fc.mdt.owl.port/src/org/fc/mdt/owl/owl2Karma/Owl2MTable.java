package org.fc.mdt.owl.owl2Karma;

import java.awt.List;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.ObjectProperty;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;

public class Owl2MTable {

	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
	
	/**
	 * 读取owl文件
	 * @author xiaodu
	 * @param owlFilePath
	 */
	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}
	
	/** 生成MTable的方法重载
	 * @author xiaodu
	 * */
	public static void GenerateMTable(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException {
		OntModel ontModel = readOwlFile(owlFilePath);
		GenerateMTable(ontModel, languagesFolder, monitor);
	}

	public static void GenerateMTable(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */

		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);

		// 获取类
		OntClass owlMapping_TableClass = ontModel.getOntClass(METAG + "Mapping_Table");
		OntClass owlMapping_Table_ColumnClass = ontModel.getOntClass(METAG + "Mapping_Table_Column");
		OntClass owlMapping_Table_RowClass = ontModel.getOntClass(METAG + "Mapping_Table_Row");
		OntClass owlMapping_Table_LinkClass = ontModel.getOntClass(METAG + "Mapping_Table_Link");

		// 获取annotaiton property
		AnnotationProperty annotationProName = ontModel.createAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationProlocalLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationProId = ontModel.createAnnotationProperty(METAG + "id");
		AnnotationProperty annotationProText = ontModel.createAnnotationProperty(METAG + "text");
		// 获取mTable标记语言
		AnnotationProperty annotationPropertyModelLocation = ontModel.createAnnotationProperty(METAG + "modelLocation");
		// 获取非一定存在annotaiton property
		AnnotationProperty annotationProModel_Id = ontModel.createAnnotationProperty(METAG + "model_id");
		AnnotationProperty annotationProMeta_Model = ontModel.createAnnotationProperty(METAG + "meta_model");
		AnnotationProperty annotationProMeta_Property_Instance_Id = ontModel
				.createAnnotationProperty(METAG + "meta_property_instance_id");
		AnnotationProperty annotationProMeta_Property_Instance_Type = ontModel
				.createAnnotationProperty(METAG + "meta_property_instance_type");
		AnnotationProperty annotationProMeta_Property_Instance_Text = ontModel
				.createAnnotationProperty(METAG + "meta_property_instance_text");

		// 一个owlMapping_TableIndividual是一个mTable文件
		for (Iterator it = owlMapping_TableClass.listInstances(); it.hasNext();) {
			Individual owlMapping_TableIndividual = (Individual) it.next();
			String name = owlMapping_TableIndividual.getPropertyValue(annotationProName).toString();
			String filename = name;
			Document document = DocumentHelper.createDocument();
			Element KARMA_external_plugin = document.addElement("KARMA_external_plugin");
			Element Mapping_Table = KARMA_external_plugin.addElement("Mapping_Table");
			Mapping_Table.addAttribute("Name", name);
			if (owlMapping_TableIndividual.getPropertyValue(annotationProlocalLabel) != null) {
				String localLabel = owlMapping_TableIndividual.getPropertyValue(annotationProlocalLabel).toString();
				Mapping_Table.addAttribute("localLabel", localLabel);
				filename = localLabel;
			}
			Element theHeader = Mapping_Table.addElement("THE-HEADER");
			Element rowHeader = theHeader.addElement("ROW-HEADER");
			Element columnHeader = theHeader.addElement("COLUMN-HEADER");
			Element link = Mapping_Table.addElement("LINK");
			// ROW_HEADER内容(由于本体的原因生成的顺序相反)
			for (Iterator It = owlMapping_TableIndividual.listProperties(); It.hasNext();) {
				Statement owlMappingTableIndividualPro = (Statement) It.next();
				if (owlMappingTableIndividualPro.getPredicate().getLocalName().equals("ownMappingRow")) {
					Individual owlMappingRow = ontModel
							.getIndividual(owlMappingTableIndividualPro.getResource().getURI());

					for (Iterator it_r = owlMapping_Table_RowClass.listInstances(); it_r.hasNext();) {
						Individual owlMappingRowE = (Individual) it_r.next();
						if (owlMappingRow.getPropertyValue(annotationProId) != null) {
							if (owlMappingRow.getLocalName().equals(owlMappingRowE.getLocalName())) {
								Element ROW = rowHeader.addElement("ROW");
								String row_Id = owlMappingRow.getPropertyValue(annotationProId).toString();
								ROW.addAttribute("id", row_Id);
								if (owlMappingRow.getPropertyValue(annotationProModel_Id) != null) {
									String model_Id = owlMappingRow.getPropertyValue(annotationProModel_Id).toString();
									ROW.addAttribute("model_id", model_Id);
								}
								if (owlMappingRow.getPropertyValue(annotationProMeta_Model) != null) {
									String meta_Model = owlMappingRow.getPropertyValue(annotationProMeta_Model)
											.toString();
									ROW.addAttribute("meta_model", meta_Model);
								}
								String row_Text = owlMappingRow.getPropertyValue(annotationProText).toString();
								ROW.setText(row_Text);
								if (owlMappingRow.getPropertyValue(annotationProMeta_Property_Instance_Id) != null) {
									String meta_Property_Instance_Id = owlMappingRow
											.getPropertyValue(annotationProMeta_Property_Instance_Id).toString();
									Element meta_Property_Instance = ROW.addElement("meta_property_instance");
									meta_Property_Instance.addAttribute("meta_property_instance_id",
											meta_Property_Instance_Id);
									if (owlMappingRow
											.getPropertyValue(annotationProMeta_Property_Instance_Type) != null) {
										String meta_Property_Instance_Type = owlMappingRow
												.getPropertyValue(annotationProMeta_Property_Instance_Type).toString();
										meta_Property_Instance.addAttribute("meta_property_instance_type",
												meta_Property_Instance_Type);
									}
									if (owlMappingRow
											.getPropertyValue(annotationProMeta_Property_Instance_Text) != null) {
										String meta_Property_Instance_Text = owlMappingRow
												.getPropertyValue(annotationProMeta_Property_Instance_Text).toString();
										meta_Property_Instance.setText(meta_Property_Instance_Text);
									}
								}
							}
						}
					}
				}
			}
			// CLOUMN_HEADER内容
			for (Iterator It = owlMapping_TableIndividual.listProperties(); It.hasNext();) {
				Statement owlMappingTableIndividualPro = (Statement) It.next();
				if (owlMappingTableIndividualPro.getPredicate().getLocalName().equals("ownMappingColumn")) {
					Individual owlMappingColumn = ontModel
							.getIndividual(owlMappingTableIndividualPro.getResource().getURI());
					for (Iterator it_c = owlMapping_Table_ColumnClass.listInstances(); it_c.hasNext();) {
						Individual owlMappingColumnE = (Individual) it_c.next();
						if (owlMappingColumn.getPropertyValue(annotationProId) != null) {
							if (owlMappingColumn.getLocalName().equals(owlMappingColumnE.getLocalName())) {
								Element Column = columnHeader.addElement("COLUMN");
								String column_Id = owlMappingColumn.getPropertyValue(annotationProId).toString();
								Column.addAttribute("id", column_Id);
								if (owlMappingColumn.getPropertyValue(annotationProModel_Id) != null) {
									String model_Id = owlMappingColumn.getPropertyValue(annotationProModel_Id).toString();
									Column.addAttribute("model_id", model_Id);
								}
								if (owlMappingColumn.getPropertyValue(annotationProMeta_Model) != null) {
									String meta_Model = owlMappingColumn.getPropertyValue(annotationProMeta_Model)
											.toString();
									Column.addAttribute("meta_model", meta_Model);
								}
								String column_Text = owlMappingColumn.getPropertyValue(annotationProText).toString();
								Column.setText(column_Text);
								if (owlMappingColumn.getPropertyValue(annotationProMeta_Property_Instance_Id) != null) {
									String meta_Property_Instance_Id = owlMappingColumn
											.getPropertyValue(annotationProMeta_Property_Instance_Id).toString();
									Element meta_Property_Instance = Column.addElement("meta_property_instance");
									meta_Property_Instance.addAttribute("meta_property_instance_id",
											meta_Property_Instance_Id);
									if (owlMappingColumn
											.getPropertyValue(annotationProMeta_Property_Instance_Type) != null) {
										String meta_Property_Instance_Type = owlMappingColumn
												.getPropertyValue(annotationProMeta_Property_Instance_Type).toString();
										meta_Property_Instance.addAttribute("meta_property_instance_type",
												meta_Property_Instance_Type);
									}
									if (owlMappingColumn
											.getPropertyValue(annotationProMeta_Property_Instance_Text) != null) {
										String meta_Property_Instance_Text = owlMappingColumn
												.getPropertyValue(annotationProMeta_Property_Instance_Text).toString();
										meta_Property_Instance.setText(meta_Property_Instance_Text);
									}
								}
							}
						}
					
					}
				}
			}
			// LINK内容

			// 优化后
			ArrayList<String> listRow = new ArrayList<String>();
			ArrayList<String> listColumn = new ArrayList<String>();
			for (Iterator It = owlMapping_TableIndividual.listProperties(); It.hasNext();) {
				Statement owlMappingTableIndividualPro = (Statement) It.next();
				if (owlMappingTableIndividualPro.getPredicate().getLocalName().equals("ownMappingRow")) {
					Individual owlMLinkFromRow = ontModel
							.getIndividual(owlMappingTableIndividualPro.getResource().getURI());
					String rowId = owlMLinkFromRow.getPropertyValue(annotationProId).toString();
					listRow.add(rowId);
				}
				if (owlMappingTableIndividualPro.getPredicate().getLocalName().equals("ownMappingColumn")) {
					Individual owlMLinkToColumn = ontModel
							.getIndividual(owlMappingTableIndividualPro.getResource().getURI());
					String columnId = owlMLinkToColumn.getPropertyValue(annotationProId).toString();
					listColumn.add(columnId);
				}
			}
			if (listRow.size() != 0) {
				for (int i = 0; i < listRow.size(); i++) {
					Element row = link.addElement("row");
					row.addAttribute("id", listRow.get(i));
					Individual owlMLinkFromRow = ontModel
							.getIndividual(METAG + name + "row_refer" + "__" + listRow.get(i));
					ArrayList<String> listPro = new ArrayList<String>();
					for (Iterator Itp = ontModel.listObjectProperties(); Itp.hasNext();) {
						ObjectProperty owllPro = (ObjectProperty) Itp.next();
						if (owllPro != null && owllPro.getLocalName() != null) {
							String Prop = owllPro.getLocalName();
							listPro.add(Prop);
						}

					}
					if (listColumn.size() != 0) {
						for (int j = 0; j < listColumn.size(); j++) {
							Element column = row.addElement("column");
							column.addAttribute("id", listColumn.get(j));
						}
					}
					for (Iterator Itr = owlMLinkFromRow.listProperties(); Itr.hasNext();) {
						Statement owlMappingRowIndividualPro = (Statement) Itr.next();
						if (listPro.contains(owlMappingRowIndividualPro.getPredicate().getLocalName())) {
							String relationship = owlMappingRowIndividualPro.getPredicate().getLocalName();
							System.out.println(relationship);
							Individual owlMLink = ontModel
									.getIndividual(owlMappingRowIndividualPro.getResource().getURI());
							String id = owlMLink.getPropertyValue(annotationProId).toString();
							for (Iterator<Element> itc = row.elementIterator(); itc.hasNext();) {
								Element columnElement = itc.next();
								String linkToColumn_id = columnElement.attribute("id").getValue();
								if (id.equals(linkToColumn_id)) {
									columnElement.setText(relationship);
								}
							}
						}
					}
				}

			}

			IFolder languageFolder = languagesFolder
					.getFolder(owlMapping_TableIndividual.getPropertyValue(annotationPropertyModelLocation).toString());
			IFolder modelFolder = null;
			IFolder modelFolder1 = languageFolder.getFolder(PackagePath.TYPE_MODEL);
			IFolder modelFolder2 = languageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
			if (modelFolder1.exists()) {
				modelFolder = modelFolder1;
			} else if (modelFolder2.exists()) {
				modelFolder = modelFolder2;
			}
			String fileName = modelFolder.getLocation().toOSString() + "/" + filename + ".mTable";
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("UTF-8");
			format.setNewLineAfterDeclaration(false);
			XMLWriter writer = new XMLWriter(new FileOutputStream(new File(fileName)), format);
			writer.write(document);
			writer.close();


			IFile modelFile = modelFolder.getFile(filename + ".mTable");
			modelFile.refreshLocal(IResource.DEPTH_ZERO, null);
		}
	}

}
