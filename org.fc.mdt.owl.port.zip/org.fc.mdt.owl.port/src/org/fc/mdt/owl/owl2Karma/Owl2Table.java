package org.fc.mdt.owl.owl2Karma;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.jena.ontology.AnnotationProperty;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.fc.mdt.core.karma.parser.util.PackagePath;

public class Owl2Table {

	static String METAG = "http://www.zkhoneycomb.com/formats/metagInOwl#";
	
	/**
	 * 读取owl文件
	 * @param owlFilePath
	 */
	private static OntModel readOwlFile(String owlFilePath) {
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		System.out.println(" path:" + path);
		ontModel.read(path);
		return ontModel;
	}
	
	/**
	 * 生成Table的方法重载
	 * @author xiaodu
	 */
	public static void GenerateTable(String owlFilePath, IFolder languagesFolder, IProgressMonitor monitor) throws IOException, CoreException {
		OntModel ontModel = readOwlFile(owlFilePath);
		GenerateTable(ontModel, languagesFolder, monitor);
	}

	public static void GenerateTable(OntModel ontModel, IFolder languagesFolder, IProgressMonitor monitor)
			throws IOException, CoreException {
		/* 输入为OntModel,所以注释掉此处 edited by xiaodu
		OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		String path = owlFilePath;
		ontModel.read(path);
		 */

		// 此语句将ontModel设置为非严格检测，这样由实例读取类时不会报错
		ontModel.setStrictMode(false);

		// 获取类
		OntClass owlTableClass = ontModel.getOntClass(METAG + "Table");
		OntClass owlColumnClass = ontModel.getOntClass(METAG + "Table_Columns");
		OntClass owlRowClass = ontModel.getOntClass(METAG + "Table_Rows");
		OntClass owlLinkClass = ontModel.getOntClass(METAG + "Table_Links");

		// 获取AnnotationProperty
		AnnotationProperty annotationProName = ontModel.getAnnotationProperty(METAG + "Name");
		AnnotationProperty annotationProlocalLabel = ontModel.createAnnotationProperty(METAG + "localLabel");
		AnnotationProperty annotationProId = ontModel.getAnnotationProperty(METAG + "id");
		AnnotationProperty annotationProname = ontModel.getAnnotationProperty(METAG + "name");
		AnnotationProperty annotationProWidth = ontModel.getAnnotationProperty(METAG + "width");
		AnnotationProperty annotationPronum = ontModel.getAnnotationProperty(METAG + "num");
		AnnotationProperty annotationProLink_text = ontModel.getAnnotationProperty(METAG + "link_text");		
		AnnotationProperty annotationProLocation = ontModel.getAnnotationProperty(METAG + "location");
		
		AnnotationProperty annotationPropertyModelLocation = ontModel.getAnnotationProperty(METAG + "modelLocation");
		
		
		// 一个owlTableIndividual是一个Table文件
		for (Iterator it = owlTableClass.listInstances(); it.hasNext();) {
			Individual owlTableIndividual = (Individual) it.next();			
			Document document = DocumentHelper.createDocument();
			Element KARMA_external_plugin = document.addElement("KARMA_external_plugin");
			Element Table = KARMA_external_plugin.addElement("Table");
			String name = owlTableIndividual.getPropertyValue(annotationProName).toString();
			Table.addAttribute("Name", name);
			String filename = name;
			if(owlTableIndividual.getPropertyValue(annotationProlocalLabel)!=null) {
				String localLabel = owlTableIndividual.getPropertyValue(annotationProlocalLabel).toString();
				filename = localLabel;
				Table.addAttribute("localLabel", localLabel);
			}
						
			// columns
			Element columns = Table.addElement("columns");
			for (Iterator It = owlTableIndividual.listProperties(); It.hasNext();) {
				Statement owlTableIndividualPro = (Statement) It.next();
				if (owlTableIndividualPro.getPredicate().getLocalName().equals("own")) {
					Individual owlTableIndividualColumns = ontModel
							.getIndividual(owlTableIndividualPro.getResource().getURI());
					String rowIndividual = name + "__" + "rows";
					String linkIndividual = name +"_link_";
					if(!owlTableIndividualColumns.getLocalName().equals(rowIndividual)&&!owlTableIndividualColumns.getLocalName().contains(linkIndividual)){
						Element column = columns.addElement("column");
						String column_Id = owlTableIndividualColumns.getPropertyValue(annotationProId).toString();
						String column_Name = owlTableIndividualColumns.getPropertyValue(annotationProname).toString();
						column.addAttribute("id", column_Id);
						column.addAttribute("name", column_Name);
						if(owlTableIndividualColumns.getPropertyValue(annotationProWidth)!=null) {
							String column_Width = owlTableIndividualColumns.getPropertyValue(annotationProWidth).toString();
							column.addAttribute("width", column_Width);
						}
					}
//					for (Iterator it_columns = owlColumnClass.listInstances(); it_columns.hasNext();) {
//						Individual owlColumnsElement = (Individual) it_columns.next();
//						if (owlTableIndividualColumns.getPropertyValue(annotationProId) != null) {
//							if (owlTableIndividualColumns.getLocalName()
//									.equals(owlColumnsElement.getLocalName())) {
//								Element column = columns.addElement("column");
//								String column_Id = owlTableIndividualColumns.getPropertyValue(annotationProId)
//										.toString();
//								String column_Name = owlTableIndividualColumns.getPropertyValue(annotationProName)
//										.toString();
//								column.addAttribute("id", column_Id);
//								column.addAttribute("name", column_Name);
////								System.out.println(column_Id);
//							}
//						}
//					}
				}
			}
			// rows
			Element rows = Table.addElement("rows");
			Individual owlRowIndividual = ontModel.getIndividual(METAG + name +"__" + "rows");
			String rows_num = owlRowIndividual.getPropertyValue(annotationPronum).toString();
			rows.addAttribute("num", rows_num);
			// links
			Element links = Table.addElement("links");
			for (Iterator It = owlTableIndividual.listProperties(); It.hasNext();) {
				Statement owlTableIndividualPro = (Statement) It.next();
				if (owlTableIndividualPro.getPredicate().getLocalName().equals("own")) {
					Individual owlTableIndividualLinks = ontModel
							.getIndividual(owlTableIndividualPro.getResource().getURI());
					String rowIndividual = name + "__" + "rows";
					String columnIndividual = name +"_column_";
					if(!owlTableIndividualLinks.getLocalName().equals(rowIndividual)&&!owlTableIndividualLinks.getLocalName().contains(columnIndividual)){
						Element link = links.addElement("link");
						String link_location = owlTableIndividualLinks.getPropertyValue(annotationProLocation).toString();
						String link_Name = owlTableIndividualLinks.getPropertyValue(annotationProname).toString().replace("\\","");
						String link_text = owlTableIndividualLinks.getPropertyValue(annotationProLink_text).toString().replace("\\","");
						link.addAttribute("location", link_location);
						link.addAttribute("name", link_Name);
						link.setText(link_text.replace(link_Name, link_text));
						
					}
				}
			}
			IFolder languageFolder = languagesFolder
					.getFolder(owlTableIndividual.getPropertyValue(annotationPropertyModelLocation).toString());
			IFolder modelFolder = null;
			IFolder modelFolder1 = languageFolder.getFolder(PackagePath.TYPE_MODEL);
			IFolder modelFolder2 = languageFolder.getFolder(PackagePath.TYPE_MODEL_ZH);
			if (modelFolder1.exists()) {
				modelFolder = modelFolder1;
			} else if (modelFolder2.exists()) {
				modelFolder = modelFolder2;
			}
			String fileName = modelFolder.getLocation().toOSString() + "/" + filename + ".table";
			OutputFormat format = OutputFormat.createPrettyPrint();
			System.out.println(document);
			format.setEncoding("UTF-8");
			format.setNewLineAfterDeclaration(false);
			XMLWriter writer = new XMLWriter(new FileOutputStream(new File(fileName)), format);
			writer.setEscapeText(false);
			writer.write(document);
			writer.close();
			IFile modelFile = modelFolder.getFile(filename + ".table");
			modelFile.refreshLocal(IResource.DEPTH_ZERO, null);
		}
	}

}
